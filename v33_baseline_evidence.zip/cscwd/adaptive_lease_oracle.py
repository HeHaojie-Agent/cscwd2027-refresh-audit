"""Exact zero-conflict lease oracle; future information is explicitly nondeployable."""
import numpy as np
from numba import njit
from causal_score_codec import HEADER

INTERVALS = (1, 2, 4, 8, 16)


def grant_packet(node, window, stamp, interval):
    code = INTERVALS.index(interval)
    packet = HEADER.pack(93, node, int(window), int(stamp))+bytes([code])
    assert len(packet) == 15
    assert HEADER.unpack_from(packet) == (93, node, int(window), int(stamp))
    assert INTERVALS[packet[14]] == interval
    return packet


@njit(cache=True)
def helper_bytes(q, previous, current):
    length = 0
    for node in (1, 2):
        bits = 0
        for c in range(12):
            diff = np.int64(q[current, node, c])-np.int64(q[previous, node, c])
            symbol = 2*diff if diff >= 0 else -2*diff-1
            bits += (symbol >> 2)+3
        length += 14+min(12, (bits+7)//8)
    return length


@njit(cache=True)
def lease_oracle(q, reset):
    n = len(q)
    send = np.zeros((n, 3), np.bool_)
    send[:, 0] = True
    grants = np.zeros(n, np.int16)
    prediction = np.empty(n, np.int16)
    edge_total = 0
    start = 0
    intervals = np.array([1, 2, 4, 8, 16])
    while start < n:
        end = start+1
        while end < n and not reset[end]:
            end += 1
        length = end-start
        cost = np.zeros(length+1, np.int64)
        choice = np.ones(length, np.int16)
        for local in range(length-1, -1, -1):
            a = start+local
            first = end
            for t in range(a+1, min(a+16, end)):
                cached_winner, full_winner, cached_best, full_best = 0, 0, -1, -1
                for c in range(12):
                    cached = int(q[t, 0, c])+int(q[a, 1, c])+int(q[a, 2, c])
                    full = int(q[t, 0, c])+int(q[t, 1, c])+int(q[t, 2, c])
                    if cached > cached_best:
                        cached_best, cached_winner = cached, c
                    if full > full_best:
                        full_best, full_winner = full, c
                if cached_winner != full_winner:
                    first = t
                    break
            best = np.int64(1 << 60)
            for h in intervals:
                b = min(a+h, end)
                if first < b:
                    continue
                value = 30 if a+1 < end else 0
                if b < end:
                    value += helper_bytes(q, a, b)+cost[b-start]
                if value < best or (value == best and h > choice[local]):
                    best, choice[local] = value, h
            cost[local] = best
        edge_total += cost[0]
        a = start
        send[start, 1:] = True
        while a < end:
            h = choice[a-start]
            if a+1 < end:
                grants[a+1] = h
            b = a+h
            if b < end:
                send[b, 1:] = True
            a = b
        start = end
    anchor = 0
    for t in range(n):
        if send[t, 1]:
            anchor = t
        best, winner = -1, 0
        for c in range(12):
            value = int(q[t, 0, c])+int(q[anchor, 1, c])+int(q[anchor, 2, c])
            if value > best:
                best, winner = value, c
        prediction[t] = winner
    return send, grants, prediction, edge_total


def verify_lease(q, reset, send, grants, prediction):
    n = len(q)
    assert send[:, 0].all() and send[reset].all()
    np.testing.assert_array_equal(send[:, 1], send[:, 2])
    anchor, due = 0, -1
    for t in range(n):
        expected = bool(reset[t])
        if reset[t]:
            anchor, due = t, -1
            assert grants[t] == 0
        elif t == anchor+1 and due < 0:
            assert int(grants[t]) in INTERVALS
            for node in (1, 2):
                grant_packet(node, t, t, int(grants[t]))
            due = anchor+int(grants[t])
            expected = due == t
        elif due == t:
            expected = True
            assert grants[t] == 0
        else:
            assert grants[t] == 0
        assert bool(send[t, 1]) == expected
        if expected:
            anchor, due = t, -1
        fused = q[t, 0].astype(np.int32)+q[anchor, 1:].astype(np.int32).sum(0)
        assert int(np.argmax(fused)) == prediction[t]
