"""Author-rule, causality, full-metric and real-packet checks on fixed policies."""
from pathlib import Path
import ast,itertools
import numpy as np,pandas as pd,torch
from sklearn.metrics import f1_score
from run_published_baselines_v33 import (ROOT,OUT,AUTHOR,confidence,fit_bins,candidates,cheap_metrics,
    costs,original_cases,external_cases,load,subject_frame,policy_mask,write,sha,schedule)
from protocol_replay_v26 import RiceWidthCodec
from run_oracle_imitation_v29 import read
source=(AUTHOR/'sensor_selection/derive_policies.py').read_text(encoding='utf-8')
tree=ast.parse(source);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='get_conf_dist')
scope={'np':np,'torch':torch};exec(compile(ast.Module(body=[fn],type_ignores=[]),'author_get_conf_dist','exec'),scope)
rng=np.random.default_rng(57);conf=torch.tensor(np.linspace(.001,.999,1000),dtype=torch.float64)
sensor=torch.tensor(rng.integers(0,4,1000));ensemble=torch.tensor(rng.integers(0,4,1000));labels=torch.tensor(rng.integers(0,4,1000))
distribution,lower,upper,marks,reliability,ensemble_rel=scope['get_conf_dist'](conf,sensor,ensemble,labels,10,np.zeros(10),np.zeros(10),np.zeros(10),'optimal')
gains=ensemble_rel-reliability
for budget in range(11):
    mask=policy_mask(gains,budget)
    # Same allocation as the author's descending positive gains.
    order=np.argsort(gains)[::-1];expected=np.zeros(10,np.uint8)
    expected[[int(j) for j in order if gains[j]>0][:budget]]=1
    assert np.array_equal(mask,expected)

seen=set();streams=0;packets=0;causal=0
for item in list(original_cases())+list(external_cases()):
    dataset=item['case']['dataset'];key=(dataset,item['stride'],item['offset'])
    if key in seen:continue
    seen.add(key);dest=OUT/'cases'/item['key'];meta=read(dest/'b_selection.json')['model']
    model={k:np.asarray(v) for k,v in meta.items()};a=load(item,'a');person=item['case']['evaluation_subjects'][0]
    f=subject_frame(a,person);conf=confidence(f);reference=f['reference'];known=f['endpoint_targets']!=-1
    rows=pd.DataFrame(read(dest/'metrics.json'))
    baseline=np.ones(len(reference)) # only denominators of returned rows depend on this input
    for c in candidates(model):
        row,send,pull,pred,total=cheap_metrics(f,conf,c,baseline)
        saved=rows[(rows.subject==person)&rows.method.eq(c['method'])].iloc[0]
        assert saved.total_bytes==int(total.sum())
        actual_f1=f1_score(f['endpoint_targets'][known],f['classes'][pred[known]],labels=f['classes'],average='macro',zero_division=0)
        assert abs(actual_f1-saved.known_endpoint_macro_f1)<1e-12
        assert abs(saved.reference_disagreement-np.mean(pred!=reference))<1e-12
        # Independent scalar inference and full codec state on a causal prefix.
        m=min(128,len(reference));anchor=0;requested=0;count=np.zeros(m,np.int64)
        encoders=[RiceWidthCodec('rice2',12) for _ in range(3)];decoders=[RiceWidthCodec('rice2',12) for _ in range(3)]
        for t in range(m):
            if f['reset'][t]:query=True
            elif c['margin']>=0:
                values=np.sort(f['q'][t,0].astype(int)+f['q'][anchor,1].astype(int)+f['q'][anchor,2].astype(int))
                query=values[-1]-values[-2]<=c['margin'] or t-anchor>=16
            else:
                j=int(np.searchsorted(c['marks'][1:-1],conf[t],side='left'))
                query=bool(c['mask'][j]) and (requested+1)*10<=c['budget']*(t+1)
                query=query or (c['cache'] and t-anchor>=16)
            assert bool(send[t,1])==query
            if query:anchor=t;requested+=1
            values=f['q'][t,0].astype(int)
            if c['cache'] or query:values+=f['q'][anchor,1].astype(int)+f['q'][anchor,2].astype(int)
            assert int(np.argmax(values))==int(pred[t])
            for node in range(3):
                if not send[t,node]:continue
                if f['reset'][t]:encoders[node].previous=None;decoders[node].previous=None
                packet=encoders[node].encode(f['q'][t,node],node,t,t)
                assert np.array_equal(decoders[node].decode(packet,node,t,t),f['q'][t,node])
                count[t]+=len(packet);packets+=1
        count+=30*pull[:m]+45*f['status'][:m]+(134+c['size'])*f['session_start'][:m]
        np.testing.assert_array_equal(count,total[:m])
        hidden=np.flatnonzero(~send[:,1])
        if len(hidden):
            q=f['q'].copy();at=int(hidden[len(hidden)//2]);q[at,1:]=rng.integers(0,256,q[at,1:].shape,dtype=np.uint8)
            send2,pull2,pred2=schedule(q,f['reset'],conf,c['marks'],c['mask'],c['budget'],c['cache'],c['margin'])
            assert np.array_equal(send2,send) and np.array_equal(pull2,pull) and np.array_equal(pred2,pred);causal+=1
        streams+=1
    print('Fixed-policy independent checks',key,flush=True)
assert streams==450 and len(seen)==9
write(OUT/'fixed_policy_verification.json',dict(all_passed=True,author_allocation_comparisons=11,full_metric_checks=streams,
    scenario_groups=9,actual_prefix_packets_encoded_decoded=packets,hidden_score_causality_checks=causal,
    original_author_commit=read(OUT/'frozen.json')['author_commit'],source_sha256=sha(__file__)))
print('Fixed policy and source correspondence audit passed',flush=True)
