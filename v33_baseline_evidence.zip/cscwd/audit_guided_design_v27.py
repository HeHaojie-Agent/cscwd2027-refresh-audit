"""Exact cost diagnostic and explicit-window control for B-only design selection."""
import struct
import numpy as np
from causal_score_codec import HEADER
from protocol_replay_v26 import RiceWidthCodec
from scalar_risk_calibration import (weight_packet,parse_weight_packet,runtime_parameters,
                                    lease_schedule,choose_interval)
from continuous_screen_accounting import session_grid,setup_packets,macro_f1
from continuous_causal_controls import METHODS
from validity_diagnostic import profile
from run_validity_diagnostic import onset_metrics
from confirm_lease_contribution import weighted_quantile

THRESHOLDS=(.005,.01,.02,.03,.05,.075,.1)
INTERVALS=(1,2,4,8,16)
SELECTORS=('fixed12','call_tuned','exhaustive','audit','fixed_matched')
CONTROL=struct.Struct('<IB')


def candidates():
    rules=[dict(rule='isotonic',threshold=float(np.float32(e)),period=0,name=f'iso{e:g}') for e in THRESHOLDS]
    rules += [dict(rule='periodic',threshold=0.,period=h,name=f'period{h}') for h in (2,4,8,16)]
    rules += [dict(rule='complete',threshold=0.,period=1,name='complete')]
    return [dict(**r,width=w,id=r['name']+f'_w{w}',order=2*i+j) for i,r in enumerate(rules) for j,w in enumerate((12,4))]


def subframe(f,mask):
    result={k:v.copy() if k=='classes' else v[mask].copy() for k,v in f.items()}
    n=len(result['q']);assert n
    physical=result['physical_reset'].copy();physical[0]=True
    if n>1:
        gap=np.diff(result['continuous_global_indices'])
        expected=int(np.median(gap[gap>0]))
        physical[1:] |= gap!=expected
    result['physical_reset']=physical
    result['reset'],result['session_start'],result['status']=session_grid(physical,2048)
    return result


def schedule(f,model,candidate):
    q=f['q'];n=len(q)
    if candidate['rule']=='isotonic':
        sent,grants,pred=lease_schedule(q,f['reset'],runtime_parameters(model),1,candidate['threshold'])
    else:
        h=candidate['period'];last=np.maximum.accumulate(np.where(f['reset'],np.arange(n),-1))
        refresh=(np.arange(n)-last)%h==0
        sent=np.column_stack([np.ones(n,bool),refresh,refresh]);grants=np.zeros(n,np.int16)
        anchor=np.maximum.accumulate(np.where(refresh,np.arange(n),-1))
        pred=np.argmax(q[:,0].astype(int)+q[anchor,1].astype(int)+q[anchor,2].astype(int),axis=1).astype(np.int16)
    return dict(send=sent,grants=grants,prediction=pred)


def score_lengths(f,sent,width,codec):
    q=f['q'];k=3 if codec=='rice3' else 2
    score=np.zeros(len(q),np.int64)
    for node in range(3):
        at=np.flatnonzero(sent[:,node]);rows=q[at,node,:width].astype(np.int16)
        diff=rows-np.vstack([rows[:1],rows[:-1]])
        symbols=np.where(diff<0,-2*diff-1,2*diff)
        lengths=14+np.minimum(width,(((symbols>>k)+1+k).sum(1)+7)//8)
        lengths[f['reset'][at]]=14+width
        score[at]+=lengths
    return score


def ledger(f,model,candidate,trace):
    complete=candidate['rule']=='complete'
    score=score_lengths(f,trace['send'],candidate['width'],'rice3' if complete else 'rice2')
    control=10*(trace['grants']>0).astype(np.int64)
    setup=(116 if complete else 134)*f['session_start'].astype(np.int64)+54*f['session_start']
    deploy=(len(weight_packet(model)) if candidate['rule']=='isotonic' else 0)*f['session_start'].astype(np.int64)
    status=45*f['status'].astype(np.int64)
    return dict(score_bytes=score,control_bytes=control,setup_bytes=setup,model_bytes=deploy,status_bytes=status,
                total_bytes=score+control+setup+deploy+status)


def quality(f,trace,events):
    pred=trace['prediction'];known=f['endpoint_targets']!=-1;classes=f['classes']
    reference=f['reference'];n=len(pred)
    ref_f1=macro_f1(f['endpoint_targets'][known],classes[reference[known]],classes)
    f1=macro_f1(f['endpoint_targets'][known],classes[pred[known]],classes)
    row=dict(reference_disagreement=float(np.mean(pred!=reference)),known_endpoint_macro_f1_drop=ref_f1-f1,
             known_endpoint_macro_f1=f1,known_endpoint_reference_f1=ref_f1,
             deployable_full_models_per_window=float(trace['send'].sum()/n))
    recovered=onset_metrics(f,pred,np.zeros(n),events,{})
    for item in recovered:
        item.pop('response_channel_ms',None)
    for criterion in ('first_correct','two_consecutive_correct'):
        selected=[r for r in recovered if r['criterion']==criterion and r['observable']]
        pairs=[r['extra_recovery_windows'] for r in selected if r['extra_recovery_windows'] is not None]
        row[criterion+'_additional_failure_fraction']=float(np.mean([r['additional_failure'] for r in selected])) if selected else None
        row[criterion+'_p95_extra_recovery_windows']=float(weighted_quantile(np.array(pairs),np.ones(len(pairs))/len(pairs))) if pairs else None
    gates=dict(D=row['reference_disagreement']<=.01,F=row['known_endpoint_macro_f1_drop']<=.005)
    for criterion in ('first_correct','two_consecutive_correct'):
        failure=row[criterion+'_additional_failure_fraction'];p95=row[criterion+'_p95_extra_recovery_windows']
        gates[criterion+'_fail']=failure is not None and failure<=.01
        gates[criterion+'_p95']=p95 is not None and p95<=1
    row['quality_pass']=all(gates.values());row['quality_gates']=gates
    return row,recovered


class WindowReceiver:
    """Bound reliable peer; identities are decoded from each five-byte message."""
    def __init__(self,peer,origin):
        self.peer,self.origin,self.last=peer,origin,origin-1
    def accept(self,packet):
        if len(packet)!=5:raise ValueError('Truncated or extra control bytes')
        window,code=CONTROL.unpack(packet)
        if window<self.origin or window<=self.last or not 1<=code<=5:
            raise ValueError('Stale/duplicate window or invalid action')
        self.last=window
        return window,INTERVALS[code-1]


def serialize(f,model,candidate,obtain=None):
    """Recompute decisions, then serialize/decode each packet; optional raw inference."""
    n=len(f['q']);width=candidate['width'];complete=candidate['rule']=='complete'
    codec='rice3' if complete else 'rice2'
    enc=[RiceWidthCodec(codec,width) for _ in range(3)];dec=[RiceWidthCodec(codec,width) for _ in range(3)]
    get=(lambda t,node:f['q'][t,node]) if obtain is None else obtain
    weight=weight_packet(model) if candidate['rule']=='isotonic' else b''
    params=runtime_parameters(parse_weight_packet(weight)) if weight else None
    sent=np.zeros((n,3),bool);grants=np.zeros(n,np.int16);pred=np.empty(n,np.int16)
    parts={k:np.zeros(n,np.int64) for k in ('score','control','setup','model','status')}
    cache=np.zeros((3,12),np.uint8);anchor=0;due=-1;receivers=None
    for t in range(n):
        window=int(f['continuous_global_indices'][t]);stamp=int(round(f['end_time'][t]*1e6))
        if f['session_start'][t]:
            configs=setup_packets(METHODS.index(codec),0) if complete else profile(6 if weight else 16,
                      16 if weight else candidate['period'],candidate['threshold'])
            extensions=[HEADER.pack(208,node,window,stamp)+bytes([1,width,2,32]) for node in range(3)]
            for node,packet in enumerate(extensions):
                assert HEADER.unpack_from(packet)==(208,node,window,stamp)
                assert packet[14:]==bytes([1,width,2,32]) and len(packet)==18
            parts['setup'][t]=sum(map(len,configs+extensions));parts['model'][t]=len(weight)
            receivers={node:WindowReceiver(node,window) for node in (1,2)}
        if f['reset'][t]:
            for c in enc+dec:c.previous=None
        primary=np.asarray(get(t,0),np.uint8)
        assert np.array_equal(primary,f['q'][t,0])
        refresh=complete or bool(f['reset'][t])
        if not refresh:
            if not weight:refresh=t-anchor>=candidate['period']
            elif due==t:refresh=True
            elif t==anchor+1 and due<0:
                interval=int(choose_interval(primary,cache,params,1,candidate['threshold']))
                grants[t]=interval;due=anchor+interval
                for node in (1,2):
                    packet=CONTROL.pack(window,1+INTERVALS.index(interval))
                    actual_window,actual_interval=receivers[node].accept(packet)
                    assert (actual_window,actual_interval)==(window,interval)
                    parts['control'][t]+=len(packet)
                refresh=due==t
        if refresh:anchor=t;due=-1
        fused=np.zeros(12,np.int32)
        for node in range(3):
            if node and not refresh:
                fused+=cache[node];continue
            q=primary if node==0 else np.asarray(get(t,node),np.uint8)
            assert np.array_equal(q,f['q'][t,node]) and not q[4:].any()
            packet=enc[node].encode(q[:width],node,window,stamp)
            restored=np.zeros(12,np.uint8);restored[:width]=dec[node].decode(packet,node,window,stamp)
            assert np.array_equal(restored,q)
            parts['score'][t]+=len(packet);sent[t,node]=True;fused+=restored
            if refresh:cache[node]=restored
        pred[t]=np.argmax(fused)
        if f['status'][t]:
            for node in range(3):
                status=HEADER.pack(3,node,window,stamp)+b'\0'
                assert HEADER.unpack_from(status)==(3,node,window,stamp)
                parts['status'][t]+=len(status)
    return dict(send=sent,grants=grants,prediction=pred,total_bytes=sum(parts.values()),
                **{k+'_bytes':v for k,v in parts.items()})
