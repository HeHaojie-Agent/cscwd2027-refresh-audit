"""Independent saved-path fusion, byte accounting and matching checks for V33."""
from pathlib import Path
import ast,hashlib,json
import numpy as np,pandas as pd
from run_oracle_imitation_v29 import original_cases,external_cases,load,read,write,sha
from run_nested_survival import subject_frame
from run_matched_calibration import fixed_baseline_name

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results/published_baselines_v33'
raw=pd.read_csv(OUT/'view_metrics.csv');old=pd.read_csv(ROOT/'results/twoside_trigger_v32/view_metrics.csv')
old=old[old.method.eq('twoside_sel')]
keys=['dataset','outer_fold','group','direction','subject','stride','offset']
ref=old[keys+['baseline_bytes_per_window']].drop_duplicates(keys)
matched=raw.merge(ref,on=keys,suffixes=('','_v32'),validate='many_to_one')
np.testing.assert_allclose(matched.baseline_bytes_per_window,matched.baseline_bytes_per_window_v32,atol=1e-12,rtol=0)
count=0;hash_count=0
for ci,item in enumerate(list(original_cases())+list(external_cases()),1):
    dest=OUT/'cases'/item['key'];complete=read(dest/'complete.json')
    for name,h in complete['files_sha256'].items():assert sha(dest/name)==h;hash_count+=1
    a=load(item,'a');choice=read(dest/'b_selection.json');bsubjects=item['case']['calibration_subjects']
    assert set(item['case']['evaluation_subjects']).isdisjoint(bsubjects)
    assert choice['A_loaded']==False
    codec='rice3' if item['external'] else fixed_baseline_name(item['case']['dataset'],item['stride'],item['offset'])
    case_rows=pd.DataFrame(read(dest/'metrics.json'))
    for subject in item['case']['evaluation_subjects']:
        f=subject_frame(a,subject);n=len(f['q']);q=f['q'];positions=np.arange(n)
        for family,c in choice['choices'].items():
            method=family+'_sel'
            with np.load(dest/f'subject{subject}_{method}.npz') as z:t={k:z[k] for k in z.files}
            assert np.array_equal(t['continuous_global_indices'],f['continuous_global_indices'])
            sent=t['send'];pull=t['pull'];assert sent[:,0].all() and sent[f['reset']].all()
            assert np.array_equal(sent[:,1],sent[:,2])
            assert not pull[f['reset']].any()
            anchor=np.maximum.accumulate(np.where(sent[:,1],positions,-1))
            fused=q[:,0].astype(np.int64)
            if c is None or c['cache']:fused+=q[anchor,1].astype(np.int64)+q[anchor,2].astype(np.int64)
            else:
                at=sent[:,1];fused[at]+=q[anchor[at],1].astype(np.int64)+q[anchor[at],2].astype(np.int64)
            np.testing.assert_array_equal(np.argmax(fused,axis=1),t['prediction'])
            k=3 if c is None and codec=='rice3' else 2
            total=np.zeros(n,np.int64)
            for node in range(3):
                at=np.flatnonzero(sent[:,node]);scores=q[at,node].astype(np.int64)
                delta=np.diff(scores,axis=0,prepend=scores[:1]);zigzag=2*np.abs(delta)-(delta<0)
                payload=np.minimum(12,np.ceil(((zigzag>>k)+1+k).sum(1)/8).astype(int))
                payload[f['reset'][at]]=12;total[at]+=14+payload
            total+=30*pull+45*f['status']+((116 if c is None else 134)+(0 if c is None else c['size']))*f['session_start']
            np.testing.assert_array_equal(total,t['total_bytes'])
            r=case_rows[(case_rows.subject==subject)&case_rows.method.eq(method)].iloc[0]
            assert r.total_bytes==int(total.sum())
            np.testing.assert_allclose(r.deployable_full_models_per_window,sent.sum()/n,atol=1e-12)
            np.testing.assert_allclose(r.reference_disagreement,np.mean(t['prediction']!=f['reference']),atol=1e-12)
            count+=1
    if ci%80==0:print('Independent audit',ci,'/396',flush=True)
assert count==3900
summary=pd.read_csv(OUT/'dataset_equal_metrics.csv')
group=['dataset','stride','offset','method']
means=raw.groupby(group+['subject','outer_fold','group']).mean(numeric_only=True).groupby(group+['subject']).mean(numeric_only=True).groupby(group).mean(numeric_only=True)
summary=summary.set_index(group)
for field in ('bytes_per_window','reference_disagreement','known_endpoint_macro_f1','deployable_full_models_per_window'):
    np.testing.assert_allclose(means[field].sort_index(),summary[field].sort_index(),rtol=0,atol=1e-12)
np.testing.assert_allclose(summary.savings_fraction,1-summary.bytes_per_window/summary.baseline_bytes_per_window,atol=1e-12,rtol=0)
for lock in ('prior.json','inputs.json'):
    assert all(sha(ROOT/n)==h for n,h in read(OUT/lock).items())
amendment=read(OUT/'summary_dispatch_amendment.json')
assert read(OUT/'frozen.json')['source_sha256']==sha(OUT/'source_at_execution.py')==amendment['original_source_sha256']
assert sha(ROOT/'run_published_baselines_v33.py')==amendment['updated_source_sha256']
current=ast.parse((ROOT/'run_published_baselines_v33.py').read_text(encoding='utf-8'))
nodes={n.name:ast.dump(n,include_attributes=False) for n in current.body if isinstance(n,ast.FunctionDef)}
for name,digest in amendment['unchanged_scoring_function_ast_sha256'].items():
    assert hashlib.sha256(nodes[name].encode()).hexdigest()==digest
write(OUT/'independent_verification.json',dict(all_passed=True,case_grids=396,selected_streams=count,
    same_complete_push_baseline_rows=len(raw),hash_checked_files=hash_count,dataset_summaries=len(summary),
    original_paper_preserved=True,no_new_node_training=True,new_independent_subjects=0,
    scope='Saved fusion, exact score/control/package ledger, all B-selected policies and fallbacks, baseline matching, subject-equal aggregation; recovery p95 uses exact rational mixtures in the separately locked summarizer'))
print('V33 independent audit passed',flush=True)
