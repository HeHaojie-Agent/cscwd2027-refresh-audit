# V33 results and executed code

Read baseline_comparison.pdf and V33_基线对比说明.md in cscwd/baseline_v33.
The CSV files preserve all fixed budgets, all B-selected outcomes, true-label F1,
the exact recovery mixture quantiles and the comparison with frozen V32.

The archive includes original B policy tables and selection records for all 396
case grids, source/protocol locks and both independent verification reports.
The full 42,900-row view table permits recomputing subject-equal means.

To rerun scoring, use the original frozen score frames and annotation files named
in inputs.json in the existing workspace. Raw signals, fitted node models and
the full per-window trajectories/event dictionaries are stored in the workspace,
outside this compact result archive. Training node models is not required.

The author baseline source is available at
https://github.com/SLDGroup/BeyondThresholds
Commit 7ab9c55b1995be5288b25abbe042926dab15fefe was inspected.
Clone it to cscwd/research/baseline_v33/BeyondThresholds when rerunning freeze or
the author-source comparison check.

Normal workflow in the original workspace

    python cscwd/run_published_baselines_v33.py selftest
    python cscwd/run_published_baselines_v33.py freeze
    python cscwd/run_published_baselines_v33.py run --workers 4
    python cscwd/run_published_baselines_v33.py summarize
    python cscwd/audit_published_baselines_v33.py
    python cscwd/audit_fixed_baselines_v33.py
    python cscwd/build_baseline_report_v33.py

The summary entry point delegates to the bounded-memory implementation.
source_at_execution.py preserves the scored source and original hash.
summary_dispatch_amendment.json records the later operational dispatch fix and
the unchanged AST hashes of all twelve policy/scoring functions. Candidate
policies, saved evaluation trajectories and selection results are unchanged.

The executed results establish a matched comparison with a published method.
They do not establish an unmodified original-paper reproduction or a global HAR
leaderboard result. Both primary-only/native and cached variants, complete-push
fallbacks and the higher-F1 operating points are retained for inspection.
