"""V11 one-datagram lossless scores; every available node costs <=26 bytes.

This is a protocol feasibility/control experiment, not a new compression claim.
The original 14-byte envelope is retained for every method, including raw.
No query, cross-node information, temporal predictor, or label is required.
"""
import heapq
import zlib
import numpy as np
from certified_score_protocol import message
from ondemand_controller import HEADER, SCORE, unpack

MIN_BASE = 40                 # kinds 40..48 encode bit width
TAIL_BASE = 50                # kinds 50..58 encode bit width
SHARED, CLASS, RICE, DEFLATE = 60, 61, 62, 63
CONTROL_METHODS = ('raw', 'minpack', 'shared_huffman', 'class_huffman', 'rice', 'deflate')
METHODS = CONTROL_METHODS + ('top2_tail', 'bounded_adaptive')


def bits_needed(values):
    return np.ceil(np.log2(np.asarray(values, dtype=np.int64)+1)).astype(np.int64)


def pack_fields(values, widths):
    value = 0; count = 0
    for v, width in zip(values, widths):
        v, width = int(v), int(width)
        if width < 0 or v < 0 or v >= 1 << width:
            raise ValueError('Field does not fit')
        value = (value << width) | v; count += width
    return (value << ((-count) % 8)).to_bytes((count+7)//8, 'big')


class BitReader:
    def __init__(self, payload):
        self.value = int.from_bytes(payload, 'big'); self.remaining = 8*len(payload)

    def read(self, width):
        if width < 0 or width > self.remaining: raise ValueError('Truncated bitstream')
        self.remaining -= width
        return (self.value >> self.remaining) & ((1 << width)-1)

    def finish(self):
        if self.remaining >= 8 or self.read(self.remaining): raise ValueError('Noncanonical padding')


def huffman_lengths(weights):
    heap = [(float(w), i, (i,)) for i, w in enumerate(weights)]
    heapq.heapify(heap); lengths = np.zeros(len(weights), np.uint8); serial = len(weights)
    while len(heap) > 1:
        a, _, x = heapq.heappop(heap); b, _, y = heapq.heappop(heap)
        lengths[list(x+y)] += 1
        heapq.heappush(heap, (a+b, serial, x+y)); serial += 1
    return lengths


def canonical(lengths):
    lengths = np.asarray(lengths, int)
    if np.any(lengths < 1) or np.any(lengths > 32): raise ValueError('Invalid Huffman lengths')
    codes = np.zeros(len(lengths), np.uint64); decoder = {}; code = 0; previous = 0
    for symbol in sorted(range(len(lengths)), key=lambda s: (lengths[s], s)):
        width = int(lengths[symbol]); code <<= width-previous
        if code >= 1 << width: raise ValueError('Oversubscribed Huffman lengths')
        codes[symbol] = code; decoder[width, code] = symbol
        code += 1; previous = width
    return codes, decoder


def delta(q, centers):
    diff = q.astype(np.int16)-centers.astype(np.int16)
    return np.where(diff >= 0, 2*diff, -2*diff-1).astype(np.int16)


def undelta(symbols, centers):
    symbols = np.asarray(symbols, int)
    diff = np.where(symbols % 2 == 0, symbols//2, -(symbols+1)//2)
    result = centers.astype(int)+diff
    if np.any((result < 0) | (result > 255)): raise ValueError('Decoded score outside uint8')
    return result.astype(np.uint8)


class BoundedCodec:
    def __init__(self, centers, shared_lengths, class_lengths, rice_k):
        self.centers = np.asarray(centers, np.uint8)
        self.shared_lengths = np.asarray(shared_lengths, np.uint8)
        self.class_lengths = np.asarray(class_lengths, np.uint8)
        self.rice_k = np.asarray(rice_k, np.uint8)
        if (self.centers.shape != (3, 12) or self.shared_lengths.shape != (3, 511)
                or self.class_lengths.shape != (3, 12, 256) or self.rice_k.shape != (3,)):
            raise ValueError('Wrong compression configuration shape')
        if np.any(self.rice_k > 7): raise ValueError('Invalid Rice parameter')
        self.shared = [canonical(row) for row in self.shared_lengths]
        self.per_class = [[canonical(row) for row in node] for node in self.class_lengths]

    @classmethod
    def fit(cls, q, subjects):
        q = np.asarray(q, np.uint8); subjects = np.asarray(subjects)
        # Each subject has the same total weight. Add-one mass is one window
        # relative to mean-window weight, so every unseen symbol remains legal.
        weights = np.array([1/np.sum(subjects == s) for s in subjects])
        weights *= len(weights)/weights.sum()
        centers = np.empty((3, 12), np.uint8)
        for node in range(3):
            for c in range(12):
                hist = np.bincount(q[:, node, c], weights=weights, minlength=256)
                centers[node, c] = np.searchsorted(np.cumsum(hist), weights.sum()/2)
        residual = delta(q, centers)
        shared = []; perclass = []; rice = []
        for node in range(3):
            hist = np.bincount(residual[:, node].ravel(), weights=np.repeat(weights, 12), minlength=511)+1
            shared.append(huffman_lengths(hist)); perclass.append([])
            for c in range(12):
                hist = np.bincount(q[:, node, c], weights=weights, minlength=256)+1
                perclass[-1].append(huffman_lengths(hist))
            costs = [np.average(np.minimum(12, ((residual[:, node] >> k)+1+k).sum(axis=1)//8
                       + ((((residual[:, node] >> k)+1+k).sum(axis=1) % 8) != 0)), weights=weights) for k in range(8)]
            rice.append(int(np.argmin(costs)))
        return cls(centers, shared, perclass, rice)

    def configuration(self, method):
        if method == 'shared_huffman': return self.centers.tobytes()+self.shared_lengths.tobytes()
        if method == 'class_huffman': return self.class_lengths.tobytes()
        if method == 'rice': return self.centers.tobytes()+self.rice_k.tobytes()
        if method == 'bounded_adaptive':
            return self.centers.tobytes()+self.shared_lengths.tobytes()+self.class_lengths.tobytes()+self.rice_k.tobytes()
        return b''

    def configuration_packets(self, method):
        packets = []
        for node in range(3):
            payload = b''
            if method in ('shared_huffman', 'rice', 'bounded_adaptive'):
                payload += self.centers[node].tobytes()
            if method in ('shared_huffman', 'bounded_adaptive'):
                payload += self.shared_lengths[node].tobytes()
            if method in ('class_huffman', 'bounded_adaptive'):
                payload += self.class_lengths[node].tobytes()
            if method in ('rice', 'bounded_adaptive'):
                payload += self.rice_k[node:node+1].tobytes()
            if payload: packets.append(message(70+METHODS.index(method), node, 0, 0, payload))
        return packets

    @classmethod
    def from_configuration_packets(cls, packets, method):
        centers = np.zeros((3, 12), np.uint8); shared = np.full((3, 511), 9, np.uint8)
        perclass = np.full((3, 12, 256), 8, np.uint8); rice = np.zeros(3, np.uint8)
        needs_config = method in ('shared_huffman', 'class_huffman', 'rice', 'bounded_adaptive')
        if len(packets) != (3 if needs_config else 0): raise ValueError('Wrong configuration count')
        for node, packet in enumerate(packets):
            expected = ((12 if method in ('shared_huffman', 'rice', 'bounded_adaptive') else 0)
                +(511 if method in ('shared_huffman', 'bounded_adaptive') else 0)
                +(3072 if method in ('class_huffman', 'bounded_adaptive') else 0)
                +(1 if method in ('rice', 'bounded_adaptive') else 0))
            payload = unpack(packet, 70+METHODS.index(method), node, 0, 0, expected); offset = 0
            if method in ('shared_huffman', 'rice', 'bounded_adaptive'):
                centers[node] = np.frombuffer(payload[offset:offset+12], np.uint8); offset += 12
            if method in ('shared_huffman', 'bounded_adaptive'):
                shared[node] = np.frombuffer(payload[offset:offset+511], np.uint8); offset += 511
            if method in ('class_huffman', 'bounded_adaptive'):
                perclass[node] = np.frombuffer(payload[offset:offset+3072], np.uint8).reshape(12, 256); offset += 3072
            if method in ('rice', 'bounded_adaptive'): rice[node] = payload[offset]
        return cls(centers, shared, perclass, rice)

    def lengths(self, q):
        """Exact analytic payload lengths except DEFLATE (uses real streams)."""
        q = np.asarray(q, np.uint8); n = len(q); result = {'raw': np.full((n, 3), 12, int)}
        width = bits_needed(np.ptp(q.astype(int), axis=2))
        result['minpack'] = np.minimum(12, 1+(12*width+7)//8)
        tail = np.sort(q.astype(int), axis=2)[:, :, :-2]
        result['top2_tail'] = np.minimum(12, 4+(10*bits_needed(np.ptp(tail, axis=2))+7)//8)
        residual = delta(q, self.centers)
        result['shared_huffman'] = np.minimum(12, (np.stack([self.shared_lengths[j, residual[:, j]].sum(axis=1) for j in range(3)], axis=1)+7)//8)
        result['class_huffman'] = np.minimum(12, (np.stack([self.class_lengths[j, np.arange(12), q[:, j]].sum(axis=1) for j in range(3)], axis=1)+7)//8)
        result['rice'] = np.minimum(12, (((residual >> self.rice_k[None, :, None])+1+self.rice_k[None, :, None]).sum(axis=2)+7)//8)
        return result

    def encode(self, node, q, window, timestamp, method='bounded_adaptive'):
        q = np.asarray(q)
        if q.shape != (12,) or q.dtype != np.uint8 or node not in (0, 1, 2): raise ValueError('Expected local uint8 vector')
        if method not in METHODS: raise ValueError('Unknown codec')
        choices = [(SCORE, q.tobytes())]
        allowed = set(METHODS) if method == 'bounded_adaptive' else {method}
        if 'minpack' in allowed:
            base = int(q.min()); width = int(bits_needed(int(q.max())-base))
            choices.append((MIN_BASE+width, bytes([base])+pack_fields(q.astype(int)-base, [width]*12)))
        if 'top2_tail' in allowed:
            indices = np.argsort(-q.astype(int), kind='stable')[:2]
            tail = q[[c for c in range(12) if c not in indices]]
            base = int(tail.min()); width = int(bits_needed(int(tail.max())-base))
            prefix = bytes([int(indices[0]) | int(indices[1]) << 4, int(q[indices[0]]), int(q[indices[1]]), base])
            choices.append((TAIL_BASE+width, prefix+pack_fields(tail.astype(int)-base, [width]*10)))
        if 'shared_huffman' in allowed:
            symbols = delta(q, self.centers[node]); codes, _ = self.shared[node]
            choices.append((SHARED, pack_fields(codes[symbols], self.shared_lengths[node, symbols])))
        if 'class_huffman' in allowed:
            choices.append((CLASS, pack_fields([self.per_class[node][c][0][q[c]] for c in range(12)], self.class_lengths[node, np.arange(12), q])))
        if 'rice' in allowed:
            k = int(self.rice_k[node]); symbols = delta(q, self.centers[node]); values = []; widths = []
            for symbol in symbols:
                quotient, remainder = int(symbol) >> k, int(symbol) & ((1 << k)-1)
                values.extend([1, remainder]); widths.extend([quotient+1, k])
            choices.append((RICE, pack_fields(values, widths)))
        if 'deflate' in allowed:
            compressor = zlib.compressobj(level=6, wbits=-15)
            choices.append((DEFLATE, compressor.compress(q.tobytes())+compressor.flush()))
        kind, payload = min(choices, key=lambda x: (len(x[1]), x[0]))
        packet = message(kind, node, window, timestamp, payload)
        if len(packet) > 26: raise AssertionError('Hard budget violated')
        return packet

    def decode(self, packet, node, window, timestamp):
        if len(packet) < 14 or len(packet) > 26: raise ValueError('Invalid bounded packet length')
        kind = HEADER.unpack_from(packet)[0]
        payload = unpack(packet, kind, node, window, timestamp, len(packet)-14)
        if kind == SCORE:
            if len(payload) != 12: raise ValueError('Wrong raw length')
            return np.frombuffer(payload, np.uint8).copy()
        if MIN_BASE <= kind <= MIN_BASE+8 or TAIL_BASE <= kind <= TAIL_BASE+8:
            is_tail = kind >= TAIL_BASE; width = kind-(TAIL_BASE if is_tail else MIN_BASE)
            prefix = 4 if is_tail else 1; count = 10 if is_tail else 12
            if len(payload) != prefix+(count*width+7)//8: raise ValueError('Wrong packed length')
            reader = BitReader(payload[prefix:]); base = payload[prefix-1]
            values = np.array([base+reader.read(width) for _ in range(count)], int); reader.finish()
            if np.any(values > 255): raise ValueError('Offset overflow')
            if not is_tail: return values.astype(np.uint8)
            a, b = payload[0] & 15, payload[0] >> 4
            if a >= 12 or b >= 12 or a == b: raise ValueError('Bad top indices')
            result = np.zeros(12, np.uint8); result[a] = payload[1]; result[b] = payload[2]
            result[[c for c in range(12) if c not in (a, b)]] = values
            if list(np.argsort(-result.astype(int), kind='stable')[:2]) != [a, b]: raise ValueError('Noncanonical top2')
            return result
        if kind == DEFLATE:
            decompressor = zlib.decompressobj(wbits=-15)
            raw = decompressor.decompress(payload, 13)
            if len(raw) != 12 or not decompressor.eof or decompressor.unused_data or decompressor.unconsumed_tail:
                raise ValueError('Invalid bounded DEFLATE stream')
            return np.frombuffer(raw, np.uint8).copy()
        if kind not in (SHARED, CLASS, RICE): raise ValueError('Unknown packet kind')
        reader = BitReader(payload); symbols = []
        for c in range(12):
            if kind == RICE:
                k = int(self.rice_k[node]); quotient = 0
                while reader.read(1) == 0:
                    quotient += 1
                    if quotient > 510 >> k: raise ValueError('Rice symbol overflow')
                symbol = (quotient << k) | reader.read(k)
                if symbol > 510: raise ValueError('Rice symbol overflow')
            else:
                _, table = self.shared[node] if kind == SHARED else self.per_class[node][c]
                value = 0; symbol = None
                for width in range(1, 33):
                    value = (value << 1) | reader.read(1)
                    if (width, value) in table: symbol = table[width, value]; break
                if symbol is None: raise ValueError('Invalid Huffman code')
            symbols.append(symbol)
        reader.finish()
        return np.asarray(symbols, np.uint8) if kind == CLASS else undelta(symbols, self.centers[node])
