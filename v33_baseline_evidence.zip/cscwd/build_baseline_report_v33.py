"""Readable, source-backed baseline report and paper-ready numerical tables."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
import numpy as np,pandas as pd,fitz

ROOT=Path(__file__).resolve().parent;R=ROOT/'results/published_baselines_v33';P=ROOT/'baseline_v33'
P.mkdir(exist_ok=True)
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):Path(p).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert read(R/'independent_verification.json')['all_passed'] and read(R/'fixed_policy_verification.json')['all_passed']
all_points=pd.read_csv(R/'dataset_equal_metrics.csv')
ours=pd.read_csv(ROOT/'results/twoside_trigger_v32/dataset_equal_metrics.csv')
ours=ours[ours.method.eq('twoside_sel')].copy()
ours['comparison_method']='V32 two-sided trigger'
selected=all_points[all_points.method.str.endswith('_sel')].copy()
selected['comparison_method']=selected.method
combined=pd.concat([selected,ours],ignore_index=True)
combined.to_csv(P/'selected_comparison.csv',index=False)
all_points.to_csv(P/'all_baseline_operating_points.csv',index=False)
best=[]
for key,group in all_points[all_points.method.str.startswith('bt_')&~all_points.method.str.endswith('_sel')].groupby(['dataset','stride','offset']):
    valid=group[group.reference_disagreement<=.01].copy();assert len(valid)
    valid['saving_tie']=valid.savings_fraction.round(12)
    baseline=valid.sort_values(['saving_tie','reference_disagreement','method'],ascending=[False,True,True]).iloc[0]
    new=ours[(ours.dataset==key[0])&(ours.stride==key[1])&(ours.offset==key[2])].iloc[0]
    best.append(dict(dataset=key[0],stride=key[1],offset=key[2],baseline=baseline.method,
        baseline_saving_percent=100*baseline.savings_fraction,baseline_disagreement_percent=100*baseline.reference_disagreement,
        baseline_calls=baseline.deployable_full_models_per_window,baseline_f1=baseline.known_endpoint_macro_f1,
        ours_saving_percent=100*new.savings_fraction,ours_disagreement_percent=100*new.reference_disagreement,
        ours_calls=new.deployable_full_models_per_window,ours_f1=new.known_endpoint_macro_f1,ours_pass=bool(new.all_checks_passed),
        comparison_scope='Best evaluated fixed BT budget after A outcomes; favorable diagnostic baseline, not a B-selected deployment result'))
best=pd.DataFrame(best);best.to_csv(P/'best_fixed_baseline_under_1pct.csv',index=False)
fixed=all_points[~all_points.method.str.endswith('_sel')]
f1_rows=[]
for key,group in fixed.groupby(['dataset','stride','offset']):
    top=group.sort_values(['known_endpoint_macro_f1','savings_fraction'],ascending=[False,False]).iloc[0]
    f1_rows.append(dict(dataset=key[0],stride=key[1],offset=key[2],method=top.method,macro_f1=top.known_endpoint_macro_f1,
        saving_percent=100*top.savings_fraction,disagreement_percent=100*top.reference_disagreement,
        scope='Post hoc F1 maximum; ignores the joint screen'))
pd.DataFrame(f1_rows).to_csv(P/'f1_tradeoff_diagnostic.csv',index=False)
labels={'pamap2':'PAMAP2','mhealth':'MHEALTH','opportunity':'OPPORTUNITY'}
grid=lambda s,o:'Primary' if s==1 else f'Alt. {o}'
source=read(R/'frozen.json')
write(P/'sources_and_scope.json',dict(checked_date='2026-11-18',
    primary_paper='https://par.nsf.gov/servlets/purl/10547273',
    author_code=source['author_repository'],author_commit=source['author_commit'],
    author_paper_sha256=sha(ROOT/'research/baseline_v33/beyond_thresholds.pdf'),
    other_candidates=[dict(name='CoSS',primary='https://www.dfki.de/en/web/research/projects-and-publications/publication/17091',
        status='Vetted adjacent sensor/rate co-optimization work; not run in this frozen-model refresh benchmark'),
        dict(name='Viveka',primary='https://arxiv.org/abs/2608.05572',
        status='2026 author preprint; not run; energy and sampling objectives differ from the serialized score-refresh objective')],
    task='Communication saving subject to the existing quality/call/recovery screen',
    leaderboard_claim=False,unmodified_original_experiment_claim=False,
    comparison_source_sha256={'V33':sha(R/'dataset_equal_metrics.csv'),'V32':sha(ROOT/'results/twoside_trigger_v32/dataset_equal_metrics.csv')}))

primary=best[best.stride==1].set_index('dataset')
notes=f'''# 三个数据集的首轮已发表基线对比

评测目标沿用当前论文。比较通信字节、识别宏 F1、参考失配、模型调用和两种恢复指标。三个数据集、三个网格全部纳入，共 396 个案例，节点模型和受试者角色沿用现有实验。

## 实际跑了哪些基线

本轮适配 Cooper 与 Marculescu 的 Beyond Thresholds，发表于 IoTDI 2024，第 1–12 页，DOI 10.1109/IoTDI61053.2024.00005。论文全文和作者代码已读取，作者仓库固定在 {source['author_commit']}。

作者方法把单节点预测置信度分成十个等频区间，按调用完整集成的预期准确率增益分配预算。这里分别运行标签估计增益、判决一致性估计增益，并各自测试单节点／集成级联输出，以及接入现有缓存的输出，共四组，每组保留十一种预算。另有六种主节点融合间隔阈值。每组通过 B 的字节、失配、F1 和调用条件选择最低字节方案，无合格方案则回退到匹配完整推送。

适配使用当前冻结的 MiniRocket/Ridge 节点和量化分数。初始节点固定为本文 primary，替换作者轮换初始传感器的设置。B 受试者承担置信度分区拟合和选择，所有 A 标签仅用于评分。单节点置信度由活跃类别上的还原分数 softmax 计算。缓存版本还使用当前协议的最大年龄 16。每次拉取计 30 字节，每会话计入实际序列化策略表。

## 当前结果

四组 BT 的 B 选择与单侧 margin 选择在所有案例中都回退到完整推送，节省 0%，每窗三次调用，九个场景均未通过联合筛查。V32 仍通过四个场景，包含 MHEALTH 三个网格和 OPPORTUNITY 主网格。

为呈现固定策略的完整取舍，报告另给出在 A 上查看所有已测 BT 预算后，参考失配不超过 1% 的最佳固定点。这个比较有利于基线，它属于事后诊断。

主网格数值为 PAMAP2 的 BT 节省 {primary.loc['pamap2'].baseline_saving_percent:.2f}%、V32 节省 {primary.loc['pamap2'].ours_saving_percent:.2f}%，MHEALTH 的 BT 节省 {primary.loc['mhealth'].baseline_saving_percent:.2f}%、V32 节省 {primary.loc['mhealth'].ours_saving_percent:.2f}%，OPPORTUNITY 的 BT 节省 {primary.loc['opportunity'].baseline_saving_percent:.2f}%、V32 节省 {primary.loc['opportunity'].ours_saving_percent:.2f}%。BT 的负节省代表比匹配完整推送花费更多字节。PAMAP2 上 V32 的失配为 {primary.loc['pamap2'].ours_disagreement_percent:.3f}%，仍超过 1% 门槛。

真实标签 F1 也完整保留。部分 BT 固定点或 margin 固定点取得更高 F1，同时容许更高参考失配。比如 OPPORTUNITY 主网格一个 BT 固定点的 F1 为 0.70483，V32 为 0.69550。结论限定为当前通信与质量联合目标下的比较。

## 文献定位

本轮形成的是有作者代码依据的已发表方法适配对比，覆盖三个现有真实数据集。SOTA 排名仍依赖具体标签任务、输入传感器、窗口、训练划分和目标指标，当前结果没有建立 HAR 准确率排行榜的领先地位。检索还核对了 CoSS 的作者机构正式发表记录，以及 Viveka 的 2026 作者预印本。前者联合选择传感器与采样率，后者研究上下文感知采样与能耗，它们未在本轮冻结节点模型的刷新实验中执行。

## 检查与复现

所有 3,900 条 B 选择轨迹已独立核对融合、费用与完整推送参考。固定预算另核对九个场景中的 450 条完整指标记录，并用原始编码器／解码器检查 105,980 个前缀报文，实施 422 项隐藏辅助分数扰动检查。作者代码的置信区间增益分配与本实现逐预算核对。恢复 p95 使用精确分数权重的受试者等权混合。全部 42,900 行候选／选择指标的汇总和原论文文件哈希通过核查。

汇总首次尝试因一次性加载事件记录占用过多内存而停止，最终由逐案例汇总脚本完成。评估轨迹、候选集合与门槛均按冻结协议执行，最终汇总使用明确的精确分位数定义。

`baseline_comparison.pdf` 是可直接检查的结果报告。`selected_comparison.csv` 包含全部选择结果与 V32，`all_baseline_operating_points.csv` 保留固定预算和完整指标，`best_fixed_baseline_under_1pct.csv` 给出事后最佳基线，`f1_tradeoff_diagnostic.csv` 展示 F1 取舍。原论文文件保持在 paper_v14，本轮报告和实验位于 baseline_v33 与 results/published_baselines_v33。

论文全文来源 https://par.nsf.gov/servlets/purl/10547273

作者代码 https://github.com/SLDGroup/BeyondThresholds

CoSS 正式发表记录 https://www.dfki.de/en/web/research/projects-and-publications/publication/17091

Viveka 作者预印本 https://arxiv.org/abs/2608.05572
'''
(P/'V33_基线对比说明.md').write_text(notes.replace('置信区间增益','置信度分区增益'),encoding='utf-8')

tex=[r'\documentclass[10pt,a4paper]{article}',r'\usepackage[margin=20mm]{geometry}',r'\usepackage{fontspec,booktabs,longtable,hyperref,array}',
 r'\setmainfont{Times New Roman}',r'\hypersetup{hidelinks}',r'\setlength{\parindent}{0pt}',r'\setlength{\parskip}{5pt}',r'\raggedbottom',r'\begin{document}',
 r'{\Large\bfseries Matched Published-Baseline Comparison}',r'\hfill 18 November 2026',
 r'\section*{Communication saving under the existing quality screen}',
 r'We evaluated four adaptations of Beyond Thresholds (IoTDI 2024) and a primary-only margin control on the frozen PAMAP2, MHEALTH and OPPORTUNITY scores. All 396 case--grid combinations were completed. The target retains the paper\textquotesingle{}s 10\% byte saving, 1\% reference-disagreement, 2.7 calls/window, subject-saving, F1 and recovery conditions. V32 is the already evaluated two-sided trigger.',
 r'The baseline allocates ensemble calls to ten primary-confidence bins using positive expected accuracy gain. We evaluate label-estimated and agreement-estimated gain, each with native single-node/ensemble output and a cached-fusion wrapper. Eleven budgets per family and six margin thresholds are retained. Fitted node models, labels, sensors and codecs follow the current experiment. Policy fitting and selection use B; A outcomes are scored afterwards.',
 r'\subsection*{Frozen B selections}',
 r'All five B selectors fall back to complete push in every case: 0\% saving, zero reference disagreement and three calls/window. No selector passes any of the nine scenarios. V32 passes four scenarios, comprising all three MHEALTH grids and the OPPORTUNITY primary grid. Complete push does not satisfy the saving or call conditions.',
 r'\subsection*{All evaluated fixed budgets remain visible}',
 r'The following diagnostic favors the baseline by inspecting all fixed BT budgets on A and choosing the cheapest mean-byte point within 1\% reference disagreement. It is separate from the frozen B selections above. A negative saving denotes byte overhead. V32 uses its frozen B-selected settings.',
 r'\begin{center}\small',r'\begin{tabular}{lrrrrl}',r'\toprule Dataset & BT saving (\%) & BT D (\%) & V32 saving (\%) & V32 D (\%) & V32 screen \\ \midrule']
for d in ('pamap2','mhealth','opportunity'):
    row=primary.loc[d];tex.append(f"{labels[d]} & {row.baseline_saving_percent:.2f} & {row.baseline_disagreement_percent:.3f} & {row.ours_saving_percent:.2f} & {row.ours_disagreement_percent:.3f} & {'pass' if row.ours_pass else 'D fails'}"+r' \\')
tex += [r'\bottomrule\end{tabular}\end{center}',
 r'PAMAP2 V32 remains above the strict 1\% limit. The comparison supports lower byte cost under the tested communication/quality conditions on successful scenarios. Some fixed baseline settings attain higher true-label F1 while accepting more reference disagreement: on the OPPORTUNITY primary grid, a BT setting reaches 0.70483 macro-F1 versus 0.69550 for V32. All operating points and true-label scores accompany the report.',
 r'\subsection*{Interpretation and source scope}',
 r'The executed comparison is a matched adaptation of a published sensor-selection method. It preserves the confidence-bin gain allocation but fixes the initial sensor and uses the current score-fusion backend in place of the original neural networks. The cache wrapper adds the common age-16 rule. All request pairs, score packets and serialized policy packages are charged. Dataset-wide HAR leaderboard superiority has not been established.',
 r'\newpage',r'\section*{Complete scenario comparison}',r'V32 frozen selections, with subject-equal means. D denotes reference disagreement and F1 is the known-endpoint macro-F1.',
 r'\begin{center}\small\begin{tabular}{llrrrrl}',r'\toprule Dataset & Grid & Saving (\%) & D (\%) & Calls & F1 & Screen \\ \midrule']
for d in ('pamap2','mhealth','opportunity'):
    for _,r in best[best.dataset==d].sort_values(['stride','offset']).iterrows():
        tex.append(f"{labels[d]} & {grid(r.stride,r.offset)} & {r.ours_saving_percent:.2f} & {r.ours_disagreement_percent:.3f} & {r.ours_calls:.3f} & {r.ours_f1:.5f} & {'pass' if r.ours_pass else 'fail'}"+r' \\')
tex += [r'\bottomrule\end{tabular}\end{center}',
 r'Best fixed BT diagnostic within 1\% reference disagreement. S denotes label-estimated gain; U denotes agreement-estimated gain. C is cached fusion and N is native single-node/ensemble output. Budget is the number of selected confidence bins out of ten.',
 r'\begin{center}\small\begin{tabular}{lllr rrr}',r'\toprule Dataset & Grid & BT variant & Budget & Saving (\%) & D (\%) & Calls \\ \midrule']
for d in ('pamap2','mhealth','opportunity'):
    for _,r in best[best.dataset==d].sort_values(['stride','offset']).iterrows():
        parts=r.baseline.split('_');variant=('S' if parts[1]=='supervised' else 'U')+('/C' if parts[2]=='cache' else '/N')
        budget=int(parts[-1][1:]);tex.append(f"{labels[d]} & {grid(r.stride,r.offset)} & {variant} & {budget} & {r.baseline_saving_percent:.2f} & {r.baseline_disagreement_percent:.3f} & {r.baseline_calls:.3f}"+r' \\')
tex += [r'\bottomrule\end{tabular}\end{center}',
 r'\subsection*{Verification}',
 r'Independent checks cover all 3,900 selected streams, 42,900 matched baseline rows and 495 dataset-level operating points. Fixed-policy checks cover 450 full metric records, 105,980 real encoded/decoded prefix packets and 422 hidden-score perturbation tests. The confidence-bin allocation matches the author implementation across eleven budgets. Recovery quantiles use exact rational subject/view/direction weights. Original paper files remain hash-matched.',
 r'\subsection*{Verified literature and reproducibility}',
 r'Cooper and Marculescu, \emph{Beyond Thresholds}, IoTDI 2024, pp. 1--12, DOI 10.1109/IoTDI61053.2024.00005. Author implementation commit \texttt{7ab9c55b1995be5288b25abbe042926dab15fefe}. \url{https://github.com/SLDGroup/BeyondThresholds}',
 r'CoSS is a newer adjacent sensor/rate co-optimization method in Expert Systems with Applications. Its official author-institution record covers all three datasets. It was not executed in this frozen-model refresh comparison. \url{https://www.dfki.de/en/web/research/projects-and-publications/publication/17091}',
 r'The CSV files provide all selected outcomes, every fixed operating point, true-label F1 and failed screen conditions. The source, frozen protocol and verification records are supplied with the results. All experiments reuse development-exposed subjects and introduce no independent individuals.',
 r'\end{document}']
content='\n'.join(tex)+'\n'
content=content.replace(r'\raggedbottom',r'\raggedbottom\emergencystretch=2em\setlength{\footskip}{20pt}')
content=content.replace(r'\texttt{7ab9c55b1995be5288b25abbe042926dab15fefe}',r'\texttt{7ab9c55}')
content=content.replace(r'\url{https://github.com/SLDGroup/BeyondThresholds}',r'\url{https://github.com/SLDGroup/BeyondThresholds}\par')
content=content.replace(r'\url{https://www.dfki.de/en/web/research/projects-and-publications/publication/17091}',r'\url{https://www.dfki.de/en/web/research/projects-and-publications/publication/17091}\par')
(P/'baseline_comparison.tex').write_text(content,encoding='utf-8')
build=ROOT.parent/'tmp/pdfs/baseline_v33';build.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env['TECTONIC_CACHE_DIR']=str(ROOT.parent/'tmp/pdfs/paper2_build/tex-cache')
with (build/'console.log').open('w',encoding='utf-8') as log:
    result=subprocess.run([os.environ['CODEX_TECTONIC_PATH'],'--keep-logs','--outdir',str(build),'baseline_comparison.tex'],cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT)
if result.returncode:print((build/'console.log').read_text(encoding='utf-8')[-5000:]);raise SystemExit(result.returncode)
shutil.copy2(build/'baseline_comparison.pdf',P/'baseline_comparison.pdf')
log=(build/'baseline_comparison.log').read_text(encoding='utf-8',errors='replace')
assert 'Overfull' not in log and not re.search(r'(Citation|Reference) .* undefined',log)
renders=P/'rendered';renders.mkdir(exist_ok=True)
with fitz.open(P/'baseline_comparison.pdf') as doc:
    for i,page in enumerate(doc,1):
        assert all(b[0]>25 and b[1]>25 and b[2]<page.rect.width-25 and b[3]<page.rect.height-25 for b in page.get_text('blocks'))
        page.get_pixmap(matrix=fitz.Matrix(1.7,1.7)).save(renders/f'page_{i}.png')
    pages=len(doc)
write(P/'validation.json',dict(pages=pages,no_overflow=True,no_undefined_references=True,visual_review='pending',
    pdf_sha256=sha(P/'baseline_comparison.pdf'),comparison_rows=len(combined),all_operating_points=len(all_points),
    passed_v32_scenarios=int(ours.all_checks_passed.sum()),passed_baseline_selected_scenarios=int(selected.all_checks_passed.sum())))
print(json.dumps(dict(pdf=str(P/'baseline_comparison.pdf'),pages=pages,selected_rows=len(combined)),ensure_ascii=False))
