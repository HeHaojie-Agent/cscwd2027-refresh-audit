"""V15 exact causal controls. No fitting, labels or future codebooks."""
import struct
import zlib
import numpy as np
from bounded_score_codec import pack_fields,BitReader,huffman_lengths,canonical,delta,undelta

HEADER=struct.Struct('<BBIQ')
MODES=['raw','delta_bitpack','delta_sparse']+[f'rice{k}' for k in range(8)]+['rolling_deflate','online_absolute_huffman','online_delta_huffman']
BASE={'raw':20,'delta_bitpack':22,'delta_sparse':24,**{f'rice{k}':30+2*k for k in range(8)},
      'rolling_deflate':46,'online_absolute_huffman':48,'online_delta_huffman':50}
ADAPTIVE=('raw','minpack','delta_bitpack','delta_sparse','rice4','rolling_deflate')


def message(kind,node,window,stamp,payload=b''):
    if not 0<=node<3 or not 0<=kind<=255: raise ValueError('Invalid message metadata')
    return HEADER.pack(kind,node,int(window),int(stamp))+payload


def payload(packet,node,window,stamp):
    if len(packet)<14: raise ValueError('Truncated header')
    kind,n,w,t=HEADER.unpack_from(packet)
    if (n,w,t)!=(node,int(window),int(stamp)): raise ValueError('Wrong packet identity')
    return kind,packet[14:]


def width(value): return int(value).bit_length()


class ExactCodec:
    def __init__(self,method):
        if method not in MODES+['minpack','adaptive']: raise ValueError('Unknown method')
        self.method=method; self.previous=None; self.history=[]; self.count=0
        self.hist=np.ones((12,256),np.int64) if method=='online_absolute_huffman' else np.ones(511,np.int64)
        self.books=None
        if method.startswith('online_'): self.rebuild()

    def rebuild(self):
        hist=self.hist if self.hist.ndim==2 else [self.hist]
        self.lengths=[huffman_lengths(h) for h in hist]
        self.books=[canonical(h) for h in self.lengths]

    def observe(self,row):
        row=np.asarray(row,np.uint8)
        if self.method=='online_absolute_huffman': self.hist[np.arange(12),row]+=1
        elif self.method=='online_delta_huffman' and self.previous is not None:
            self.hist+=np.bincount(delta(row,self.previous),minlength=511)
        self.previous=row.copy(); self.history=(self.history+[row.copy()])[-32:]; self.count+=1
        if self.method.startswith('online_') and self.count%128==0: self.rebuild()

    def encode(self,q,node,window,stamp):
        q=np.asarray(q)
        if q.dtype!=np.uint8 or q.shape not in ((1,12),(2,12)): raise ValueError('Expected one/two uint8 rows')
        count=len(q); choices=[(20+count-1,q.tobytes())]
        allowed=ADAPTIVE if self.method=='adaptive' else (self.method,)
        initial=self.previous is None; prefix=q[0].tobytes() if initial else b''
        target=q[1:] if initial else q
        bases=q[:-1] if initial else np.concatenate([self.previous[None],q[:-1]])
        symbols=delta(target,bases).ravel()
        if 'minpack' in allowed:
            base=int(q.min()); bits=width(int(q.max())-base)
            choices.append((60+2*bits+count-1,bytes([base])+pack_fields((q.astype(int)-base).ravel(),[bits]*q.size)))
        if 'delta_bitpack' in allowed and len(symbols):
            bits=width(symbols.max()); choices.append((22+count-1,prefix+bytes([bits])+pack_fields(symbols,[bits]*len(symbols))))
        if 'delta_sparse' in allowed and len(symbols):
            out=bytearray(prefix)
            for row,base in zip(target,bases):
                changed=np.flatnonzero(row!=base); mask=sum(1<<int(c) for c in changed)
                out.extend(mask.to_bytes(2,'little')); out.extend(row[changed].tobytes())
            choices.append((24+count-1,bytes(out)))
        for k in range(8):
            if f'rice{k}' in allowed and len(symbols):
                values=[]; widths=[]
                for s in symbols:
                    values.extend([1,int(s)&((1<<k)-1)]); widths.extend([(int(s)>>k)+1,k])
                choices.append((30+2*k+count-1,prefix+pack_fields(values,widths)))
        if 'rolling_deflate' in allowed:
            dictionary=np.asarray(self.history,np.uint8).tobytes() if self.history else b''
            obj=zlib.compressobj(6,wbits=-15,**({'zdict':dictionary} if dictionary else {}))
            choices.append((46+count-1,obj.compress(q.tobytes())+obj.flush()))
        if self.method.startswith('online_'):
            values=[]; widths=[]; prefix_h=b''
            for row in q:
                if self.method=='online_delta_huffman' and self.previous is None: prefix_h=row.tobytes()
                else:
                    syms=row if self.method=='online_absolute_huffman' else delta(row,self.previous)
                    for c,s in enumerate(syms):
                        book=c if self.method=='online_absolute_huffman' else 0
                        values.append(self.books[book][0][s]); widths.append(self.lengths[book][s])
                self.observe(row)
            choices.append((BASE[self.method]+count-1,prefix_h+pack_fields(values,widths)))
        else:
            for row in q: self.observe(row)
        kind,body=min(choices,key=lambda p:(len(p[1]),p[0]))
        assert len(body)<=12*count
        return message(kind,node,window,stamp,body)

    def decode(self,packet,count,node,window,stamp):
        kind,body=payload(packet,node,window,stamp)
        if count not in (1,2) or len(body)>12*count or (kind%2)!=(count-1): raise ValueError('Invalid packet/count')
        basekind=kind-count+1
        if 60<=basekind<=76:
            mode='minpack'; bits=(basekind-60)//2
        else:
            mode=next((m for m,b in BASE.items() if b==basekind),None)
        if mode is None or (mode!='raw' and mode not in (ADAPTIVE if self.method=='adaptive' else (self.method,))):
            raise ValueError('Wrong codec kind')
        if mode=='raw':
            if len(body)!=12*count: raise ValueError('Raw length')
            rows=np.frombuffer(body,np.uint8).reshape(count,12).copy()
            for row in rows: self.observe(row)
            return rows
        if mode=='minpack':
            if len(body)!=1+(count*12*bits+7)//8: raise ValueError('Packed length')
            reader=BitReader(body[1:]); rows=np.array([body[0]+reader.read(bits) for _ in range(12*count)],int).reshape(count,12)
            reader.finish()
            if np.any(rows>255): raise ValueError('Packed overflow')
        elif mode=='rolling_deflate':
            dictionary=np.asarray(self.history,np.uint8).tobytes() if self.history else b''
            obj=zlib.decompressobj(wbits=-15,**({'zdict':dictionary} if dictionary else {}))
            decoded=obj.decompress(body,12*count+1)
            if len(decoded)!=12*count or not obj.eof or obj.unused_data or obj.unconsumed_tail: raise ValueError('DEFLATE length/end')
            rows=np.frombuffer(decoded,np.uint8).reshape(count,12).copy()
        else:
            rows=[]; offset=0; previous=self.previous
            if previous is None and mode!='online_absolute_huffman':
                if len(body)<12: raise ValueError('Missing keyframe')
                previous=np.frombuffer(body[:12],np.uint8).copy(); rows.append(previous); offset=12
                if mode.startswith('online_'): self.observe(previous)
            if mode=='delta_bitpack':
                if offset>=len(body): raise ValueError('Missing width')
                bits=body[offset]; offset+=1
                if bits>9: raise ValueError('Delta width')
            if mode=='delta_sparse':
                for _ in range(count-len(rows)):
                    if offset+2>len(body): raise ValueError('Missing mask')
                    mask=int.from_bytes(body[offset:offset+2],'little'); offset+=2
                    if mask>=4096: raise ValueError('Reserved mask')
                    chosen=[c for c in range(12) if mask&(1<<c)]
                    if offset+len(chosen)>len(body): raise ValueError('Sparse truncation')
                    row=previous.copy(); row[chosen]=np.frombuffer(body[offset:offset+len(chosen)],np.uint8)
                    offset+=len(chosen); rows.append(row); previous=row
                if offset!=len(body): raise ValueError('Sparse trailing bytes')
            else:
                reader=BitReader(body[offset:])
                for _ in range(count-len(rows)):
                    syms=[]
                    for c in range(12):
                        if mode=='delta_bitpack': s=reader.read(bits)
                        elif mode.startswith('rice'):
                            k=int(mode[4:]); quotient=0
                            while reader.read(1)==0:
                                quotient+=1
                                if quotient>510>>k: raise ValueError('Rice overflow')
                            s=(quotient<<k)|reader.read(k)
                        else:
                            book=c if mode=='online_absolute_huffman' else 0; code=0; s=None
                            for n in range(1,33):
                                code=(code<<1)|reader.read(1)
                                if (n,code) in self.books[book][1]: s=self.books[book][1][n,code]; break
                            if s is None: raise ValueError('Huffman prefix')
                        if s>510 or (mode=='online_absolute_huffman' and s>255): raise ValueError('Symbol overflow')
                        syms.append(s)
                    previous=np.asarray(syms,np.uint8) if mode=='online_absolute_huffman' else undelta(np.asarray(syms),previous)
                    rows.append(previous)
                    if mode.startswith('online_'): self.observe(previous)
                reader.finish()
            rows=np.asarray(rows,np.uint8)
            if mode.startswith('online_'): return rows
        for row in rows: self.observe(row)
        return rows.astype(np.uint8)
