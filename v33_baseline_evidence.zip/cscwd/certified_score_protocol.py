"""V9 candidate: sparse exact-score pushes and certified selective refinement.

The certificate preserves the existing full-uint8 equal-fusion ARGMAX, not the
unquantized model, confidence vector, ground truth, or sensor inference cost.
Coordinator code can only inspect serialized replies. All node models run once.
"""
import time
import numpy as np
from ondemand_controller import HEADER, header, unpack, STATUS, SCORE
from run_pamap2_baselines import decision

TOP2 = 10
MASK_QUERY = 11
MASK_REPLY = 12
REST_QUERY = 13
REST_REPLY = 14


def message(kind, node, window, timestamp, payload=b''):
    if node not in (0, 1, 2): raise ValueError('Invalid sensor node')
    return HEADER.pack(kind, node, int(window), int(timestamp))+payload


def class_mask(classes):
    if len(set(classes)) != len(classes) or any(c < 0 or c >= 12 for c in classes): raise ValueError('Invalid class mask')
    value = sum(1 << int(c) for c in classes)
    return int(value).to_bytes(2, 'little')


def parse_mask(payload):
    if len(payload) != 2: raise ValueError('Mask length')
    value = int.from_bytes(payload, 'little')
    if value == 0 or value >= 1 << 12: raise ValueError('Empty or reserved mask bits')
    return np.array([c for c in range(12) if value & (1 << c)], dtype=int)


class ScoreServer:
    """Remote node owner. Quantized scores never exposed to its caller."""
    def __init__(self, scores, available, codec, windows, timestamps, x=None, bundles=None, names=None, slices=None):
        self._scores = scores; self._available = np.asarray(available, dtype=bool)
        self.codec = codec; self.windows = np.asarray(windows); self.timestamps = np.asarray(timestamps)
        self._x = x; self._bundles = bundles; self._names = names; self._slices = slices
        self._quantized = np.zeros((len(windows), 3, 12), dtype=np.uint8)
        self._sent = np.zeros((len(windows), 3, 12), dtype=bool)
        self._ready = np.zeros((len(windows), 3), dtype=bool)
        self.evaluations = np.zeros((len(windows), 3), dtype=np.int8); self.node_wall_ns = np.zeros(3, dtype=np.int64)
        levels = np.arange(256, dtype=np.uint8)
        self.lookup = np.stack([codec.decode(node, np.tile(levels[:, None], (1, 12)))[:, 0] for node in range(3)])
        if not np.isfinite(self.lookup).all() or np.any(np.diff(self.lookup, axis=1) < 0): raise ValueError('Need finite monotone float32 codec')
        if not np.isfinite(np.sum(np.max(np.abs(self.lookup), axis=1), dtype=np.float32)): raise ValueError('Fusion may overflow')

    def _prepare(self, node):
        ix = np.flatnonzero(self._available[:, node] & ~self._ready[:, node])
        if not len(ix): return
        started = time.perf_counter_ns()
        if self._x is None: local = self._scores[ix, node]
        else:
            name = self._names[node]; local = decision(self._bundles[name], self._x[ix, self._slices[name], :])
        self._quantized[ix, node] = self.codec.encode(node, local)
        self.node_wall_ns[node] += time.perf_counter_ns()-started
        self._ready[ix, node] = True; self.evaluations[ix, node] += 1

    def initial(self, node, full=False):
        self._prepare(node); output = []
        for i in range(len(self.windows)):
            if not self._available[i, node]: output.append(None); continue
            q = self._quantized[i, node]
            if full:
                payload = q.tobytes(); kind = SCORE; self._sent[i, node] = True
            else:
                order = np.argsort(-q.astype(int), kind='stable')[:2]
                payload = bytes([int(order[0]) | (int(order[1]) << 4), int(q[order[0]]), int(q[order[1]])])
                kind = TOP2; self._sent[i, node, order] = True
            output.append(message(kind, node, self.windows[i], self.timestamps[i], payload))
        return output

    def refine(self, node, index, request):
        if not self._available[index, node] or not self._ready[index, node]: raise ValueError('Unready or unavailable node')
        kind, _, _, _ = HEADER.unpack_from(request)
        if kind == MASK_QUERY:
            payload = unpack(request, MASK_QUERY, node, self.windows[index], self.timestamps[index], 2)
            classes = parse_mask(payload); reply_kind = MASK_REPLY
            if self._sent[index, node, classes].any(): raise ValueError('Repeated class request')
        elif kind == REST_QUERY:
            unpack(request, REST_QUERY, node, self.windows[index], self.timestamps[index], 0)
            classes = np.flatnonzero(~self._sent[index, node]); reply_kind = REST_REPLY
        else: raise ValueError('Invalid refinement request kind')
        if not len(classes): raise ValueError('Empty refinement')
        self._sent[index, node, classes] = True
        return message(reply_kind, node, self.windows[index], self.timestamps[index], self._quantized[index, node, classes].tobytes())


def decode_top2(packet, node, window, timestamp):
    payload = unpack(packet, TOP2, node, window, timestamp, 3)
    first, second = payload[0] & 15, payload[0] >> 4
    if first >= 12 or second >= 12 or first == second or payload[1] < payload[2]: raise ValueError('Malformed top2')
    if payload[1] == payload[2] and first > second: raise ValueError('Noncanonical top2 tie')
    return np.array([first, second]), np.array([payload[1], payload[2]], dtype=np.uint8)


def sum_bounds(low, high, available, lookup):
    """Monotone float32 decoding and SAME reduction order as full baseline.

Finite round-to-nearest addition is monotone. Summing endpoint float32 arrays
in the identical axis order therefore brackets the actual full float32 sum;
no real-arithmetic approximation is substituted for the deployed operation.
"""
    lo = np.stack([lookup[node, low[:, node]] for node in range(3)], axis=1)
    hi = np.stack([lookup[node, high[:, node]] for node in range(3)], axis=1)
    lower = np.where(available[:, :, None], lo, np.float32(0)).sum(axis=1, dtype=np.float32)
    upper = np.where(available[:, :, None], hi, np.float32(0)).sum(axis=1, dtype=np.float32)
    return lower, upper


def certificates(lower, upper, available):
    winner = lower.argmax(axis=1); out = np.ones(len(lower), dtype=bool)
    for c in range(12):
        # np.argmax resolves exact ties toward the smaller class index.
        out &= (c == winner) | np.where(c < winner, lower[np.arange(len(lower)), winner] > upper[:, c],
                                       lower[np.arange(len(lower)), winner] >= upper[:, c])
    out &= available.any(axis=1)
    return out, winner


def run_certified(server, classes, mode='selective', order=(0, 1, 2), seed=0, trace_limit=0):
    n = len(server.windows); available = np.zeros((n, 3), bool)
    low = np.zeros((n, 3, 12), np.uint8); high = np.zeros_like(low)
    known = np.zeros_like(low, dtype=bool); initial_bytes = np.zeros(n, dtype=np.int32)
    query_bytes = np.zeros(n, dtype=np.int32); reply_bytes = np.zeros(n, dtype=np.int32)
    rounds = np.zeros(n, dtype=np.int8); first_certified = np.zeros(n, bool); traces = []
    mask_queries = np.zeros(n, dtype=np.int8); revealed_entries = np.zeros(n, dtype=np.int16)
    for node in range(3):
        for i, packet in enumerate(server.initial(node)):
            if packet is None: continue
            indices, value = decode_top2(packet, node, server.windows[i], server.timestamps[i])
            available[i, node] = True; high[i, node] = value[1]
            low[i, node, indices] = value; high[i, node, indices] = value; known[i, node, indices] = True
            initial_bytes[i] += len(packet)
    random_order = np.argsort(np.random.default_rng(seed).random((n, 3)), axis=1)
    prediction = np.full(n, -1, dtype=np.int32)
    for step in range(31):
        lower, upper = sum_bounds(low, high, available, server.lookup)
        certified, winner = certificates(lower, upper, available)
        if step == 0: first_certified = certified.copy()
        prediction[certified] = np.asarray(classes)[winner[certified]]
        pending = np.flatnonzero(available.any(axis=1) & ~certified)
        if not len(pending): break
        if step == 30: raise AssertionError('Refinement failed to terminate')
        for i in pending:
            best_lower = lower[i, winner[i]]
            candidates = (upper[i] > best_lower) | ((upper[i] == best_lower) & (np.arange(12) <= winner[i]))
            candidates[winner[i]] = True
            choices = []
            for node in order:
                if not available[i, node]: continue
                remaining = np.flatnonzero(~known[i, node]); active = remaining[candidates[remaining]]
                if not len(active): continue
                use_rest = mode == 'full_remaining' or len(active)+2 >= len(remaining)
                requested = remaining if use_rest else active
                cost = 28+len(remaining) if use_rest else 30+len(active)
                widths = (server.lookup[node, high[i, node, requested]]-server.lookup[node, low[i, node, requested]]).astype(float)
                priority = float(widths.sum()/cost)
                choices.append((priority, node, requested, use_rest))
            if not choices: raise AssertionError('Uncertified frame has no eligible unknown score')
            if mode == 'fixed_order': choice = choices[0]
            elif mode == 'random':
                priority_order = random_order[i].tolist()
                choice = min(choices, key=lambda value: priority_order.index(value[1]))
            else: choice = max(choices, key=lambda value: value[0])
            _, node, requested, use_rest = choice
            request = message(REST_QUERY if use_rest else MASK_QUERY, node, server.windows[i], server.timestamps[i], b'' if use_rest else class_mask(requested.tolist()))
            response = server.refine(node, i, request)
            payload = unpack(response, REST_REPLY if use_rest else MASK_REPLY, node, server.windows[i], server.timestamps[i], len(requested))
            value = np.frombuffer(payload, dtype=np.uint8)
            if np.any(value < low[i, node, requested]) or np.any(value > high[i, node, requested]): raise ValueError('Refinement contradicts rank bounds')
            low[i, node, requested] = value; high[i, node, requested] = value; known[i, node, requested] = True
            query_bytes[i] += len(request); reply_bytes[i] += len(response); rounds[i] += 1
            mask_queries[i] += not use_rest; revealed_entries[i] += len(requested)
            if i < trace_limit: traces.append({'window': int(server.windows[i]), 'step': step, 'node': node,
                'classes': requested.tolist(), 'kind': 'rest' if use_rest else 'mask', 'request_hex': request.hex(), 'response_hex': response.hex()})
    data_bytes = initial_bytes+query_bytes+reply_bytes
    # Selective requests never cost more than requesting all remaining scores.
    # Each refinement reveals >=1 previously unknown entry; top2 has10 unknown.
    if np.any(rounds > available.sum(axis=1)) or np.any(data_bytes > 55*available.sum(axis=1)):
        raise AssertionError('Protocol exceeded one completion per node or data cap')
    return {'prediction': prediction, 'initial_bytes': initial_bytes, 'query_bytes': query_bytes, 'reply_bytes': reply_bytes,
            'data_bytes': data_bytes, 'rounds': rounds, 'first_certified': first_certified,
            'mask_queries': mask_queries, 'revealed_entries': revealed_entries, 'low_codes': low, 'high_codes': high,
            'lower_sum': lower, 'upper_sum': upper,
            'evaluated_nodes': server.evaluations.sum(axis=1), 'known_entries': known.sum(axis=(1, 2)),
            'actual_node_wall_ns': server.node_wall_ns.copy(), 'traces': traces, 'available': available}
