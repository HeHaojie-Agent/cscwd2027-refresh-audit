"""V18C post-hoc contribution audit; no refitting or deployed free-message claim."""
import argparse
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from nested_validity_data import ROOT, read, write, sha
from run_lease_oracle import OUT as SOURCE, PREVIOUS, SCENARIOS
from run_lease_prediction import check as source_check, policies
from run_nested_survival import subject_frame
from validity_survival import frame, paid_features
from lease_prediction import probabilities
from summarize_validity_diagnostic import checks
from summarize_nested_survival import clean

OUT = ROOT/'results'/'contribution_confirmation_v18c'
KEYS = ['dataset', 'outer_fold', 'group', 'subject', 'stride', 'offset', 'method']
POLICY_COST_CHECKS = {'ten_percent_bytes_saved', 'seventyfive_percent_subjects_positive',
    'ten_percent_fewer_full_model_calls'}


def cost_counts(total, grants):
    total, grants = np.asarray(total), np.asarray(grants)
    fee = 30*(grants > 0).astype(np.int64)
    immediate = 30*(grants == 1).astype(np.int64)
    assert np.all(total >= fee)
    return dict(actual_total_bytes=int(total.sum()), no_all_grants_total_bytes=int((total-fee).sum()),
        no_h1_grants_total_bytes=int((total-immediate).sum()), grant_count=int((grants > 0).sum()),
        h1_grant_count=int((grants == 1).sum()))


def truth_counts(reference, prediction, endpoint, classes):
    known = endpoint != -1
    conflict = reference != prediction
    ref_correct = classes[reference] == endpoint
    candidate_correct = classes[prediction] == endpoint
    return dict(known_conflicts=int((known & conflict).sum()), unknown_conflicts=int((~known & conflict).sum()),
        harmful_conflicts=int((known & conflict & ref_correct & ~candidate_correct).sum()),
        helpful_conflicts=int((known & conflict & ~ref_correct & candidate_correct).sum()),
        both_wrong_conflicts=int((known & conflict & ~ref_correct & ~candidate_correct).sum()),
        known_reference_errors=int((known & ~ref_correct).sum()),
        known_candidate_errors=int((known & ~candidate_correct).sum()))


def lease_outcomes(error, reset, current, interval):
    starts = np.flatnonzero(reset)
    assert starts[0] == 0
    ends = np.r_[starts[1:], len(error)]
    end_at = np.repeat(ends, np.diff(np.r_[starts, len(error)]))
    requested_end = current+interval-1
    observed_end = np.minimum(requested_end, end_at[current])
    prefix = np.r_[0, np.cumsum(error)]
    return requested_end <= end_at[current], (prefix[observed_end]-prefix[current]) > 0, observed_end-current


def weighted_quantile(values, weights, probability=.95):
    values, weights = np.asarray(values), np.asarray(weights)
    assert len(values) and (weights > 0).all()
    order = np.argsort(values, kind='stable')
    cdf = np.cumsum(weights[order])/weights.sum()
    return float(values[order[min(np.searchsorted(cdf, probability), len(values)-1)]])


def prepare():
    source_check()
    OUT.mkdir(parents=True, exist_ok=True)
    sources = {name: sha(ROOT/name) for name in ('confirm_lease_contribution.py', 'test_contribution_confirmation.py',
        'CSCWD2027_核心贡献确认口径V18C.md')}
    inputs = {str((SOURCE/name).relative_to(ROOT)): sha(SOURCE/name) for name in
        ('artifact_manifest.json', 'final_integrity.json', 'research_decision.json', 'view_metrics.csv',
         'onset_view_metrics.csv', 'onsets.csv', 'dataset_equal_metrics.csv', 'risk_subject_equal.csv')}
    inputs[str((PREVIOUS/'plan.json').relative_to(ROOT))] = sha(PREVIOUS/'plan.json')
    for path in (SOURCE/'learner_inputs.json', SOURCE/'learner_source_lock.json'):
        inputs[str(path.relative_to(ROOT))] = sha(path)
    if (OUT/'source_lock.json').exists():
        assert read(OUT/'source_lock.json') == sources
        assert read(OUT/'inputs.json') == inputs
    else:
        write(OUT/'source_lock.json', sources)
        write(OUT/'inputs.json', inputs)
        write(OUT/'frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
            post_hoc_after_v18_results=True, fitting=False, new_outer_validation_or_test=False,
            source_sha256=sha(OUT/'source_lock.json'), inputs_sha256=sha(OUT/'inputs.json')))


def verify_inputs():
    for name, value in read(OUT/'source_lock.json').items():
        assert sha(ROOT/name) == value, name
    for name, value in read(OUT/'inputs.json').items():
        assert sha(ROOT/name) == value, name
    original = read(SOURCE/'artifact_manifest.json')
    for name, value in original.items():
        assert sha(SOURCE/name) == value, name
    assert sha(SOURCE/'artifact_manifest.json') == read(SOURCE/'final_integrity.json')['artifact_manifest_sha256']
    source_check()
    return len(original)


def trace_audit():
    rows, selected, cases = [], [], 0
    for group in read(PREVIOUS/'plan.json')['groups']:
        lineage = read(PREVIOUS/'groups'/group['id']/'lineage.json')
        for stride, offset in SCENARIOS:
            target = SOURCE/'learners'/group['id']/f'stride{stride}_offset{offset}'
            models = read(target/'models.json')
            f_all = frame(ROOT/lineage['evaluation_scores'], group['dataset'], stride, offset)
            for subject in group['controller_held_subjects']:
                f = subject_frame(f_all, subject)
                n, reference = len(f['q']), f['reference']
                with np.load(target/f'subject{subject}_trace.npz') as trace:
                    np.testing.assert_array_equal(trace['continuous_global_indices'], f['continuous_global_indices'])
                    for i, (name, _, threshold, model) in enumerate(policies(models)):
                        total, grants, send, prediction = (trace[f'm{i}_'+key] for key in ('total_bytes', 'grants', 'send', 'prediction'))
                        counts = cost_counts(total, grants)
                        truth = truth_counts(reference, prediction, f['endpoint_targets'], f['classes'])
                        assert truth['known_conflicts'] == sum(truth[key] for key in
                            ('harmful_conflicts', 'helpful_conflicts', 'both_wrong_conflicts'))
                        assert truth['known_conflicts']+truth['unknown_conflicts'] == int((prediction != reference).sum())
                        assert truth['known_candidate_errors']-truth['known_reference_errors'] == truth['harmful_conflicts']-truth['helpful_conflicts']
                        common = dict(dataset=group['dataset'], outer_fold=group['outer_fold'], group=group['group'],
                            subject=subject, stride=stride, offset=offset, method=name)
                        row = dict(**common, **counts, **truth, audit_windows=n,
                            trace_full_model_calls=int(send.sum()), trace_reference_mismatches=int((prediction != reference).sum()))
                        for h in (1, 2, 4, 8, 16):
                            row[f'h{h}_grant_count'] = int((grants == h).sum())
                        rows.append(row)
                        if not model:
                            assert counts['grant_count'] == 0 and counts['actual_total_bytes'] == counts['no_all_grants_total_bytes']
                            continue
                        current = np.flatnonzero(grants > 1)
                        if not len(current):
                            selected.append(dict(**common, extensions=0, full_followup=0, censored=0,
                                full_predicted_event_sum=0., full_event_count=0, censored_positive_events=0))
                            continue
                        last = np.maximum.accumulate(np.where(send[:, 1], np.arange(n), -1))
                        previous = np.r_[0, last[:-1]]
                        forecasts = probabilities(model, paid_features(f['q'], current, previous[current]))
                        interval = grants[current]
                        column = np.searchsorted([2, 4, 8, 16], interval)
                        risk = forecasts[np.arange(len(current)), column]
                        assert (risk <= threshold+1e-12).all()
                        complete, event, observed = lease_outcomes(prediction != reference, f['reset'], current, interval)
                        assert (observed >= 1).all()
                        selected.append(dict(**common, extensions=len(current), full_followup=int(complete.sum()),
                            censored=int((~complete).sum()), full_predicted_event_sum=float(risk[complete].sum()),
                            full_event_count=int(event[complete].sum()), censored_positive_events=int(event[~complete].sum())))
            cases += 1
            if cases % 24 == 0:
                print(f'V18C trace audit {cases}/192', flush=True)
    assert cases == 192 and len(rows) == 5760 and len(selected) == 3456
    pd.DataFrame(rows).to_csv(OUT/'trace_audit.csv', index=False)
    pd.DataFrame(selected).to_csv(OUT/'selected_lease_view_metrics.csv', index=False)
    return pd.DataFrame(rows), pd.DataFrame(selected)


def cost_summary(audit):
    metrics = pd.read_csv(SOURCE/'view_metrics.csv')
    recovery = pd.read_csv(SOURCE/'onset_view_metrics.csv')
    assert len(metrics) == len(audit) == 5760 and not metrics.duplicated(KEYS).any()
    merged = metrics.merge(audit, on=KEYS, validate='one_to_one').merge(recovery, on=KEYS, validate='one_to_one')
    assert len(merged) == 5760
    for actual, expected in [('audit_windows', 'windows'), ('actual_total_bytes', 'total_bytes'),
        ('trace_full_model_calls', 'full_model_calls'), ('trace_reference_mismatches', 'reference_mismatches'),
        ('grant_count', 'grant_decisions')]:
        np.testing.assert_array_equal(merged[actual], merged[expected])
    np.testing.assert_array_equal(30*merged.grant_count, merged.grant_bytes)
    expanded = []
    for scenario, column in [('actual', 'actual_total_bytes'), ('free_all_grants', 'no_all_grants_total_bytes'),
                             ('free_h1_grants', 'no_h1_grants_total_bytes')]:
        part = merged.copy()
        part['charge_scenario'] = scenario
        part['bytes_per_window'] = part[column]/part.windows
        part['nongrant_bytes_per_window'] = part.no_all_grants_total_bytes/part.windows
        part['grants_per_window'] = part.grant_count/part.windows
        part['h1_grants_per_window'] = part.h1_grant_count/part.windows
        for name in ('harmful_conflicts', 'helpful_conflicts', 'both_wrong_conflicts', 'known_reference_errors', 'known_candidate_errors'):
            part[name+'_per_known_window'] = part[name]/part.known_windows
        expanded.append(part)
    views = pd.concat(expanded, ignore_index=True)
    subject = views.groupby(['dataset', 'stride', 'offset', 'method', 'charge_scenario', 'subject'], as_index=False).mean(numeric_only=True)
    subject['positive_savings'] = subject.bytes_per_window < subject.baseline_bytes_per_window
    subject.to_csv(OUT/'cost_subject_equal.csv', index=False)
    equal = subject.groupby(['dataset', 'stride', 'offset', 'method', 'charge_scenario'], as_index=False).mean(numeric_only=True)
    equal['savings_fraction'] = 1-equal.bytes_per_window/equal.baseline_bytes_per_window
    equal['positive_subject_fraction'] = equal.positive_savings
    equal['max_pair_grant_bytes_for_ten_percent_average_saving'] = np.where(equal.grants_per_window > 0,
        (.9*equal.baseline_bytes_per_window-equal.nongrant_bytes_per_window)/equal.grants_per_window, np.nan)
    equal.to_csv(OUT/'cost_dataset_equal.csv', index=False)
    actual = equal[equal.charge_scenario == 'actual']
    canonical = pd.read_csv(SOURCE/'dataset_equal_metrics.csv')
    joined = actual.merge(canonical, on=['dataset', 'stride', 'offset', 'method'], validate='one_to_one', suffixes=('_audit', '_original'))
    assert len(joined) == 90
    for name in ['bytes_per_window', 'full_models_per_window', 'reference_disagreement', 'known_endpoint_macro_f1_drop',
                 'first_correct_p95_extra_recovery_windows', 'two_consecutive_correct_p95_extra_recovery_windows']:
        np.testing.assert_allclose(joined[name+'_audit'], joined[name+'_original'], atol=1e-12, rtol=1e-12)
    points = []
    for _, row in equal.iterrows():
        item = row.to_dict()
        item['checks'] = checks(item)
        item['quality_checks_passed'] = all(value for key, value in item['checks'].items() if key not in POLICY_COST_CHECKS)
        item['all_checks_passed'] = all(item['checks'].values())
        points.append(item)
    write(OUT/'cost_checks.json', clean(points))
    actual_subject = subject[subject.charge_scenario == 'actual'].copy()
    actual_subject.to_csv(OUT/'truth_subject_equal.csv', index=False)
    selected_truth = actual_subject.groupby(['dataset', 'stride', 'offset', 'method'], as_index=False).mean(numeric_only=True)
    selected_truth.to_csv(OUT/'truth_dataset_equal.csv', index=False)
    return points, subject


def pairwise_predictive_summary():
    risk = pd.read_csv(SOURCE/'risk_subject_equal.csv')
    keys = ['dataset', 'stride', 'offset', 'horizon', 'subject']
    rows = []
    for left, right in [('direct', 'geometric'), ('survival', 'geometric'), ('survival', 'direct')]:
        joined = risk[risk.model == left].merge(risk[risk.model == right], on=keys, validate='one_to_one', suffixes=('_left', '_right'))
        for _, row in joined.iterrows():
            common = {key: row[key] for key in keys}
            rows.append(dict(**common, comparison=left+' minus '+right,
                brier_difference=row.brier_left-row.brier_right, auc_difference=row.auc_left-row.auc_right,
                absolute_mean_risk_bias_difference=abs(row.mean_predicted_risk_left-row.observed_event_rate_left)-
                    abs(row.mean_predicted_risk_right-row.observed_event_rate_right)))
    paired = pd.DataFrame(rows)
    paired.to_csv(OUT/'predictive_subject_pairs.csv', index=False)
    result = []
    for key, part in paired.groupby(['dataset', 'stride', 'offset', 'horizon', 'comparison']):
        result.append(dict(zip(['dataset', 'stride', 'offset', 'horizon', 'comparison'], key), subjects=len(part),
            brier_difference=float(part.brier_difference.mean()), auc_difference=float(part.auc_difference.mean()),
            brier_improved_subjects=int((part.brier_difference < -1e-12).sum()),
            auc_improved_subjects=int((part.auc_difference > 1e-12).sum()),
            brier_difference_min=float(part.brier_difference.min()), brier_difference_max=float(part.brier_difference.max())))
    summary = pd.DataFrame(result)
    summary.to_csv(OUT/'predictive_pair_summary.csv', index=False)
    return summary


def selected_summary(selected):
    keys = ['dataset', 'stride', 'offset', 'method', 'subject']
    subject = selected.groupby(keys, as_index=False).sum(numeric_only=True)
    subject['mean_predicted_risk'] = subject.full_predicted_event_sum/subject.full_followup.replace(0, np.nan)
    subject['observed_event_fraction'] = subject.full_event_count/subject.full_followup.replace(0, np.nan)
    subject['censoring_fraction'] = subject.censored/subject.extensions.replace(0, np.nan)
    subject.to_csv(OUT/'selected_lease_subject_equal.csv', index=False)
    rows = []
    for key, part in subject.groupby(['dataset', 'stride', 'offset', 'method']):
        rows.append(dict(zip(['dataset', 'stride', 'offset', 'method'], key),
            subjects_total=len(part), subjects_with_complete_extensions=int((part.full_followup > 0).sum()),
            mean_predicted_risk=float(part.mean_predicted_risk.mean()), observed_event_fraction=float(part.observed_event_fraction.mean()),
            mean_subject_censoring_fraction=float(part.censoring_fraction.mean()),
            repeated_train_role_extensions=int(part.extensions.sum()),
            repeated_train_role_complete_extensions=int(part.full_followup.sum())))
    result = pd.DataFrame(rows)
    result.to_csv(OUT/'selected_lease_dataset_equal.csv', index=False)
    return result


def recovery_quantiles():
    events = pd.read_csv(SOURCE/'onsets.csv')
    viewkeys = KEYS+['criterion']
    skeys = ['dataset', 'stride', 'offset', 'method', 'subject', 'criterion']
    scenario = ['dataset', 'stride', 'offset', 'method', 'criterion']
    pair = events.dropna(subset=['extra_recovery_windows']).copy()
    pair['view_pairs'] = pair.groupby(viewkeys).extra_recovery_windows.transform('size')
    subject_views = pair[viewkeys].drop_duplicates().groupby(skeys, as_index=False).size().rename(columns={'size': 'subject_views'})
    paired_rows = len(pair)
    pair = pair.merge(subject_views, on=skeys, validate='many_to_one')
    assert len(pair) == paired_rows
    pair['subject_count'] = pair.groupby(scenario).subject.transform('nunique')
    pair['weight'] = 1/(pair.view_pairs*pair.subject_views*pair.subject_count)
    rows = []
    for key, part in pair.groupby(scenario):
        assert np.isclose(part.weight.sum(), 1.)
        rows.append(dict(zip(scenario, key), subject_equal_mixture_p95=weighted_quantile(part.extra_recovery_windows, part.weight),
            mixture_fraction_extra_over_one=float(part.loc[part.extra_recovery_windows > 1, 'weight'].sum()),
            subjects_with_paired_success=int(part.subject.nunique()), repeated_train_role_pairs=len(part)))
    summary = pd.DataFrame(rows)
    summary.to_csv(OUT/'recovery_quantile_audit.csv', index=False)
    return summary


def run():
    original_artifacts = verify_inputs()
    audit, selected = trace_audit()
    points, subjects = cost_summary(audit)
    predictive = pairwise_predictive_summary()
    selection = selected_summary(selected)
    recovery = recovery_quantiles()
    passed = {}
    for scenario in ('actual', 'free_all_grants', 'free_h1_grants'):
        passed[scenario] = []
        for method in sorted({item['method'] for item in points}):
            part = [item for item in points if item['charge_scenario'] == scenario and item['method'] == method]
            assert len(part) == 6
            if all(item['all_checks_passed'] for item in part):
                passed[scenario].append(method)
    primary_free = [x for x in points if x['method'] == 'survival_t0.01' and x['charge_scenario'] == 'free_all_grants']
    assert len(primary_free) == 6
    verdict = dict(version='contribution_confirmation_v18c', post_hoc_diagnostic=True,
        original_artifacts_verified_unchanged=original_artifacts, methods_passing_all_six_scenarios_by_charge_assumption=passed,
        primary_survival_free_all_grants_passes=all(x['all_checks_passed'] for x in primary_free),
        independent_incremental_time_information_established=False, actual_net_benefit_established=False,
        new_core_contribution_established=False, reference_consistency_expiry_is_not_actual_task_failure=True,
        no_fitting=True, no_new_outer_validation_or_test=True,
        cost_bounds_are_not_deployed_protocols=True, no_new_hardware_performance_claim=True,
        confidence='Share with caveats: arithmetic and paired comparisons audited; training-role post-hoc scope only')
    write(OUT/'verdict.json', verdict)
    write(OUT/'report_data.json', clean(dict(verdict=verdict, costs=points,
        predictive=predictive.to_dict('records'), selected=selection.to_dict('records'),
        recovery=recovery.to_dict('records'))))
    print(dict(completed=True, original_artifacts_unchanged=original_artifacts, all_six_passed=passed,
        primary_free_notifications_passed=verdict['primary_survival_free_all_grants_passes']))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        prepare() if args.prepare_only else run()
