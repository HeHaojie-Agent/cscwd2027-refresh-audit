"""Exact vectorized costs for V15 fixed controls, with real DEFLATE sizes.

Entropy codebooks use only previously decoded observations. Costs are checked
against actual packets at keyframes and entropy rebuilds, not estimated rates.
"""
import zlib
import numpy as np
from bounded_score_codec import huffman_lengths,delta,bits_needed
from causal_score_codec import ExactCodec,ADAPTIVE

METHODS=['raw','minpack','delta_bitpack','delta_sparse']+[f'rice{k}' for k in range(8)]+[
    'rolling_deflate','adaptive','online_absolute_huffman','online_delta_huffman']


def blocks(reset,waiting):
    if waiting not in (0,1) or not len(reset) or not reset[0]: raise ValueError('Invalid stream/wait')
    starts=[]; counts=[]; i=0
    while i<len(reset):
        count=2 if waiting and i+1<len(reset) and not reset[i+1] else 1
        starts.append(i); counts.append(count); i+=count
    return np.asarray(starts,int),np.asarray(counts,int)


def huffman_bits(q,reset,absolute):
    result=np.zeros(q.shape[:2],np.int32); boundaries=np.r_[np.flatnonzero(reset),len(q)]
    symbols=np.zeros_like(q,dtype=np.int16); symbols[1:]=delta(q[1:],q[:-1])
    for a,b in zip(boundaries[:-1],boundaries[1:]):
        for node in range(3):
            hist=np.ones((12,256),np.int64) if absolute else np.ones(511,np.int64)
            for start in range(a,b,128):
                stop=min(start+128,b)
                if absolute:
                    lengths=np.stack([huffman_lengths(h) for h in hist])
                    result[start:stop,node]=lengths[np.arange(12),q[start:stop,node]].sum(axis=1)
                    for c in range(12): hist[c]+=np.bincount(q[start:stop,node,c],minlength=256)
                else:
                    lengths=huffman_lengths(hist); first=start+(start==a)
                    result[first:stop,node]=lengths[symbols[first:stop,node]].sum(axis=1)
                    hist+=np.bincount(symbols[first:stop,node].ravel(),minlength=511)
    return result


def costs(q,reset,waiting):
    q=np.asarray(q,np.uint8); starts,counts=blocks(reset,waiting); ends=starts+counts-1
    keyframe=reset[starts]; prefix=12*keyframe[:,None]; targets=counts-keyframe
    raw=np.broadcast_to((12*counts)[:,None],(len(starts),3)).copy()
    symbols=np.zeros_like(q,dtype=np.int16); symbols[1:]=delta(q[1:],q[:-1]); symbols[reset]=0
    reduce=lambda a:np.add.reduceat(a,starts,axis=0)
    w=bits_needed(np.maximum(q[starts].max(axis=2),q[ends].max(axis=2)).astype(int)-np.minimum(q[starts].min(axis=2),q[ends].min(axis=2)))
    values=dict(raw=raw,minpack=np.minimum(raw,1+(12*counts[:,None]*w+7)//8))
    w=bits_needed(np.maximum.reduceat(symbols.max(axis=2),starts,axis=0))
    packed=prefix+1+(12*targets[:,None]*w+7)//8; packed[targets==0]=raw[targets==0]+1
    sparse=(q!=np.roll(q,1,axis=0)).sum(axis=2)+2; sparse[reset]=0
    values['delta_bitpack']=np.minimum(raw,packed); values['delta_sparse']=np.minimum(raw,prefix+reduce(sparse))
    for k in range(8):
        bits=((symbols>>k)+1+k).sum(axis=2); bits[reset]=0
        values[f'rice{k}']=np.minimum(raw,prefix+(reduce(bits)+7)//8)
    for method,absolute in [('online_absolute_huffman',True),('online_delta_huffman',False)]:
        bits=huffman_bits(q,reset,absolute)
        values[method]=np.minimum(raw,(0 if absolute else prefix)+(reduce(bits)+7)//8)
    compressed=raw.copy(); stream_start=0
    for block,(a,count) in enumerate(zip(starts,counts)):
        if reset[a]: stream_start=a
        for node in range(3):
            dictionary=q[max(stream_start,a-32):a,node].tobytes()
            obj=zlib.compressobj(6,wbits=-15,**({'zdict':dictionary} if dictionary else {}))
            compressed[block,node]=min(12*count,len(obj.compress(q[a:a+count,node].tobytes())+obj.flush()))
    values['rolling_deflate']=compressed
    values['adaptive']=np.minimum.reduce([values[m] for m in ADAPTIVE])
    return starts,counts,{m:v.astype(np.int32)+14 for m,v in values.items()}


def wire_check(q,reset,starts,counts,expected,windows,stamps):
    checks=0; rows_checked=0
    for method in METHODS:
        for node in range(3):
            sender=receiver=None
            for block,(start,count) in enumerate(zip(starts,counts)):
                if reset[start]: sender=ExactCodec(method); receiver=ExactCodec(method)
                selected=sender.count<4 or sender.count%128<2
                rows=q[start:start+count,node]
                if selected:
                    packet=sender.encode(rows,node,windows[start],stamps[start])
                    assert len(packet)==expected[method][block,node],(method,start,len(packet),expected[method][block,node])
                    decoded=receiver.decode(packet,int(count),node,windows[start],stamps[start])
                    np.testing.assert_array_equal(decoded,rows); checks+=1; rows_checked+=count
                else:
                    # Exact-push controls reconstruct all intervening vectors;
                    # advancing their receiver state is offline audit replay.
                    for row in rows: sender.observe(row); receiver.observe(row)
    return checks,rows_checked
