"""V14 persisted subject-held MiniRocket models for continuous train streams.

Hyperparameters are selected only within the final fit subjects. Intermediate
windows/features are memory mapped; neither scores nor labels of outer-held
subjects are used for model/feature/scaler selection.
"""
import hashlib
import json
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score
from scipy.linalg import cho_factor,cho_solve
from continuous_training_data import CONFIG,OUT as DATA,TrainingWindowStore

ALPHAS=(.01,.1,1.,10.,100.,1000.,10000.)
BATCH=64


def digest(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()


def close_map(array):
    if hasattr(array,'flush'): array.flush()
    mapping=getattr(array,'_mmap',None)
    if mapping is not None: mapping.close()


def remove_scratch(paths,root):
    root=Path(root).resolve()
    for path in paths:
        path=Path(path).resolve()
        if not path.is_relative_to(root): raise ValueError('Scratch outside experiment root')
        if path.is_file(): path.unlink()


def training_partitions(subjects):
    subjects=np.array(sorted(map(int,subjects)))
    if len(subjects)<2: raise ValueError('Need at least two fit subjects')
    # Exactly two group-disjoint CV splits, fixed before any held prediction.
    for held in (subjects[::2],subjects[1::2]):
        yield subjects[~np.isin(subjects,held)].tolist(),held.tolist()


def model_key(dataset,node,fit_subjects,protocol_sha256):
    payload=json.dumps(dict(dataset=dataset,node=node,fit_subjects=sorted(fit_subjects),protocol_sha256=protocol_sha256),sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:24]


class ContinuousRocketTransform:
    def __init__(self,kernels=2016):
        from aeon.transformations.collection.convolution_based import MiniRocket
        self.transformer=MiniRocket(n_kernels=kernels,n_jobs=1,random_state=0)

    def fit(self,x,normalized_path):
        # Streaming StandardScaler gives stable channel moments using only fit
        # windows. No held windows enter the random-kernel bias fitting.
        moments=StandardScaler()
        for start in range(0,len(x),BATCH):
            block=np.asarray(x[start:start+BATCH])
            moments.partial_fit(block.transpose(0,2,1).reshape(-1,block.shape[1]))
        self.mean=moments.mean_.astype(np.float32)[None,:,None]
        self.std=np.maximum(np.sqrt(moments.var_),1e-8).astype(np.float32)[None,:,None]
        normalized=np.lib.format.open_memmap(normalized_path,mode='w+',dtype=np.float32,shape=x.shape)
        for start in range(0,len(x),BATCH): normalized[start:start+BATCH]=(x[start:start+BATCH]-self.mean)/self.std
        normalized.flush(); self.transformer.fit(normalized); close_map(normalized)
        return self

    def transform(self,x):
        return np.asarray(self.transformer.transform(((x-self.mean)/self.std).astype(np.float32)),dtype=np.float32)


def join_training_annotations(store):
    path=DATA/store.dataset/'training_views'/store.fold['fold']/'train_annotations.csv'
    labels=pd.read_csv(path)
    labels=labels.set_index('continuous_global_index').loc[store.index.continuous_global_index].reset_index()
    if not np.array_equal(labels.subject,store.index.subject): raise ValueError('Training annotation join mismatch')
    return labels


def fit_positions(store,annotations,subjects):
    if not set(subjects)<=set(store.fold['train']): raise ValueError('Not within outer TRAIN subjects')
    return np.flatnonzero(store.index.subject.isin(subjects).to_numpy() & (annotations.window_kind.to_numpy()=='pure_known'))


def materialize_node(store,positions,node,path):
    cfg=CONFIG[store.dataset]; width=cfg['selected_axes_per_node']; total=len(positions)
    if not total: raise ValueError('No supervised fit windows')
    output=np.lib.format.open_memmap(path,mode='w+',dtype=np.float32,shape=(total,width,cfg['window']))
    for start in range(0,total,BATCH):
        x,_=store.batch(positions[start:start+BATCH]); output[start:start+len(x)]=x[:,node*width:(node+1)*width]
    output.flush(); return output


def transform_and_scale(x,transform,path,scaler=None):
    output=None; fitting=scaler is None
    if fitting: scaler=StandardScaler()
    for start in range(0,len(x),BATCH):
        feature=transform.transform(x[start:start+BATCH])
        if output is None: output=np.lib.format.open_memmap(path,mode='w+',dtype=np.float32,shape=(len(x),feature.shape[1]))
        output[start:start+len(feature)]=feature
        if fitting: scaler.partial_fit(feature)
    for start in range(0,len(x),BATCH): output[start:start+BATCH]=scaler.transform(output[start:start+BATCH])
    output.flush(); return output,scaler


def predict_features(model,features):
    return np.concatenate([model.predict(features[start:start+BATCH]) for start in range(0,len(features),BATCH)])


def ridge_grid_weights(features,y,alphas=ALPHAS):
    """Same RidgeClassifier objective, reuse one float64 Gram across alphas.

    This avoids rereading/centering a large feature matrix seven times. Binary
    target coding and the zero decision threshold match sklearn exactly.
    """
    classes=np.unique(y); p=features.shape[1]
    if len(classes)<2: raise ValueError('Need two classes for ridge selection')
    targets=np.where(y[:,None]==(classes[1:] if len(classes)==2 else classes)[None,:],1.,-1.)
    xmean=np.mean(features,axis=0,dtype=np.float64); ymean=targets.mean(axis=0)
    gram=np.zeros((p,p),np.float64); rhs=np.zeros((p,targets.shape[1]),np.float64)
    for start in range(0,len(features),256):
        x=np.asarray(features[start:start+256],dtype=np.float64)-xmean
        target=targets[start:start+256]-ymean
        gram+=x.T@x; rhs+=x.T@target
    result={}
    for alpha in alphas:
        current=gram.copy(); current.flat[::p+1]+=alpha
        factor=cho_factor(current,lower=True,overwrite_a=True,check_finite=False)
        weights=cho_solve(factor,rhs,overwrite_b=False,check_finite=False)
        result[alpha]=dict(coef=weights.T,intercept=ymean-xmean@weights,classes=classes)
        del current,factor
    return result


def predict_grid_weights(model,features):
    output=[]
    for start in range(0,len(features),BATCH):
        value=np.asarray(features[start:start+BATCH],np.float64)@model['coef'].T+model['intercept']
        index=(value[:,0]>0).astype(int) if len(model['classes'])==2 else value.argmax(axis=1)
        output.append(model['classes'][index])
    return np.concatenate(output)


def select_alpha(store,annotations,fit_subjects,node,scratch,classes):
    """Full transform/scaler refit inside each inner subject split."""
    scratch=Path(scratch); scratch.mkdir(parents=True,exist_ok=True)
    rows=[]; lineage=[]; warnings_log=[]
    for split,(training,held) in enumerate(training_partitions(fit_subjects)):
        train=fit_positions(store,annotations,training); val=fit_positions(store,annotations,held)
        xt_path=scratch/f'cv{split}_xtrain.npy'; xv_path=scratch/f'cv{split}_xheld.npy'
        normalized_path=scratch/f'cv{split}_normalized.npy'; ft_path=scratch/f'cv{split}_ft.npy'; fv_path=scratch/f'cv{split}_fv.npy'
        xt=materialize_node(store,train,node,xt_path); xv=materialize_node(store,val,node,xv_path)
        transform=ContinuousRocketTransform().fit(xt,normalized_path)
        ft,scaler=transform_and_scale(xt,transform,ft_path)
        fv,_=transform_and_scale(xv,transform,fv_path,scaler=scaler)
        y=annotations.endpoint_target.to_numpy(); subjects=store.index.subject.to_numpy()
        candidates=ridge_grid_weights(ft,y[train])
        for alpha in ALPHAS:
            model=candidates[alpha]
            if not np.isfinite(model['coef']).all(): raise ValueError('Nonfinite CV weights')
            prediction=predict_grid_weights(model,fv)
            for subject in held:
                selected=subjects[val]==subject
                score=float(f1_score(y[val][selected],prediction[selected],labels=classes,average='macro',zero_division=0))
                rows.append(dict(split=split,subject=subject,alpha=alpha,macro_f1=score,windows=int(selected.sum())))
            del model
        del candidates
        lineage.append(dict(split=split,fit_subjects=training,held_subjects=held,
            fit_global_window_indices=store.index.continuous_global_index.to_numpy()[train].tolist(),
            held_global_window_indices=store.index.continuous_global_index.to_numpy()[val].tolist(),
            raw_channel_mean=transform.mean.ravel().tolist(),raw_channel_std=transform.std.ravel().tolist(),
            feature_count=int(ft.shape[1]),scaler_fit_rows=int(scaler.n_samples_seen_),
            all_transform_scaler_classifier_fit_only_inner_training=True))
        for array in (xt,xv,ft,fv): close_map(array)
        del xt,xv,ft,fv,transform,scaler
        remove_scratch([xt_path,xv_path,normalized_path,ft_path,fv_path],scratch)
    frame=pd.DataFrame(rows); means=frame.groupby('alpha').macro_f1.mean()
    best=float(means.max()); selected=next(alpha for alpha in ALPHAS if means.loc[alpha]>=best-1e-12)
    return selected,dict(selected_alpha=selected,cv_subject_equal_macro_f1=best,
        alpha_grid=list(ALPHAS),candidate_mean_scores={str(k):float(v) for k,v in means.items()},
        subject_metrics=rows,inner_lineage=lineage,numerical_warnings=warnings_log,
        no_historical_outer_validation_alpha_reused=True,
        cv_solver='cached float64 centered Gram+Cholesky; same RidgeClassifier objective and target coding')


def fit_final(store,annotations,fit_subjects,node,alpha,scratch,classes):
    scratch=Path(scratch); scratch.mkdir(parents=True,exist_ok=True)
    positions=fit_positions(store,annotations,fit_subjects)
    x_path=scratch/'final_x.npy'; normalized_path=scratch/'final_normalized.npy'; f_path=scratch/'final_features.npy'
    x=materialize_node(store,positions,node,x_path)
    transform=ContinuousRocketTransform().fit(x,normalized_path)
    features,scaler=transform_and_scale(x,transform,f_path)
    y=annotations.endpoint_target.to_numpy()[positions]
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        classifier=RidgeClassifier(alpha=alpha,solver='cholesky',copy_X=True).fit(features,y)
    if not np.array_equal(classifier.classes_,classes) or not np.isfinite(classifier.coef_).all():
        raise ValueError('Final classifier has missing classes/nonfinite weights')
    bundle=dict(transform=transform,scaler=scaler,model=classifier,dataset=store.dataset,node=node,
        fit_subjects=sorted(fit_subjects),fit_continuous_global_indices=store.index.continuous_global_index.to_numpy()[positions],
        alpha=float(alpha),training_filter='pure_known windows of fit_subjects only',
        transform_kernels_requested=2016,feature_count=int(features.shape[1]))
    metadata=dict(fit_subjects=sorted(fit_subjects),fit_windows=len(positions),feature_count=int(features.shape[1]),
        class_labels=classes.tolist(),alpha=float(alpha),scaler_fit_rows=int(scaler.n_samples_seen_),
        channel_mean=transform.mean.ravel().tolist(),channel_std=transform.std.ravel().tolist(),
        numerical_warnings=[str(item.message) for item in caught])
    close_map(x); close_map(features); del x,features
    remove_scratch([x_path,normalized_path,f_path],scratch)
    return bundle,metadata


def score_node(store,positions,node,bundle):
    width=CONFIG[store.dataset]['selected_axes_per_node']; result=np.empty((len(positions),12),np.float32)
    if set(store.index.subject.to_numpy()[positions])&set(bundle['fit_subjects']):
        raise ValueError('Cannot label in-sample prediction as OOF')
    for start in range(0,len(positions),BATCH):
        x,_=store.batch(positions[start:start+BATCH]); local=x[:,node*width:(node+1)*width]
        feature=bundle['transform'].transform(local)
        result[start:start+len(x)]=bundle['model'].decision_function(bundle['scaler'].transform(feature)).astype(np.float32)
    if not np.isfinite(result).all(): raise ValueError('Nonfinite independent continuous scores')
    return result
