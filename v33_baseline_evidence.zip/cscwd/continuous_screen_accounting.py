"""Frozen V15 byte and virtual-channel definitions, independent of labels."""
import numpy as np
from causal_score_codec import HEADER

LINKS=((250000,.001),(1000000,.001),(250000,.005))


def physical_resets(subjects,streams,rows,times,stride,seconds=1):
    n=len(rows); reset=np.ones(n,bool)
    reset[1:]=(subjects[1:]!=subjects[:-1])|(streams[1:]!=streams[:-1])|(np.diff(rows)!=stride)|(~np.isclose(np.diff(times),seconds,atol=1e-6,rtol=0))
    return reset


def session_grid(physical,length):
    start=np.arange(len(physical))%length==0; reset=physical|start
    status=reset|(np.arange(len(physical))%length%100==0)
    return reset,start,status


def setup_packets(method_id,waiting):
    quant=HEADER.pack(4,255,0,0)+np.tile([-4.,4.],(3,1)).astype('<f8').tobytes()
    profiles=[HEADER.pack(5,node,0,0)+bytes([method_id,waiting])+int(128).to_bytes(2,'little') for node in range(3)]
    assert len(quant)==62 and sum(map(len,profiles))==54
    # Parse configuration rather than silently assuming untransmitted settings.
    np.testing.assert_array_equal(np.frombuffer(quant[14:],'<f8').reshape(3,2),np.tile([-4.,4.],(3,1)))
    for node,packet in enumerate(profiles):
        assert HEADER.unpack_from(packet)==(5,node,0,0) and packet[14:]==bytes([method_id,waiting,128,0])
    return [quant]+profiles


def latency(times,starts,counts,pre_bytes,pre_messages,post_bytes,post_messages,waiting):
    # FCFS Lindley recurrence in closed vectorized form. All bytes/messages in
    # one transaction become ready at release; feedback follows its output.
    release=times[starts]+waiting
    hold=np.repeat(release,counts)-times
    if np.min(hold)<-1e-5: raise ValueError('Observation grid violates wait budget')
    out={}
    for bitrate,prop in LINKS:
        before=np.asarray(pre_bytes)*8/bitrate+np.asarray(pre_messages)*prop
        after=np.asarray(post_bytes)*8/bitrate+np.asarray(post_messages)*prop
        service=before+after; cumulative=np.cumsum(service)
        end=cumulative+np.maximum.accumulate(release-(cumulative-service))
        emit=end-after
        out[f'latency_{bitrate}_{int(prop*1000)}_ms']=(np.repeat(emit,counts)-times)*1000
    out['imposed_wait_seconds']=np.maximum(0,hold)
    return out


def macro_f1(y,pred,classes):
    return float(np.mean([2*np.sum((y==c)&(pred==c))/max(1,np.sum(y==c)+np.sum(pred==c)) for c in classes]))
