"""V13 label-independent, causal continuous windows and train-only access.

Signals live once per recording. Overlapping windows are materialized lazily.
Raw labels and evaluation annotations are never an input to window selection.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from prepare_pamap2 import ROOT, ACTIVITIES, NODES

OUT=ROOT/'results'/'continuous_training_v13'
CONFIG={
    'pamap2':dict(rate=100,window=200,stride=100,max_carry=10,classes=list(ACTIVITIES),
        nodes=tuple(NODES),channels=sum(NODES.values(),[]),raw_columns=54,
        source_glob='data/pamap2/**/Protocol/subject{subject}.dat',
        time_source='raw timestamp column',selected_axes_per_node=6),
    'mhealth':dict(rate=50,window=100,stride=50,max_carry=0,classes=list(range(1,13)),
        nodes=('chest','ankle','wrist'),channels=[0,1,2,5,6,7,14,15,16],raw_columns=24,
        source_glob='data/mhealth/**/mHealth_subject{subject}.log',
        time_source='row index / 50Hz; physical dropped samples cannot be detected',selected_axes_per_node=3),
}


def time_blocks(times,rate):
    times=np.asarray(times,float)
    if times.ndim!=1: raise ValueError('Expected one-dimensional timestamps')
    if not len(times): return []
    dt=np.diff(times)
    broken=(~np.isfinite(times[:-1]))|(~np.isfinite(times[1:]))|(dt<=0)|(dt>1.5/rate)
    boundaries=np.r_[0,np.flatnonzero(broken)+1,len(times)]
    return [(int(a),int(b)) for a,b in zip(boundaries[:-1],boundaries[1:])]


def causal_windows(signal,times,rate,window,stride,max_carry):
    """All decisions depend on physical order, timestamps and signal quality."""
    signal=np.asarray(signal,np.float32); times=np.asarray(times,float)
    if signal.ndim!=2 or len(signal)!=len(times) or window<1 or stride<1 or max_carry<0:
        raise ValueError('Invalid continuous signal/window specification')
    clean=signal.copy(); clean[~np.isfinite(clean)]=np.nan
    imputed=np.zeros_like(clean,bool); candidates=[]; blocks=time_blocks(times,rate)
    for block,(a,b) in enumerate(blocks):
        if max_carry:
            filled=pd.DataFrame(clean[a:b]).ffill(limit=max_carry).to_numpy(dtype=np.float32)
            imputed[a:b]=~np.isfinite(clean[a:b])&np.isfinite(filled); clean[a:b]=filled
        if b-a>=window:
            candidates.extend((start,block) for start in range(a,b-window+1,stride))
    frame=pd.DataFrame(candidates,columns=['start_row','time_block'])
    if not len(frame):
        frame=pd.DataFrame({key:pd.Series(dtype='int64') for key in ('start_row','time_block','end_row_exclusive','stream_id','local_window_index','imputed_entries')})
        frame['start_time']=pd.Series(dtype=float); frame['end_time']=pd.Series(dtype=float)
        return clean,imputed,frame,dict(candidate_windows=0,dropped_signal_windows=0,time_blocks=len(blocks))
    starts=frame.start_row.to_numpy(dtype=int); ends=starts+window
    bad=(~np.isfinite(clean).all(axis=1))|(~np.isfinite(times))
    prefix=np.r_[0,np.cumsum(bad,dtype=np.int64)]
    valid=prefix[ends]-prefix[starts]==0; dropped=int((~valid).sum())
    frame=frame.loc[valid].reset_index(drop=True); starts=starts[valid]; ends=ends[valid]
    frame['end_row_exclusive']=ends
    frame['start_time']=times[starts]; frame['end_time']=times[ends-1]
    resets=np.r_[True,(np.diff(starts)!=stride)|(np.diff(frame.time_block.to_numpy())!=0)] if len(starts) else np.array([],bool)
    frame['stream_id']=np.cumsum(resets)-1
    frame['local_window_index']=np.arange(len(frame))
    counts=np.r_[0,np.cumsum(imputed.sum(axis=1),dtype=np.int64)]
    frame['imputed_entries']=counts[ends]-counts[starts]
    return clean,imputed,frame,dict(candidate_windows=len(candidates),dropped_signal_windows=dropped,time_blocks=len(blocks))


def annotate_windows(windows,labels,classes):
    """Evaluation-only labels; this function cannot change a window or signal."""
    labels=np.asarray(labels); classes=np.asarray(classes,int)
    starts=windows.start_row.to_numpy(dtype=int); ends=windows.end_row_exclusive.to_numpy(dtype=int)
    counts=[]
    for label in classes:
        prefix=np.r_[0,np.cumsum(labels==label,dtype=np.int64)]
        counts.append(prefix[ends]-prefix[starts])
    matrix=np.stack(counts,axis=1) if len(classes) else np.zeros((len(windows),0),int)
    known=matrix.sum(axis=1); length=ends-starts; best=matrix.argmax(axis=1)
    dominant=np.where(known>0,classes[best],-1)
    maximum=matrix[np.arange(len(windows)),best]
    changes=np.r_[False,labels[1:]!=labels[:-1]]
    prefix=np.r_[0,np.cumsum(changes,dtype=np.int64)]
    inside=prefix[ends]-prefix[starts+1]
    end_label=labels[ends-1]; valid_end=np.isin(end_label,classes)
    result=pd.DataFrame(dict(local_window_index=windows.local_window_index,
        raw_start_label=labels[starts],raw_end_label=end_label,
        endpoint_target=np.where(valid_end,end_label,-1),endpoint_target_known=valid_end,
        dominant_known_label=dominant,known_sample_fraction=known/length,
        dominant_known_fraction=maximum/length,
        window_kind=np.where(known==0,'unknown_only',np.where(maximum==length,'pure_known','mixed')),
        distinct_known_classes=(matrix>0).sum(axis=1),raw_label_changes_inside=inside))
    return result


def label_events(windows,labels,times,rate,classes):
    """Observed annotation edges and unknown bridges; never invent switch times."""
    labels=np.asarray(labels,int); times=np.asarray(times,float); classes=set(map(int,classes))
    boundaries=np.r_[0,np.flatnonzero(labels[1:]!=labels[:-1])+1,len(labels)]
    events=[]; bridges=[]; onsets=[]
    starts=windows.start_row.to_numpy(dtype=int); ends=windows.end_row_exclusive.to_numpy(dtype=int)-1
    previous_known=None
    for run,(a,b) in enumerate(zip(boundaries[:-1],boundaries[1:])):
        a,b=int(a),int(b); current=int(labels[a]); current_known=current in classes
        if run:
            old=int(labels[a-1]); old_known=old in classes
            physical=bool(np.isfinite(times[a-1:a+1]).all() and 0<times[a]-times[a-1]<=1.5/rate)
            kind=('known_to_known' if old_known and current_known else 'known_to_unknown' if old_known else 'unknown_to_known' if current_known else 'unknown_to_unknown')
            if not physical: kind='label_change_across_physical_gap'
            overlaps=np.flatnonzero((starts<a)&(ends>=a))
            events.append(dict(event_row=a,event_time=float(times[a]),old_label=old,new_label=current,
                event_kind=kind,physical_adjacent=physical,containing_window_count=len(overlaps),
                containing_local_window_indices=','.join(map(str,overlaps.tolist()))))
            if current_known and physical:
                eligible=np.flatnonzero((ends>=a)&(ends<b))
                pure=np.flatnonzero((starts>=a)&(ends<b))
                first=int(eligible[0]) if len(eligible) else -1; first_pure=int(pure[0]) if len(pure) else -1
                onsets.append(dict(onset_row=a,onset_time=float(times[a]),activity=current,previous_raw_label=old,
                    onset_kind='direct_annotated_class_change' if old_known else 'annotated_onset_after_unknown',
                    raw_labeled_episode_end_exclusive=b,
                    first_endpoint_local_window_index=first,
                    first_endpoint_observation_delay_seconds=float(times[ends[first]]-times[a]) if first>=0 else None,
                    first_pure_local_window_index=first_pure,
                    first_pure_observation_delay_seconds=float(times[ends[first_pure]]-times[a]) if first_pure>=0 else None,
                    recognition_delay_measured=False))
        if current_known:
            if previous_known is not None:
                old_label,old_start,old_end=previous_known
                gap=a-old_end
                span=times[old_end-1:a+1]; increments=np.diff(span)
                physical=bool(np.isfinite(span).all() and np.all((increments>0)&(increments<=1.5/rate)))
                bridges.append(dict(previous_activity=old_label,next_activity=current,previous_episode_start=old_start,
                    previous_episode_end_exclusive=old_end,next_episode_start=a,unknown_rows=gap,
                    unknown_nominal_duration_seconds=gap/rate,activity_changed=bool(old_label!=current),
                    direct_annotated_transition=bool(gap==0 and old_label!=current and physical),
                    physical_continuity=physical,exact_switch_time_known=bool(gap==0 and old_label!=current and physical)))
            previous_known=(current,a,b)
    eventcols=['event_row','event_time','old_label','new_label','event_kind','physical_adjacent','containing_window_count','containing_local_window_indices']
    onsetcols=['onset_row','onset_time','activity','previous_raw_label','onset_kind','raw_labeled_episode_end_exclusive',
        'first_endpoint_local_window_index','first_endpoint_observation_delay_seconds','first_pure_local_window_index','first_pure_observation_delay_seconds','recognition_delay_measured']
    bridgecols=['previous_activity','next_activity','previous_episode_start','previous_episode_end_exclusive','next_episode_start','unknown_rows',
        'unknown_nominal_duration_seconds','activity_changed','direct_annotated_transition','physical_continuity','exact_switch_time_known']
    return pd.DataFrame(events,columns=eventcols),pd.DataFrame(bridges,columns=bridgecols),pd.DataFrame(onsets,columns=onsetcols)


class TrainingWindowStore:
    """Access only the selected outer fold's explicit training-role index."""
    def __init__(self,dataset,fold,out=OUT):
        if dataset not in CONFIG: raise ValueError('Unknown dataset')
        self.dataset=dataset; self.out=Path(out); self.config=CONFIG[dataset]
        manifest=json.loads((self.out/dataset/'split_manifest.json').read_text(encoding='utf8'))
        matches=[item for item in manifest['folds'] if item['fold']==fold]
        if len(matches)!=1: raise ValueError('Unknown training fold')
        self.fold=matches[0]
        self.index=pd.read_csv(self.out/dataset/'training_views'/fold/'train_windows.csv')
        if not set(self.index.subject)<=set(self.fold['train']): raise ValueError('Non-training subject in training view')
        if set(self.index.subject)&set(self.fold['validation']+self.fold['test']): raise ValueError('Held-out subject exposed')
        self.cache={}

    def __len__(self): return len(self.index)

    def batch(self,positions):
        positions=np.asarray(positions)
        if positions.ndim!=1 or positions.dtype.kind not in 'iu' or np.any(positions<0) or np.any(positions>=len(self)):
            raise ValueError('Invalid training window indices')
        rows=self.index.iloc[positions]; samples=[]
        for row in rows.itertuples(index=False):
            subject=int(row.subject)
            if subject not in self.cache:
                self.cache[subject]=np.load(self.out/self.dataset/'records'/f'subject{subject}'/'signal.npy',mmap_mode='r')
            sample=np.asarray(self.cache[subject][row.start_row:row.end_row_exclusive].T)
            if sample.shape!=(len(self.config['channels']),self.config['window']) or not np.isfinite(sample).all():
                raise ValueError('Invalid persisted training sample')
            samples.append(sample)
        shape=(0,len(self.config['channels']),self.config['window'])
        return (np.stack(samples).astype(np.float32) if samples else np.empty(shape,np.float32)),rows.copy()

    def iter_batches(self,batch_size=64):
        if batch_size<1: raise ValueError('Invalid batch size')
        for start in range(0,len(self),batch_size):
            yield self.batch(np.arange(start,min(start+batch_size,len(self))))

    def close(self):
        for array in self.cache.values():
            mapping=getattr(array,'_mmap',None)
            if mapping is not None: mapping.close()
        self.cache.clear()

    def __enter__(self): return self

    def __exit__(self,*args): self.close()
