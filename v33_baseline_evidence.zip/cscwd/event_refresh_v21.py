"""Simple causal pull controls; no hidden auxiliary score enters a decision."""
import struct
import numpy as np
from numba import njit
from causal_score_codec import HEADER

REQUEST_KIND=240
CANDIDATES=tuple([dict(name=f'drift_t{v:g}',mode=0,threshold=float(np.float32(v)),horizon=16)
                  for v in (.01,.025,.05,.1)]
                 +[dict(name=f'margin_t{v}',mode=1,threshold=float(v),horizon=16) for v in (4,16,32)])

def request_packet(node,window,stamp):
    if node not in (1,2):raise ValueError('Auxiliary node required')
    packet=HEADER.pack(REQUEST_KIND,node,int(window),int(stamp))+b'\x01'
    assert len(packet)==15
    parse_request(packet,node,window,stamp)
    return packet

def parse_request(packet,node,window,stamp):
    if len(packet)!=15 or HEADER.unpack_from(packet)!=(REQUEST_KIND,node,int(window),int(stamp)) or packet[14:]!=b'\x01':
        raise ValueError('Invalid current refresh command')
    return True

@njit(cache=True)
def schedule(q,reset,mode,threshold,horizon=16):
    n=len(q)
    send=np.zeros((n,3),np.bool_)
    requests=np.zeros(n,np.bool_)
    prediction=np.empty(n,np.int16)
    signal=np.full(n,np.nan)
    anchor=0
    for t in range(n):
        refresh=bool(reset[t])
        if not refresh:
            if mode==0:
                value=0.
                for c in range(12):value+=abs(float(q[t,0,c])-float(q[anchor,0,c]))
                value/=(12*255.)
                early=value>=threshold
            else:
                first,second=-1,-1
                for c in range(12):
                    z=int(q[t,0,c])
                    if z>first:first,second=z,first
                    elif z>second:second=z
                value=float(first-second)
                early=value<=threshold
            signal[t]=value
            refresh=early or t-anchor>=horizon
            requests[t]=refresh
        send[t,0]=True
        if refresh:
            send[t,1:]=True
            anchor=t
        best,maximum=0,-1
        for c in range(12):
            value=int(q[t,0,c])+int(q[anchor,1,c])+int(q[anchor,2,c])
            if value>maximum:best,maximum=c,value
        prediction[t]=best
    return send,requests,prediction,signal

def verify(q,reset,policy,result):
    send,requests,pred,signal=result
    assert reset[0] and send[:,0].all() and send[reset].all()
    np.testing.assert_array_equal(send[:,1],send[:,2])
    last=np.maximum.accumulate(np.where(send[:,1],np.arange(len(q)),-1))
    previous=np.r_[0,last[:-1]]
    if policy['mode']==0:
        values=np.abs(q[:,0].astype(np.int16)-q[previous,0].astype(np.int16)).sum(1)/(12*255.)
        early=values>=policy['threshold']
    else:
        ordered=np.sort(q[:,0].astype(np.int16),axis=1)
        values=ordered[:,-1]-ordered[:,-2]
        early=values<=policy['threshold']
    wanted=~reset&(early|(np.arange(len(q))-previous>=policy['horizon']))
    np.testing.assert_allclose(signal[~reset],values[~reset],atol=1e-14,rtol=0)
    np.testing.assert_array_equal(requests,wanted)
    np.testing.assert_array_equal(send[:,1],reset|wanted)
    np.testing.assert_array_equal(pred,np.argmax(q[:,0].astype(int)+q[last,1].astype(int)+q[last,2].astype(int),axis=1))

def select(summary):
    # The caller supplies B-only summaries in the frozen candidate order.
    eligible=[(float(row['bytes_per_window']),i,row['method']) for i,row in enumerate(summary) if row['all_checks_passed']]
    return min(eligible)[2] if eligible else 'complete_fallback'
