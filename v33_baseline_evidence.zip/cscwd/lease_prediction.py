"""V18 paid-information-only selection of the next paired helper deadline."""
import hashlib
import numpy as np
from numba import njit
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from validity_survival import paid_features, logistic
from survival_schedule import feature_one
from causal_score_codec import HEADER

HORIZONS = (1, 3, 7, 15)
KINDS = ('geometric', 'direct', 'survival')


def landmarks(f, training=False):
    segment = np.cumsum(f['reset'])
    current = np.arange(1, len(f['q']))
    current = current[segment[current] == segment[current-1]]
    if training:
        chosen = []
        for subject in np.unique(f['subjects']):
            at = current[f['subjects'][current] == subject]
            if len(at) > 512:
                at = at[np.linspace(0, len(at)-1, 512, dtype=int)]
            chosen.append(at)
        current = np.concatenate(chosen)
    anchor = current-1
    first = np.full(len(current), -1, np.int16)
    observed = np.zeros(len(current), np.int16)
    cache = f['q'][anchor, 1:].astype(np.int32).sum(1)
    for ahead in range(15):
        at = np.flatnonzero(current+ahead < len(f['q']))
        at = at[segment[current[at]] == segment[current[at]+ahead]]
        t = current[at]+ahead
        error = np.argmax(f['q'][t, 0].astype(np.int32)+cache[at], axis=1) != f['reference'][t]
        first[at[(first[at] < 0) & error]] = ahead
        observed[at] = ahead+1
    return dict(x=paid_features(f['q'], current, anchor), first=first, observed=observed,
                subjects=f['subjects'][current], current=current, anchor=anchor)


def fit_logistic(x, y, subjects):
    weights = np.zeros(len(y))
    labels, counts = np.unique(subjects, return_counts=True)
    for subject, count in zip(labels, counts):
        weights[subjects == subject] = len(y)/(len(labels)*count)
    # Exactly constant paid features (in particular age=1) need no variance
    # calculation. Weighted floating point cancellation can otherwise produce
    # a tiny negative variance and a spurious sqrt warning in StandardScaler.
    variable = np.ptp(x, axis=0) > 0
    mean = np.asarray(x[0], np.float64).copy()
    scale = np.ones(x.shape[1], np.float64)
    if variable.any():
        scaler = StandardScaler().fit(x[:, variable], sample_weight=weights)
        mean[variable], scale[variable] = scaler.mean_, scaler.scale_
    standardized = (x-mean)/scale
    assert np.isfinite(standardized).all()
    if len(np.unique(y)) == 1:
        p = float(((weights*y).sum()+.5)/(weights.sum()+1))
        coefficient, intercept, iterations = np.zeros(x.shape[1]), float(np.log(p/(1-p))), 0
        expected = np.full(min(len(y), 1024), p)
    else:
        fitted = LogisticRegression(C=1., solver='lbfgs', max_iter=500).fit(standardized, y, sample_weight=weights)
        coefficient = fitted.coef_[0]/scale
        intercept = float(fitted.intercept_[0]-np.dot(fitted.coef_[0], mean/scale))
        iterations = int(fitted.n_iter_.max())
        assert iterations < 500, 'Fixed iteration limit reached'
        expected = fitted.predict_proba(standardized[:1024])[:, 1]
    actual = logistic(x[:1024]@coefficient+intercept)
    error = float(np.max(np.abs(actual-expected)))
    assert error < 1e-10
    for threshold in (.01, .05, .1):
        threshold = float(np.float32(threshold))
        np.testing.assert_array_equal(actual >= threshold, expected >= threshold)
    return dict(coefficient=coefficient, intercept=intercept, subjects=labels.tolist(),
        rows=len(y), positives=int(y.sum()), iterations=iterations, fold_probability_error=error)


def fit_models(data):
    x, first, observed, subjects = (data[key] for key in ('x', 'first', 'observed', 'subjects'))
    current = fit_logistic(x, (first == 0).astype(int), subjects)
    heads = [current]
    for horizon in HORIZONS[1:]:
        event = (first >= 0) & (first < horizon)
        keep = (observed >= horizon) | event
        heads.append(fit_logistic(x[keep], event[keep].astype(int), subjects[keep]))
    xs, ys, ss = [], [], []
    previous = 0
    for bin_id, horizon in enumerate(HORIZONS):
        event = (first >= previous) & (first < horizon)
        keep = ((first < 0) | (first >= previous)) & ((observed >= horizon) | event)
        onehot = np.zeros((int(keep.sum()), 4))
        onehot[:, bin_id] = 1
        xs.append(np.column_stack([x[keep], onehot]))
        ys.append(event[keep].astype(int))
        ss.append(subjects[keep])
        previous = horizon
    survival = fit_logistic(np.concatenate(xs), np.concatenate(ys), np.concatenate(ss))
    result = {}
    for kind in KINDS:
        if kind == 'geometric':
            matrix = np.tile(current['coefficient'], (4, 1))
            intercept = np.full(4, current['intercept'])
            parameters = np.r_[current['coefficient'], current['intercept']]
            metadata = [current]
        elif kind == 'direct':
            matrix = np.stack([head['coefficient'] for head in heads])
            intercept = np.asarray([head['intercept'] for head in heads])
            parameters = np.column_stack([matrix, intercept]).ravel()
            metadata = heads
        else:
            matrix = np.tile(survival['coefficient'][:52], (4, 1))
            intercept = survival['intercept']+survival['coefficient'][52:]
            parameters = np.r_[survival['coefficient'], survival['intercept']]
            metadata = [survival]
        result[kind] = dict(kind=kind, matrix=matrix, intercept=intercept, parameters=parameters,
            training_subjects=np.unique(subjects).tolist(), heads=metadata)
        assert len(weight_packet(result[kind])) == dict(geometric=454, direct=1726, survival=486)[kind]
    return result


def probabilities(model, x):
    p = logistic(np.atleast_2d(x)@np.asarray(model['matrix']).T+np.asarray(model['intercept']))
    if model['kind'] == 'geometric':
        return 1-(1-p[:, :1])**np.asarray(HORIZONS)[None]
    if model['kind'] == 'direct':
        return np.maximum.accumulate(p, axis=1)
    return 1-np.cumprod(1-p, axis=1)


def weight_packet(model):
    values = np.asarray(model['parameters'], '<f8')
    identifier = hashlib.sha256(values.tobytes()).digest()[:16]
    packet = HEADER.pack(94+KINDS.index(model['kind']), 0, 0, 0)+identifier+values.tobytes()
    np.testing.assert_array_equal(np.frombuffer(packet[30:], '<f8'), values)
    return packet


@njit(cache=True)
def choose_interval(primary, cached, matrix, intercept, mode, threshold):
    x = feature_one(primary, cached, 1)
    remain, previous, interval = 1., 0., 1
    horizons = np.array([1, 3, 7, 15])
    intervals = np.array([2, 4, 8, 16])
    common = 0.
    if mode != 1:
        for c in range(52):
            common += matrix[0, c]*x[c]
    for j in range(4):
        z = intercept[j]+common
        if mode == 1:
            for c in range(52):
                z += matrix[j, c]*x[c]
        p = 1/(1+np.exp(-z)) if z >= 0 else np.exp(z)/(1+np.exp(z))
        if mode == 0:
            risk = 1-(1-p)**horizons[j]
        elif mode == 1:
            risk = max(previous, p)
            previous = risk
        else:
            remain *= 1-p
            risk = 1-remain
        if risk <= threshold:
            interval = intervals[j]
    return interval


@njit(cache=True)
def lease_schedule(q, reset, matrix, intercept, mode, threshold):
    send = np.zeros((len(q), 3), np.bool_)
    send[:, 0] = True
    grants = np.zeros(len(q), np.int16)
    prediction = np.empty(len(q), np.int16)
    anchor, due = 0, -1
    for t in range(len(q)):
        refresh = bool(reset[t])
        if not refresh:
            if due == t:
                refresh = True
            elif t == anchor+1 and due < 0:
                h = choose_interval(q[t, 0], q[anchor], matrix, intercept, mode, threshold)
                grants[t] = h
                due = anchor+h
                refresh = due == t
        if refresh:
            send[t, 1:] = True
            anchor, due = t, -1
        best, winner = -1, 0
        for c in range(12):
            value = int(q[t, 0, c])+int(q[anchor, 1, c])+int(q[anchor, 2, c])
            if value > best:
                best, winner = value, c
        prediction[t] = winner
    return send, grants, prediction


def verify_decisions(f, model, threshold, send, grants):
    n = len(send)
    last = np.maximum.accumulate(np.where(send[:, 1], np.arange(n), -1))
    previous = np.r_[0, last[:-1]]
    t = np.flatnonzero(grants > 0)
    p = probabilities(model, paid_features(f['q'], t, previous[t]))
    expected = np.ones(len(t), int)
    for j, h in enumerate((2, 4, 8, 16)):
        expected[p[:, j] <= threshold] = h
    np.testing.assert_array_equal(expected, grants[t])


def risk_metrics(model, data):
    p = probabilities(model, data['x'])
    rows = []
    for subject in np.unique(data['subjects']):
        for j, h in enumerate(HORIZONS):
            keep = (data['subjects'] == subject) & (data['observed'] >= h)
            y = ((data['first'][keep] >= 0) & (data['first'][keep] < h)).astype(int)
            values = p[keep, j]
            rows.append(dict(subject=int(subject), model=model['kind'], horizon=h, complete_followup=int(keep.sum()),
                right_censored=int((data['subjects'] == subject).sum()-keep.sum()), positives=int(y.sum()),
                auc=float(roc_auc_score(y, values)) if 0 < y.sum() < len(y) else None,
                brier=float(np.mean((values-y)**2)), mean_predicted_risk=float(values.mean()), observed_event_rate=float(y.mean())))
    return rows
