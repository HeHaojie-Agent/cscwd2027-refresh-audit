"""V20 matched S/B/A scores; reuse frozen models, never modify old artifacts."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[name]='1'
import argparse
from datetime import datetime, timezone
import gc
from pathlib import Path
import time
import joblib
import numpy as np
from threadpoolctl import threadpool_limits
from nested_validity_data import ROOT, OLD, read, write, sha, mapped_decision
from continuous_training_data import CONFIG, TrainingWindowStore
from risk_calibration_data import identifier

BASE = ROOT/'results'/'nested_validity_v17r'
HEADS = ROOT/'results'/'risk_only_calibration_v19'
OUT = ROOT/'results'/'matched_calibration_v20'
SCENARIOS = ((1,0),(2,0),(2,1))
DOC = 'CSCWD2027_训练条件匹配校准协议V20.md'


def make_plan(original):
    cases=[]
    needs={}
    jobs={job['id']:job for job in original['jobs']}
    for group in original['groups']:
        for inner in group['inner']:
            s,b,a=inner['fit_subjects'],inner['predict_subjects'],group['controller_held_subjects']
            assert set(s).isdisjoint(b+a) and set(b).isdisjoint(a)
            case=dict(id=group['id']+f'/direction{inner["split"]}',parent_id=group['id'],dataset=group['dataset'],
                outer_fold=group['outer_fold'],group=group['group'],direction=inner['split'],
                fit_subjects=s,calibration_subjects=b,evaluation_subjects=a,model_ids=inner['model_ids'],
                current_head_id=identifier(group['dataset'],-1,s))
            for mid in case['model_ids']:
                job=jobs[mid]
                assert job['fit_subjects']==s
                for subject in b+a:
                    needs.setdefault((mid,subject),dict(model_id=mid,subject=subject,dataset=group['dataset'],
                        node=job['node'],fit_subjects=s,authorized_train_fold=group['outer_fold']))
            cases.append(case)
    return dict(cases=cases,predictions=list(needs.values()))


def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    plan=make_plan(read(BASE/'plan.json'))
    inputs={}
    def add(path):
        inputs[str(path.relative_to(ROOT))]=sha(path)
    for path in (BASE/'plan.json',HEADS/'base_plan.json',BASE/'handoff_complete.json',
                 HEADS/'handoff_complete.json',HEADS/'base_fit_complete.json',ROOT/DOC): add(path)
    for prediction in plan['predictions']:
        directory=BASE/'models'/prediction['model_id']
        complete=read(directory/'complete.json')
        assert sha(directory/'model.joblib')==complete['model_sha256']
        assert complete['signature']['fit_subjects']==prediction['fit_subjects']
        add(directory/'model.joblib'); add(directory/'complete.json')
        source=directory/f'subject{prediction["subject"]}_scores.npz'
        prediction['reuse_path']=str(source.relative_to(ROOT)) if source.exists() else None
        if source.exists():
            meta=read(source.with_suffix('.json'))
            assert sha(source)==meta['score_sha256']
            add(source); add(source.with_suffix('.json'))
    for case in plan['cases']:
        directory=HEADS/'current_heads'/case['current_head_id']
        for stride,offset in SCENARIOS:
            path=directory/f'stride{stride}_offset{offset}.json'
            head=read(path)
            assert head['current_head_fit_subjects']==case['fit_subjects']
            assert set(head['subjects']).isdisjoint(case['calibration_subjects']+case['evaluation_subjects'])
            add(path)
        add(directory/'training_scores_lineage.json')
        add(OLD/case['dataset']/case['outer_fold']/'training_oof_scores.npz')
    sources={name:sha(ROOT/name) for name in ('matched_calibration_data.py','test_matched_calibration.py',DOC,
        'nested_validity_data.py','continuous_training_data.py','continuous_oof_models.py','risk_calibration_data.py')}
    if (OUT/'data_frozen.json').exists():
        assert read(OUT/'plan.json')==plan
        assert read(OUT/'data_inputs.json')==inputs
        assert read(OUT/'data_sources.json')==sources
    else:
        write(OUT/'plan.json',plan); write(OUT/'data_inputs.json',inputs); write(OUT/'data_sources.json',sources)
        write(OUT/'data_frozen.json',dict(client_date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
            new_predictions_started=False,new_base_fits=0,cases=len(plan['cases']),scenarios=3*len(plan['cases']),
            model_subject_predictions=len(plan['predictions']),reused=sum(bool(x['reuse_path']) for x in plan['predictions']),
            missing=sum(not x['reuse_path'] for x in plan['predictions']),sources_sha256=sha(OUT/'data_sources.json'),
            inputs_sha256=sha(OUT/'data_inputs.json')))
    print(read(OUT/'data_frozen.json'),flush=True)


def check(inputs=False):
    for name,value in read(OUT/'data_sources.json').items(): assert sha(ROOT/name)==value,name
    if inputs:
        for name,value in read(OUT/'data_inputs.json').items(): assert sha(ROOT/name)==value,name


def prediction_path(entry):
    return ROOT/entry['reuse_path'] if entry['reuse_path'] else OUT/'new_node_scores'/entry['model_id']/f'subject{entry["subject"]}_scores.npz'


def infer(entry):
    if entry['reuse_path']: return
    target=prediction_path(entry)
    if target.with_suffix('.json').exists():
        assert sha(target)==read(target.with_suffix('.json'))['score_sha256']
        return
    started=time.perf_counter()
    directory=BASE/'models'/entry['model_id']
    bundle=joblib.load(directory/'model.joblib')
    assert bundle['fit_subjects']==entry['fit_subjects'] and entry['subject'] not in bundle['fit_subjects']
    with TrainingWindowStore(entry['dataset'],entry['authorized_train_fold']) as store:
        positions=np.flatnonzero(store.index.subject.to_numpy()==entry['subject'])
        assert len(positions)
        scores=np.empty((len(positions),12),np.float32)
        width=CONFIG[entry['dataset']]['selected_axes_per_node']
        for start in range(0,len(positions),32):
            raw,_=store.batch(positions[start:start+32])
            scores[start:start+len(raw)]=mapped_decision(bundle,raw[:,entry['node']*width:(entry['node']+1)*width])
        ids=store.index.continuous_global_index.to_numpy()[positions]
    assert np.isfinite(scores).all()
    target.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(target,scores=scores,continuous_global_indices=ids)
    write(target.with_suffix('.json'),dict(**entry,score_sha256=sha(target),model_sha256=sha(directory/'model.joblib'),
        windows=len(scores),elapsed_seconds=time.perf_counter()-started))
    print(f'V20 new score {entry["dataset"]} node{entry["node"]} subject{entry["subject"]} {len(scores)} windows {time.perf_counter()-started:.2f}s',flush=True)
    del bundle,scores
    gc.collect()


def assemble(case,role,lookup):
    subjects=case['calibration_subjects'] if role=='calibration' else case['evaluation_subjects']
    target=OUT/'score_views'/case['id']/f'{role}.npz'
    if target.with_suffix('.json').exists():
        assert sha(target)==read(target.with_suffix('.json'))['sha256']
        return
    template=OLD/case['dataset']/case['outer_fold']/'training_oof_scores.npz'
    with np.load(template) as old:
        keep=np.isin(old['subjects'],subjects)
        arrays={key:old[key] if key=='classes' else old[key][keep] for key in old.files
                if key not in ('scores','reference_prediction')}
    scores=np.empty((int(keep.sum()),3,12),np.float32)
    lineage=[]
    for node,mid in enumerate(case['model_ids']):
        for subject in subjects:
            path=prediction_path(lookup[(mid,subject)])
            at=np.flatnonzero(arrays['subjects']==subject)
            with np.load(path) as saved:
                np.testing.assert_array_equal(arrays['continuous_global_indices'][at],saved['continuous_global_indices'])
                scores[at,node]=saved['scores']
            lineage.append(dict(node=node,subject=subject,path=str(path.relative_to(ROOT)),sha256=sha(path)))
    target.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(target,scores=scores,**arrays)
    write(target.with_suffix('.json'),dict(sha256=sha(target),case=case,role=role,template_sha256=sha(template),node_scores=lineage))


def run(limit=None):
    check(True)
    plan=read(OUT/'plan.json')
    for i,entry in enumerate(plan['predictions']):
        infer(entry)
        if limit and i+1>=limit:return
    lookup={(x['model_id'],x['subject']):x for x in plan['predictions']}
    for i,case in enumerate(plan['cases']):
        for role in ('calibration','evaluation'):assemble(case,role,lookup)
        print(f'V20 assembled {i+1}/{len(plan["cases"])}',flush=True)
    write(OUT/'data_complete.json',dict(directions=len(plan['cases']),new_base_model_fits=0,
        score_views=2*len(plan['cases']),completed_utc=datetime.now(timezone.utc).isoformat()))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--limit',type=int)
    args=parser.parse_args()
    with threadpool_limits(limits=1):prepare() if args.prepare_only else run(args.limit)
