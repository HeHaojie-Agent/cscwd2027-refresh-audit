"""V17 strictly nested TRAIN-role base scores for held controller subjects."""
import argparse
import hashlib
import json
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
from sklearn.linear_model import RidgeClassifier
from threadpoolctl import threadpool_limits

from continuous_training_data import TrainingWindowStore, CONFIG, OUT as DATA
from continuous_oof_models import (join_training_annotations, fit_positions, select_alpha, materialize_node,
    ContinuousRocketTransform, transform_and_scale, close_map, remove_scratch, BATCH)

ROOT = Path(__file__).resolve().parent
OLD = ROOT/'results'/'continuous_oof_v14'
OUT = ROOT/'results'/'nested_validity_v17'
BASE_SOURCES = ('nested_validity_data.py', 'continuous_oof_models.py', 'continuous_training_data.py',
                'prepare_pamap2.py', 'run_pamap2_baselines.py')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def model_id(dataset, node, fit):
    return hashlib.sha256(json.dumps([dataset, node, sorted(fit), 'v17-nested-open-class-v1']).encode()).hexdigest()[:24]


def make_plan(groups):
    planned, jobs = [], {}
    for group in groups:
        dataset, fold = group['dataset'], group['outer_fold']
        held, training = sorted(group['predict_subjects']), sorted(group['fit_subjects'])
        identifier = f'{dataset}/{fold}/group_{group["group"]}'
        entry = dict(id=identifier, dataset=dataset, outer_fold=fold, group=group['group'],
                     controller_train_subjects=training, controller_held_subjects=held, inner=[])
        for split in range(2):
            predict = training[split::2]
            fit = training[1-split::2]
            assert not set(fit) & set(predict+held)
            references = []
            for node in range(3):
                key = model_id(dataset, node, fit)
                if key not in jobs:
                    jobs[key] = dict(id=key, dataset=dataset, node=node, fit_subjects=fit,
                                     canonical_train_fold=fold, predictions={})
                for subject in predict:
                    jobs[key]['predictions'].setdefault(str(subject), fold)
                references.append(key)
            entry['inner'].append(dict(split=split, fit_subjects=fit, predict_subjects=predict, model_ids=references))
        planned.append(entry)
    return dict(groups=planned, jobs=list(jobs.values()))


def freeze_design():
    OUT.mkdir(parents=True, exist_ok=True)
    plan = make_plan(read(DATA/'training_oof_refit_plan.json')['groups'])
    protocol = dict(version='nested_validity_v17', client_date='2026-10-18',
        document_sha256=sha(ROOT/'CSCWD2027_严格嵌套失效时间预测协议V17.md'),
        controller_holdout='V14 subject groups; train S minus A; inner two alternating sorted subject groups',
        score_quantization='fixed [-4,4], uint8 ties-to-even; absent trained classes score -4',
        prediction_bins=[1, 2, 4, 8, 16], landmark_ages=[1, 2, 4, 8, 16], max_training_landmarks_per_subject_age=128,
        primary_node=0, primary_policy='survival_next2_threshold0.01_maxage16',
        probability_thresholds=[.01, .05, .1], fixed_controller_C=1.,
        no_new_validation=True, no_new_test=True)
    if (OUT/'protocol.json').exists():
        assert read(OUT/'protocol.json') == protocol
        assert read(OUT/'plan.json') == plan
    else:
        write(OUT/'protocol.json', protocol)
        write(OUT/'plan.json', plan)
        write(OUT/'design_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
              client_date='2026-10-18', protocol_sha256=sha(OUT/'protocol.json'), plan_sha256=sha(OUT/'plan.json')))
    return plan


def signature(store, annotations, fit, node):
    at = fit_positions(store, annotations, fit)
    return dict(fit_subjects=sorted(fit), node=node, windows=len(at),
                window_ids_sha256=hashlib.sha256(store.index.continuous_global_index.to_numpy()[at].astype('<i8').tobytes()).hexdigest(),
                labels_sha256=hashlib.sha256(annotations.endpoint_target.to_numpy()[at].astype('<i8').tobytes()).hexdigest())


def prepare():
    plan = freeze_design()
    lock = {name: sha(ROOT/name) for name in BASE_SOURCES}
    if (OUT/'base_source_lock.json').exists():
        assert read(OUT/'base_source_lock.json') == lock
        return
    paths = [DATA/'training_oof_refit_plan.json', OLD/'protocol.json', OLD/'source_lock.json',
             OLD/'independent_verification.json', OLD/'readiness.json']
    for dataset in CONFIG:
        paths.append(DATA/dataset/'split_manifest.json')
        for fold in read(DATA/dataset/'split_manifest.json')['folds']:
            paths += [DATA/dataset/'training_views'/fold['fold']/name for name in ('train_windows.csv', 'train_annotations.csv')]
        for record in sorted((DATA/dataset/'records').glob('subject*')):
            paths += [record/name for name in ('signal.npy', 'window_index.csv', 'annotated_onsets.csv')]
    reused = []
    for group in plan['groups']:
        directory = OLD/group['id']
        old = read(directory/'complete.json')
        refs = read(directory/'models.json')
        assert sorted(old['plan']['fit_subjects']) == group['controller_train_subjects']
        assert sorted(old['plan']['predict_subjects']) == group['controller_held_subjects']
        for filename, value in old['files_sha256'].items():
            assert sha(directory/filename) == value
        paths += [directory/name for name in ('complete.json', 'models.json', 'training_oof_scores.npz')]
        for ref in refs:
            assert sorted(ref['fit_subjects']) == group['controller_train_subjects']
            model = OLD/ref['model_path']
            assert sha(model) == ref['model_sha256']
            selection = read(OLD/ref['selection_path'])
            for cv in selection['inner_lineage']:
                assert set(cv['fit_subjects']+cv['held_subjects']) <= set(group['controller_train_subjects'])
                assert not set(cv['fit_subjects']+cv['held_subjects']) & set(group['controller_held_subjects'])
            paths += list(model.parent.glob('*.json'))+[model]
            reused.append(dict(group=group['id'], node=ref['node_index'], model_sha256=ref['model_sha256'],
                               fit_subjects=ref['fit_subjects'], excluded_controller_subjects=group['controller_held_subjects']))
    write(OUT/'inputs.json', {str(path.relative_to(ROOT)): sha(path) for path in sorted(set(paths))})
    write(OUT/'evaluation_reuse_audit.json', dict(references=reused, count=len(reused), all_controller_held_subjects_excluded=True))
    write(OUT/'base_source_lock.json', lock)
    write(OUT/'base_implementation_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
          source_lock_sha256=sha(OUT/'base_source_lock.json'), input_sha256=sha(OUT/'inputs.json')))


def assert_frozen(inputs=False):
    freeze_design()
    for name, value in read(OUT/'base_source_lock.json').items():
        assert sha(ROOT/name) == value, name
    for version, lockname in [('continuous_oof_v14', 'source_lock.json'), ('continuous_collaboration_v15', 'source_lock.json'),
                              ('collaboration_validity_v16', 'source_lock.json')]:
        for name, value in read(ROOT/'results'/version/lockname).items():
            assert sha(ROOT/name) == value, name
    if inputs:
        for name, value in read(OUT/'inputs.json').items():
            assert sha(ROOT/name) == value, name


def fit_open_classes(store, annotations, fit, node, alpha, scratch):
    scratch = Path(scratch)
    positions = fit_positions(store, annotations, fit)
    paths = [scratch/name for name in ('final_x.npy', 'final_norm.npy', 'final_features.npy')]
    x = materialize_node(store, positions, node, paths[0])
    transform = ContinuousRocketTransform().fit(x, paths[1])
    features, scaler = transform_and_scale(x, transform, paths[2])
    y = annotations.endpoint_target.to_numpy()[positions]
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        classifier = RidgeClassifier(alpha=alpha, solver='cholesky', copy_X=True).fit(features, y)
    bundle = dict(transform=transform, scaler=scaler, model=classifier, dataset=store.dataset, node=node,
                  fit_subjects=sorted(fit), fit_continuous_global_indices=store.index.continuous_global_index.to_numpy()[positions],
                  class_slots=np.asarray(CONFIG[store.dataset]['classes']), absent_class_score=-4., alpha=float(alpha))
    assert set(classifier.classes_) <= set(bundle['class_slots'])
    assert np.isfinite(classifier.coef_).all()
    metadata = dict(fit_subjects=sorted(fit), fit_windows=len(positions), alpha=float(alpha),
                    trained_classes=classifier.classes_.tolist(), missing_classes=sorted(set(bundle['class_slots'])-set(classifier.classes_)),
                    scaler_fit_rows=int(scaler.n_samples_seen_), warnings=[str(w.message) for w in caught])
    metadata['missing_classes'] = [int(x) for x in metadata['missing_classes']]
    close_map(x)
    close_map(features)
    del x, features
    remove_scratch(paths, scratch)
    return bundle, metadata


def mapped_decision(bundle, x):
    features = bundle['transform'].transform(x)
    raw = bundle['model'].decision_function(bundle['scaler'].transform(features))
    if raw.ndim == 1:
        raw = np.column_stack([-raw, raw])
    result = np.full((len(x), 12), -4., np.float32)
    for column, label in enumerate(bundle['model'].classes_):
        slot = int(np.flatnonzero(bundle['class_slots'] == label)[0])
        result[:, slot] = raw[:, column].astype(np.float32)
    return result


def fit_job(job):
    directory = OUT/'models'/job['id']
    directory.mkdir(parents=True, exist_ok=True)
    complete = directory/'complete.json'
    begun = time.perf_counter()
    with TrainingWindowStore(job['dataset'], job['canonical_train_fold']) as store:
        annotations = join_training_annotations(store)
        sig = signature(store, annotations, job['fit_subjects'], job['node'])
        if complete.exists():
            meta = read(complete)
            assert meta['signature'] == sig
            assert sha(directory/'model.joblib') == meta['model_sha256']
        else:
            scratch = directory/'scratch'
            scratch.mkdir(exist_ok=True)
            checkpoint = directory/'selection_complete.json'
            if checkpoint.exists():
                state = read(checkpoint)
                assert state['signature'] == sig and sha(directory/'selection.json') == state['sha256']
                selection = read(directory/'selection.json')
                alpha = selection['selected_alpha']
            else:
                alpha, selection = select_alpha(store, annotations, job['fit_subjects'], job['node'], scratch,
                                                 np.asarray(CONFIG[job['dataset']]['classes']))
                write(directory/'selection.json', selection)
                write(checkpoint, dict(signature=sig, sha256=sha(directory/'selection.json')))
            bundle, fit = fit_open_classes(store, annotations, job['fit_subjects'], job['node'], alpha, scratch)
            joblib.dump(bundle, directory/'model.joblib', compress=0)
            write(directory/'final_fit.json', fit)
            write(complete, dict(signature=sig, job=job, model_sha256=sha(directory/'model.joblib'),
                  selection_sha256=sha(directory/'selection.json'), final_fit_sha256=sha(directory/'final_fit.json'),
                  source_lock_sha256=sha(OUT/'base_source_lock.json'), elapsed_fit_seconds=time.perf_counter()-begun))
            del bundle
    bundle = joblib.load(directory/'model.joblib')
    for subject_text, fold in job['predictions'].items():
        subject = int(subject_text)
        target = directory/f'subject{subject}_scores.npz'
        done = target.with_suffix('.json')
        if done.exists():
            assert sha(target) == read(done)['score_sha256']
            continue
        assert subject not in bundle['fit_subjects']
        with TrainingWindowStore(job['dataset'], fold) as store:
            positions = np.flatnonzero(store.index.subject.to_numpy() == subject)
            scores = np.empty((len(positions), 12), np.float32)
            for start in range(0, len(positions), BATCH):
                x, _ = store.batch(positions[start:start+BATCH])
                width = CONFIG[job['dataset']]['selected_axes_per_node']
                scores[start:start+len(x)] = mapped_decision(bundle, x[:, job['node']*width:(job['node']+1)*width])
            ids = store.index.continuous_global_index.to_numpy()[positions]
        assert np.isfinite(scores).all()
        np.savez_compressed(target, scores=scores, continuous_global_indices=ids)
        write(done, dict(subject=subject, authorized_train_fold=fold, fit_subjects=bundle['fit_subjects'],
              model_sha256=sha(directory/'model.joblib'), score_sha256=sha(target), windows=len(scores)))
    print(f'V17 base {job["dataset"]} node{job["node"]} fit={job["fit_subjects"]} targets={len(job["predictions"])} elapsed={time.perf_counter()-begun:.1f}s', flush=True)


def assemble(dataset):
    for group in [g for g in read(OUT/'plan.json')['groups'] if g['dataset'] == dataset]:
        target = OUT/'groups'/group['id']
        done = target/'complete.json'
        if done.exists():
            assert sha(target/'training_scores.npz') == read(done)['train_sha256']
            continue
        with np.load(OLD/dataset/group['outer_fold']/'training_oof_scores.npz', allow_pickle=False) as old:
            keep = np.isin(old['subjects'], group['controller_train_subjects'])
            data = {k: old[k] if k == 'classes' else old[k][keep] for k in old.files if k not in ('scores', 'reference_prediction')}
        scores = np.empty((int(keep.sum()), 3, 12), np.float32)
        references = []
        for inner in group['inner']:
            for node, key in enumerate(inner['model_ids']):
                assert not set(inner['fit_subjects']) & set(group['controller_held_subjects']+inner['predict_subjects'])
                for subject in inner['predict_subjects']:
                    path = OUT/'models'/key/f'subject{subject}_scores.npz'
                    at = np.flatnonzero(data['subjects'] == subject)
                    with np.load(path, allow_pickle=False) as saved:
                        np.testing.assert_array_equal(saved['continuous_global_indices'], data['continuous_global_indices'][at])
                        scores[at, node] = saved['scores']
                    references.append(dict(subject=subject, node=node, model_id=key,
                                           fit_subjects=inner['fit_subjects'], scores_sha256=sha(path)))
        target.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(target/'training_scores.npz', scores=scores, **data)
        write(target/'lineage.json', dict(plan=group, training_score_references=references,
              evaluation_scores=str((OLD/group['id']/'training_oof_scores.npz').relative_to(ROOT)),
              evaluation_scores_sha256=sha(OLD/group['id']/'training_oof_scores.npz')))
        write(done, dict(train_sha256=sha(target/'training_scores.npz'), lineage_sha256=sha(target/'lineage.json'),
              training_windows=len(scores), held_subjects=group['controller_held_subjects'],
              all_controller_held_subjects_excluded_from_training_scores=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze-design', action='store_true')
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--dataset', choices=tuple(CONFIG))
    parser.add_argument('--threads', type=int, default=2)
    args = parser.parse_args()
    if args.freeze_design:
        plan = freeze_design()
        print(json.dumps(dict(controller_groups=len(plan['groups']), new_node_models=len(plan['jobs']))))
    elif args.prepare_only:
        prepare()
        print('V17 nested base inputs and implementation frozen')
    else:
        assert 1 <= args.threads <= 2
        assert_frozen(inputs=True)
        with threadpool_limits(limits=args.threads):
            for job in read(OUT/'plan.json')['jobs']:
                if args.dataset is None or job['dataset'] == args.dataset:
                    fit_job(job)
            for dataset in ([args.dataset] if args.dataset else CONFIG):
                assemble(dataset)
        write(OUT/'base_fit_complete.json', dict(jobs_completed=len(list((OUT/'models').glob('*/complete.json'))),
              groups_completed=len(list((OUT/'groups').glob('*/*/*/complete.json'))),
              matrix_threads=args.threads, no_new_validation=True, no_new_test=True))
