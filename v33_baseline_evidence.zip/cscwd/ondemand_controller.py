"""Packet-based requested-only inference and training-only collaboration policy.

The controller never receives a matrix of future node scores. Cached responders
are an offline evaluation adapter; ModelResponder computes only requested rows.
"""
from __future__ import annotations
import struct
import time
from dataclasses import dataclass
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from ondemand_protocol import NODES,HEADER_BYTES,HEARTBEAT_WINDOWS
from run_pamap2_baselines import CLASSES,NODE_SLICES,decision

STATUS,REQUEST,SCORE=1,2,3
HEADER=struct.Struct('<BBIQ')

def header(kind,node,window,timestamp):
    if kind not in (STATUS,REQUEST,SCORE) or not 0<=node<3:
        raise ValueError('Invalid message kind/node')
    return HEADER.pack(kind,node,int(window),int(timestamp))

def unpack(packet,kind,node,window,timestamp,payload_bytes):
    if len(packet)!=HEADER_BYTES+payload_bytes:
        raise ValueError('Invalid packet length')
    actual=HEADER.unpack_from(packet)
    if actual!=(kind,node,int(window),int(timestamp)):
        raise ValueError('Wrong message type, node, window or timestamp')
    return packet[HEADER_BYTES:]

@dataclass
class ScoreCodec:
    ranges:np.ndarray

    def __post_init__(self):
        self.ranges=np.asarray(self.ranges,dtype=np.float64)
        if self.ranges.shape!=(3,2) or not np.isfinite(self.ranges).all() or np.any(self.ranges[:,1]<=self.ranges[:,0]):
            raise ValueError('Expected finite increasing ranges for three nodes')

    @classmethod
    def fit(cls,scores):
        ranges=np.asarray([[scores[:,n].min(),scores[:,n].max()] for n in range(3)],dtype=np.float64)
        ranges[:,1]=np.maximum(ranges[:,1],ranges[:,0]+1e-8)
        return cls(ranges)

    def encode(self,node,score):
        score=np.asarray(score,dtype=np.float32)
        if score.shape[-1]!=len(CLASSES) or not np.isfinite(score).all():
            raise ValueError('Nonfinite or wrong-sized node scores')
        lo,hi=self.ranges[node]
        return np.rint(np.clip((score-lo)/(hi-lo),0,1)*255).astype(np.uint8)

    def decode(self,node,payload):
        encoded=np.frombuffer(payload,dtype=np.uint8) if isinstance(payload,bytes) else np.asarray(payload,dtype=np.uint8)
        if encoded.shape[-1]!=len(CLASSES):
            raise ValueError('Wrong score payload length')
        lo,hi=self.ranges[node]
        return (encoded.astype(np.float64)/255*(hi-lo)+lo).astype(np.float32)

    def convert(self,scores):
        return np.stack([self.decode(n,self.encode(n,scores[:,n])) for n in range(3)],axis=1)

    def configuration_packet(self):
        """Once-per-session codec bounds, separate from per-window messages."""
        return HEADER.pack(4,255,0,0)+self.ranges.astype('<f8').tobytes()

    @classmethod
    def from_configuration_packet(cls,packet):
        if len(packet)!=62 or HEADER.unpack_from(packet)!=(4,255,0,0):
            raise ValueError('Invalid quantizer configuration packet')
        return cls(np.frombuffer(packet[HEADER_BYTES:],dtype='<f8').reshape(3,2).copy())

class CachedResponder:
    """Private score cache. The only score accessor is a requested node response."""
    def __init__(self,scores,available,codec,windows=None,timestamps=None):
        self._scores=np.asarray(scores,dtype=np.float32)
        self._available=np.asarray(available,dtype=bool)
        self.codec=codec
        self.windows=np.arange(len(scores),dtype=np.uint32) if windows is None else np.asarray(windows,dtype=np.uint32)
        self.timestamps=np.zeros(len(scores),dtype=np.uint64) if timestamps is None else np.asarray(timestamps,dtype=np.uint64)
        if self._available.shape!=(len(scores),3):
            raise ValueError('Availability shape mismatch')
        self.evaluations=np.zeros((len(scores),3),dtype=np.int8)
        self.node_wall_ns=np.zeros(3,dtype=np.int64)
        self.status_events=[[] for _ in range(len(scores))]
        for i in range(len(scores)):
            for n in range(3):
                if i==0 or i%HEARTBEAT_WINDOWS==0 or self._available[i,n]!=self._available[i-1,n]:
                    self.status_events[i].append(header(STATUS,n,self.windows[i],self.timestamps[i])+bytes([int(self._available[i,n])]))

    def beacons(self):
        return self.status_events

    def _evaluate(self,node,indices):
        return self._scores[indices,node]

    def responses(self,node,indices,requests=None):
        indices=np.asarray(indices,dtype=int)
        if requests is not None:
            if len(requests)!=len(indices):
                raise ValueError('Request count mismatch')
            for i,p in zip(indices,requests):
                unpack(p,REQUEST,node,self.windows[i],self.timestamps[i],0)
        valid=self._available[indices,node]
        active=indices[valid]
        started=time.perf_counter_ns()
        score=self._evaluate(node,active) if len(active) else np.empty((0,len(CLASSES)),dtype=np.float32)
        self.node_wall_ns[node]+=time.perf_counter_ns()-started
        encoded=self.codec.encode(node,score)
        self.evaluations[active,node]+=1
        output=[]
        offset=0
        for i,ok in zip(indices,valid):
            if ok:
                output.append(header(SCORE,node,self.windows[i],self.timestamps[i])+encoded[offset].tobytes())
                offset+=1
            else:
                output.append(None)
        return output

class ModelResponder(CachedResponder):
    """Compute node features only for the requested windows, on the local host."""
    def __init__(self,x,bundles,available,codec,windows=None,timestamps=None,node_names=None,node_slices=None):
        super().__init__(np.zeros((len(x),3,len(CLASSES)),dtype=np.float32),available,codec,windows,timestamps)
        self._x=x
        self._bundles=bundles
        self.node_names=NODES if node_names is None else tuple(node_names)
        self.node_slices=NODE_SLICES if node_slices is None else node_slices

    def _evaluate(self,node,indices):
        name=self.node_names[node]
        return decision(self._bundles[name],self._x[indices,self.node_slices[name],:])

def features(observed,received,available):
    observed=np.asarray(observed,dtype=np.float32)
    received=np.asarray(received,dtype=bool)
    available=np.asarray(available,dtype=bool)
    clean=np.where(received[:,:,None],observed,0)
    count=received.sum(axis=1)
    pooled=clean.sum(axis=1)/np.maximum(count[:,None],1)
    sorted_nodes=np.sort(clean,axis=2)
    margins=(sorted_nodes[:,:,-1]-sorted_nodes[:,:,-2])*received
    sorted_pool=np.sort(pooled,axis=1)
    margin=sorted_pool[:,-1]-sorted_pool[:,-2]
    winner=pooled.argmax(axis=1)
    disagreement=((clean.argmax(axis=2)!=winner[:,None])&received).sum(axis=1)/np.maximum(count,1)
    return np.concatenate([clean.reshape(len(clean),-1),received,available,pooled,margins,
                           margin[:,None],disagreement[:,None],count[:,None]/3],axis=1).astype(np.float32)

def mask_bits(values):
    return np.sum(values.astype(np.uint8)*np.array([1,2,4],dtype=np.uint8),axis=1).astype(np.uint8)

def from_mask(mask,n):
    return np.broadcast_to([(mask>>k)&1 for k in range(3)],(n,3)).astype(bool).copy()

class CollaborationPolicy:
    def __init__(self,params,classes=None,node_names=None):
        self.params=params
        self.classes=CLASSES.copy() if classes is None else np.asarray(classes,dtype=np.int32)
        self.node_names=NODES if node_names is None else tuple(node_names)
        if len(self.classes)!=12 or len(self.node_names)!=3:
            raise ValueError('This wire protocol requires 12 classes and three nodes')

    def fit(self,oof,y,subjects,node_costs):
        self.codec=ScoreCodec.fit(oof)
        score=self.codec.convert(oof)
        target=np.searchsorted(self.classes,y)
        self.node_costs=np.asarray(node_costs,dtype=float)
        self.relative_costs=self.node_costs/np.mean(self.node_costs)
        unique=np.unique(subjects)
        weight=np.asarray([1/np.sum(subjects==s) for s in subjects],dtype=np.float64)
        weight/=weight.mean()
        quality=[np.mean([np.mean(score[subjects==s,n].argmax(axis=1)==target[subjects==s]) for s in unique]) for n in range(3)]
        self.order=tuple(sorted(range(3),key=lambda n:(-quality[n],n)))
        self.training_node_accuracy=quality
        risk_x=[];risk_y=[];risk_w=[]
        gain_x=[];gain_y=[];gain_w=[]
        for availability in range(1,8):
            available=from_mask(availability,len(score))
            for state in range(1,8):
                if state&availability!=state:
                    continue
                received=from_mask(state,len(score))
                observed=np.where(received[:,:,None],score,0)
                f=features(observed,received,available)
                pooled=observed.sum(axis=1)/received.sum(axis=1)[:,None]
                wrong=(pooled.argmax(axis=1)!=target).astype(np.float32)
                risk_x.append(f);risk_y.append(wrong);risk_w.append(weight)
                for candidate in range(3):
                    if not available[0,candidate] or received[0,candidate]:
                        continue
                    after=(observed.sum(axis=1)+score[:,candidate])/(received.sum(axis=1)+1)[:,None]
                    gain=wrong-(after.argmax(axis=1)!=target).astype(np.float32)
                    identity=np.broadcast_to(np.eye(3,dtype=np.float32)[candidate],(len(score),3))
                    gain_x.append(np.concatenate([f,identity],axis=1));gain_y.append(gain);gain_w.append(weight)
        self.risk=HistGradientBoostingRegressor(**self.params).fit(np.concatenate(risk_x),np.concatenate(risk_y),sample_weight=np.concatenate(risk_w))
        del risk_x,risk_y,risk_w
        self.gain=HistGradientBoostingRegressor(**self.params).fit(np.concatenate(gain_x),np.concatenate(gain_y),sample_weight=np.concatenate(gain_w))
        self.training_summary={'OOF_windows':len(oof),'training_subjects':unique.tolist(),
                               'risk_states_per_window':19,'gain_actions_per_window':15,
                               'initial_node_order':[self.node_names[n] for n in self.order],
                               'node_accuracy_subject_equal':quality,
                               'codec_ranges':self.codec.ranges.tolist()}
        return self

    def evaluate(self,observed,received,available,indices=None,cache=None):
        count=len(observed)
        q=np.zeros(count,dtype=np.float32)
        gains=np.zeros((count,3),dtype=np.float32)
        if cache is None:
            f=features(observed,received,available)
            q=np.clip(self.risk.predict(f),0,1).astype(np.float32)
            for node in range(3):
                identity=np.broadcast_to(np.eye(3,dtype=np.float32)[node],(count,3))
                gains[:,node]=self.gain.predict(np.concatenate([f,identity],axis=1))
            return q,gains
        # Cache only predictions already made from observed score states. A
        # cache is scoped to one dataset/provider stream; it never holds scores.
        rb=mask_bits(received);ab=mask_bits(available)
        keys=ab.astype(np.int16)*8+rb
        indices=np.asarray(indices)
        for key in np.unique(keys):
            positions=np.flatnonzero(keys==key)
            source=indices[positions]
            if int(key) not in cache:
                cache[int(key)]={}
            store=cache[int(key)]
            missing=[j for j,i in enumerate(source) if int(i) not in store]
            if missing:
                chosen=positions[missing]
                aq,ag=self.evaluate(observed[chosen],received[chosen],available[chosen])
                for local,j in enumerate(missing):
                    store[int(source[j])]=(aq[local],ag[local].copy())
            for j,position in enumerate(positions):
                q[position],gains[position]=store[int(source[j])]
        return q,gains

def run_controller(provider,policy,budget=165,max_evaluations=3,mode='adaptive',
                   risk_threshold=0.15,gain_penalty=0.02,margin_threshold=0.1,
                   fixed_nodes=None,cache=None,trace_limit=0,selection_rule=None,evaluation_limits=None):
    if budget<45 or max_evaluations<0 or max_evaluations>3:
        raise ValueError('Require byte budget >=45 and evaluation limit 0..3')
    allowed_modes={'adaptive','risk_only','gain_only','margin','random','fixed_push','selection'}
    if mode not in allowed_modes:
        raise ValueError('Unknown controller mode')
    n=len(provider.windows)
    limits=np.full(n,max_evaluations,dtype=np.int8) if evaluation_limits is None else np.asarray(evaluation_limits)
    if limits.shape!=(n,) or np.any(limits<0) or np.any(limits>max_evaluations) or np.any(limits!=limits.astype(int)):
        raise ValueError('Invalid per-window evaluation limits')
    if mode=='selection' and selection_rule is None:
        raise ValueError('Selection mode requires an observed-evidence selector')
    classes=getattr(policy,'classes',CLASSES)
    node_names=getattr(policy,'node_names',NODES)
    observed=np.zeros((n,3,len(CLASSES)),dtype=np.float32)
    received=np.zeros((n,3),dtype=bool)
    attempted=np.zeros((n,3),dtype=bool)
    available=np.zeros((n,3),dtype=bool)
    status_bytes=np.zeros(n,dtype=np.int32)
    request_bytes=np.zeros(n,dtype=np.int32)
    response_bytes=np.zeros(n,dtype=np.int32)
    attempts=np.zeros(n,dtype=np.int8)
    stop=np.zeros(n,dtype=np.int8)
    traces=[]
    if mode!='fixed_push':
        current=np.zeros(3,dtype=bool)
        for i,packets in enumerate(provider.beacons()):
            for packet in packets:
                kind,node,window,timestamp=HEADER.unpack_from(packet)
                data=unpack(packet,STATUS,node,provider.windows[i],provider.timestamps[i],1)
                if data[0] not in (0,1):
                    raise ValueError('Invalid availability status')
                status_bytes[i]+=len(packet)
                current[node]=bool(data[0])
                if i<trace_limit:
                    traces.append({'index':i,'kind':'status','node':node_names[node],'bytes':len(packet),'hex':packet.hex()})
            if status_bytes[i]>budget:
                raise ValueError('Status stream exceeds byte budget')
            available[i]=current
    total=lambda:status_bytes+request_bytes+response_bytes
    active=np.ones(n,dtype=bool)
    random_order=np.argsort(np.random.default_rng(0).random((n,3)),axis=1)
    for stage in range(3):
        if mode=='fixed_push':
            nodes=policy.order if fixed_nodes is None else tuple(fixed_nodes)
            if stage>=len(nodes):
                break
            choose=np.full(n,nodes[stage],dtype=np.int8)
            active=(total()+26<=budget)&(received.sum(axis=1)<limits)
        else:
            eligible=available&~attempted
            affordable=(total()+40<=budget)&(attempts<limits)
            active&=affordable&eligible.any(axis=1)
            positions=np.flatnonzero(active)
            if not len(positions):
                break
            choose=np.full(n,-1,dtype=np.int8)
            has_scores=received[positions].any(axis=1)
            for i in positions[~has_scores]:
                order=random_order[i] if mode=='random' else policy.order
                choose[i]=next(k for k in order if eligible[i,k])
            idx=positions[has_scores]
            if len(idx):
                if mode=='selection':
                    selected=np.asarray(selection_rule(observed[idx],received[idx],available[idx],idx),dtype=int)
                    if selected.shape!=(len(idx),) or np.any(selected< -1) or np.any(selected>=3):
                        raise ValueError('Selector must choose an eligible node or -1 to stop')
                    continuing=selected>=0
                    if not np.all(eligible[idx[continuing],selected[continuing]]):
                        raise ValueError('Selector requested an unavailable or previously received node')
                    choose[idx[continuing]]=selected[continuing]
                    active[idx[~continuing]]=False
                    stop[idx[~continuing]]=1
                elif mode in ('adaptive','risk_only','gain_only'):
                    q,gains=policy.evaluate(observed[idx],received[idx],available[idx],idx,cache)
                    net=gains-gain_penalty*policy.relative_costs[None,:]
                    net[~eligible[idx]]=-np.inf
                    best=net.argmax(axis=1)
                    if mode=='risk_only':
                        should=q>risk_threshold
                        best=np.asarray([next(k for k in policy.order if eligible[i,k]) for i in idx])
                    elif mode=='gain_only':
                        should=net[np.arange(len(idx)),best]>0
                    else:
                        should=(q>risk_threshold)&(net[np.arange(len(idx)),best]>0)
                    choose[idx[should]]=best[should]
                    active[idx[~should]]=False
                    stop[idx[~should]]=1
                elif mode=='margin':
                    pooled=observed[idx].sum(axis=1)/received[idx].sum(axis=1)[:,None]
                    sorted_=np.sort(pooled,axis=1)
                    should=sorted_[:,-1]-sorted_[:,-2]<margin_threshold
                    for i in idx[should]:
                        choose[i]=next(k for k in policy.order if eligible[i,k])
                    active[idx[~should]]=False
                    stop[idx[~should]]=1
                else:
                    for i in idx:
                        choose[i]=next(k for k in random_order[i] if eligible[i,k])
        for node in range(3):
            idx=np.flatnonzero(active&(choose==node))
            if not len(idx):
                continue
            requests=None
            if mode!='fixed_push':
                requests=[header(REQUEST,node,provider.windows[i],provider.timestamps[i]) for i in idx]
                request_bytes[idx]+=HEADER_BYTES
                attempts[idx]+=1
                attempted[idx,node]=True
                for i,packet in zip(idx,requests):
                    if i<trace_limit:
                        traces.append({'index':int(i),'kind':'request','node':node_names[node],'bytes':len(packet),'hex':packet.hex()})
            packets=provider.responses(node,idx,requests)
            if len(packets)!=len(idx):
                raise ValueError('Response count mismatch')
            for i,packet in zip(idx,packets):
                if packet is None:
                    available[i,node]=False
                    continue
                # Count received traffic even if subsequently rejected as stale.
                response_bytes[i]+=len(packet)
                payload=unpack(packet,SCORE,node,provider.windows[i],provider.timestamps[i],len(CLASSES))
                observed[i,node]=policy.codec.decode(node,payload)
                received[i,node]=True
                available[i,node]=True
                if i<trace_limit:
                    traces.append({'index':int(i),'kind':'score','node':node_names[node],'bytes':len(packet),'hex':packet.hex()})
    count=received.sum(axis=1)
    pooled=observed.sum(axis=1)/np.maximum(count[:,None],1)
    prediction=classes[pooled.argmax(axis=1)].astype(np.int32)
    prediction[count==0]=-1
    stop[(count>0)&(stop==0)]=2
    stop[count==0]=3
    if np.any(total()>budget) or np.any(provider.evaluations.sum(axis=1)>limits):
        raise AssertionError('Budget violated')
    return {'prediction':prediction,'pooled_scores':pooled,'received_mask':mask_bits(received),
            'attempted_mask':mask_bits(attempted),'status_bytes':status_bytes,
            'request_bytes':request_bytes,'response_bytes':response_bytes,'total_bytes':total(),
            'requested_nodes':attempts,'evaluated_nodes':provider.evaluations.sum(axis=1),
            'estimated_node_ms':provider.evaluations@policy.node_costs,'stop_code':stop,
            'traces':traces,'actual_node_wall_ns':provider.node_wall_ns.copy()}
