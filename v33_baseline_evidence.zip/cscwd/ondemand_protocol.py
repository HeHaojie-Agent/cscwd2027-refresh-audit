"""Frozen exploratory protocol for on-demand sensor collaboration."""
from pathlib import Path
import json
import hashlib
from prepare_pamap2 import OUT as BASE,ROOT,write_json

OUT=ROOT/'results'/'pamap2_ondemand_v1'
NODES=('hand','chest','ankle')
BUDGETS=(85,125,165)
MASKS=(1,2,3,4,5,6,7)
RISK_THRESHOLDS=(0.05,0.15,0.30)
GAIN_PENALTIES=(0.0,0.02,0.05,0.10)
HEADER_BYTES=14
RESPONSE_BYTES=26
REQUEST_BYTES=14
STATUS_BYTES=15
HEARTBEAT_WINDOWS=100

def freeze():
    OUT.mkdir(parents=True,exist_ok=True)
    p={
        'version':'pamap2_ondemand_v1','date':'2026-10-13',
        'status':'exploratory mechanism development; original baseline test scores already exposed',
        'baseline_protocol_sha256':hashlib.sha256((BASE/'protocol.json').read_bytes()).hexdigest(),
        'outer_folds':json.loads((BASE/'split_manifest.json').read_text(encoding='utf-8'))['folds'],
        'OOF':'three subject-group folds inside each six-subject outer training set; sorted training subjects paired for holdout, remaining four train',
        'OOF_ridge_alpha':'reuse each final node alpha selected in original outer validation; this is a declared validation dependency, no test dependency',
        'final_node_models':'reuse saved six-subject statistical/MiniRocket(2016) node models',
        'codec':'uint8, one global range per node fitted on training-subject OOF scores only; fixed class order; clipping recorded',
        'policy':'two HistGradientBoostingRegressors: current error indicator and signed accuracy gain from adding a candidate node',
        'policy_params':dict(max_iter=60,max_leaf_nodes=15,min_samples_leaf=80,learning_rate=0.08,l2_regularization=1.0,early_stopping=False,random_state=0),
        'training_weights':'subjects equally weighted, state/action expansion weights normalized to mean one',
        'features':'received score vectors masked to zero for unreceived nodes; received/available masks, pooled evidence, margins; candidate-node identity for gain',
        'initial_order':'rank nodes by subject-equal OOF accuracy; no test or current unrequested scores',
        'stop':'estimated error <= selected risk threshold OR no positive expected net gain OR no affordable/unattempted node',
        'gain_penalty':'expected signed accuracy gain minus penalty * node training-measured batch1 latency relative to mean node latency',
        'risk_thresholds':RISK_THRESHOLDS,'gain_penalties':GAIN_PENALTIES,
        'budgets_bytes':BUDGETS,'max_node_evaluations':3,
        'validation_selection':'per byte budget, maximize fixed-12-class macro-F1 averaged equally across seven nonempty availability masks; ties minimize mean actual bytes, then grid order; save selection before new test policy scoring',
        'packets':'<BBIQ: uint8 kind, uint8 node, uint32 global window, uint64 timestamp_ns; status adds bool; score adds 12 uint8 values; request header only',
        'message_bytes':{'header':14,'status':15,'request':14,'score':26},
        'availability':'node stream availability signaled on initial window, change and every 100 decision windows; status bytes count inside current-window cap; providers remain alive when their sensor stream is unavailable',
        'setup':'shared quantizer configuration once per trial: 14-byte header + 48-byte binary bounds = 62 bytes; report separately and amortized, not inside steady-state per-window cap',
        'stress_masks':MASKS,'dynamic_stress':'cycle masks 7,6,5,3 every 64 windows in fixed order, no outcome-based selection',
        'comparators':['fixed scheduled push: validation-selected single/pair, all nodes without status beacons; budget-aware random pull; margin-triggered pull; risk-only pull; gain-only pull'],
        'no_source':'prediction -1 retained as an error, never removed from denominator',
        'cost_scope':'exact serialized application bytes and request/node evaluation counts; training-only per-node latency estimates; separate real requested-only same-host replay; no wireless or energy claim',
    }
    path=OUT/'protocol.json'
    canonical=json.loads(json.dumps(p))
    if path.exists() and json.loads(path.read_text(encoding='utf-8'))!=canonical:
        raise RuntimeError('Existing protocol differs; use a new result version')
    if not path.exists():
        write_json(path,p)
    return p

if __name__=='__main__':
    freeze()
    print(OUT/'protocol.json')
