"""Package inspectable tables and executed code without duplicating raw inputs."""
from pathlib import Path
import ast,hashlib,json,shutil,zipfile

ROOT=Path(__file__).resolve().parent;R=ROOT/'results/published_baselines_v33';P=ROOT/'baseline_v33'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert read(R/'independent_verification.json')['all_passed']
assert read(R/'fixed_policy_verification.json')['all_passed']
validation=read(P/'validation.json');assert validation['pages']==2 and validation['no_overflow']
validation['visual_review']='passed';validation['reviewed_pages']=[1,2]
write(P/'validation.json',validation)
for lock in ('prior.json','inputs.json'):
    assert all(sha(ROOT/n)==h for n,h in read(R/lock).items())
readme='''# V33 results and executed code

Read baseline_comparison.pdf and V33_基线对比说明.md in cscwd/baseline_v33.
The CSV files preserve all fixed budgets, all B-selected outcomes, true-label F1,
the exact recovery mixture quantiles and the comparison with frozen V32.

The archive includes original B policy tables and selection records for all 396
case grids, source/protocol locks and both independent verification reports.
The full 42,900-row view table permits recomputing subject-equal means.

To rerun scoring, use the original frozen score frames and annotation files named
in inputs.json in the existing workspace. Raw signals, fitted node models and
the full per-window trajectories/event dictionaries are stored in the workspace,
outside this compact result archive. Training node models is not required.

The author baseline source is available at
https://github.com/SLDGroup/BeyondThresholds
Commit 7ab9c55b1995be5288b25abbe042926dab15fefe was inspected.
Clone it to cscwd/research/baseline_v33/BeyondThresholds when rerunning freeze or
the author-source comparison check.

Normal workflow in the original workspace

    python cscwd/run_published_baselines_v33.py selftest
    python cscwd/run_published_baselines_v33.py freeze
    python cscwd/run_published_baselines_v33.py run --workers 4
    python cscwd/run_published_baselines_v33.py summarize
    python cscwd/audit_published_baselines_v33.py
    python cscwd/audit_fixed_baselines_v33.py
    python cscwd/build_baseline_report_v33.py

The summary entry point delegates to the bounded-memory implementation.
source_at_execution.py preserves the scored source and original hash.
summary_dispatch_amendment.json records the later operational dispatch fix and
the unchanged AST hashes of all twelve policy/scoring functions. Candidate
policies, saved evaluation trajectories and selection results are unchanged.

The executed results establish a matched comparison with a published method.
They do not establish an unmodified original-paper reproduction or a global HAR
leaderboard result. Both primary-only/native and cached variants, complete-push
fallbacks and the higher-F1 operating points are retained for inspection.
'''
(P/'REPRODUCE.md').write_text(readme,encoding='utf-8')
files={}
def add(p):
    p=Path(p);files['cscwd/'+p.relative_to(ROOT).as_posix()]=p
for p in P.rglob('*'):
    if p.is_file() and p.suffix!='.zip' and p.name not in ('delivery_manifest.json','bundle_verification.json'):add(p)
for p in R.iterdir():
    if p.is_file():add(p)
for p in (R/'cases').rglob('b_selection.json'):add(p)
for p in (R/'cases').rglob('b_candidates.csv'):add(p)
names=['run_published_baselines_v33.py','summarize_published_baselines_v33.py','audit_published_baselines_v33.py',
       'audit_fixed_baselines_v33.py','build_baseline_report_v33.py','package_baseline_v33.py']
todo=list(names);seen=set()
while todo:
    name=todo.pop()
    if name in seen:continue
    seen.add(name);path=ROOT/name;add(path)
    for node in ast.walk(ast.parse(path.read_text(encoding='utf-8-sig'))):
        modules=[node.module] if isinstance(node,ast.ImportFrom) else [a.name for a in node.names] if isinstance(node,ast.Import) else []
        for module in modules:
            if module:
                target=module.split('.')[0]+'.py'
                if (ROOT/target).is_file():todo.append(target)
for n in ('results/twoside_trigger_v32/dataset_equal_metrics.csv','results/matched_calibration_v20/plan.json'):
    add(ROOT/n)
bundle=P/'CSCWD_V33_基线对比结果与代码.zip'
manifest={name:sha(path) for name,path in sorted(files.items())}
with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr('bundle_manifest.json',json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
    from io import BytesIO
    import pandas as pd,numpy as np
    root='cscwd/results/published_baselines_v33/'
    views=pd.read_csv(BytesIO(z.read(root+'view_metrics.csv')))
    summary=pd.read_csv(BytesIO(z.read(root+'dataset_equal_metrics.csv')))
    keys=['dataset','stride','offset','method']
    means=views.groupby(keys+['subject','outer_fold','group']).mean(numeric_only=True).groupby(keys+['subject']).mean(numeric_only=True).groupby(keys).mean(numeric_only=True)
    report=summary.set_index(keys)
    for field in ('bytes_per_window','baseline_bytes_per_window','reference_disagreement','known_endpoint_macro_f1','deployable_full_models_per_window'):
        np.testing.assert_allclose(means[field].sort_index(),report[field].sort_index(),rtol=0,atol=1e-12)
    assert views.shape[0]==42900 and len(summary)==495
write(P/'bundle_verification.json',dict(all_passed=True,manifest_files=len(manifest),view_rows=42900,scenario_rows=495,
    archive_hashes_verified=True,source_and_view_aggregation_verified=True))
write(P/'delivery_manifest.json',dict(version='V33',completed_date='2026-11-18',all_checks_passed=True,
    pdf_pages=2,case_grids=396,selected_paths_verified=3900,fixed_full_metric_checks=450,
    actual_fixed_prefix_packets=105980,hidden_score_checks=422,
    old_paper_files_preserved=len(read(R/'prior.json')),bundle_bytes=bundle.stat().st_size,bundle_files=len(manifest),
    pdf_sha256=sha(P/'baseline_comparison.pdf'),bundle_sha256=sha(bundle),
    source_snapshot_and_dispatch_amendment_preserved=True,matched_adaptation=True,global_sota_claim=False))
print(json.dumps(dict(complete=True,pdf=str(P/'baseline_comparison.pdf'),bundle=str(bundle),
    size_mb=round(bundle.stat().st_size/2**20,2),files=len(manifest)),ensure_ascii=False))
