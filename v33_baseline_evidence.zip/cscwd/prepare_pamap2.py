"""Audit original PAMAP2 Protocol files and build subject-disjoint windows.

No model scores enter data selection. All interpolation is restricted to a
continuous activity segment within one recording. Longer gaps remain NaN.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data' / 'pamap2'
OUT = ROOT / 'results' / 'pamap2_baseline_v1'
ACTIVITIES = {1:'lying', 2:'sitting', 3:'standing', 4:'walking', 5:'running',
              6:'cycling', 7:'Nordic walking', 12:'ascending stairs',
              13:'descending stairs', 16:'vacuum cleaning', 17:'ironing',
              24:'rope jumping'}
NODES = {'hand': [4,5,6,10,11,12], 'chest': [21,22,23,27,28,29],
         'ankle': [38,39,40,44,45,46]}
SUBJECTS = list(range(101,109))
WINDOW = 200
STRIDE = 100
MAX_GAP = 10

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

def protocol():
    return {
        'version':'pamap2_baseline_v1', 'status':'exploratory baseline; not prospective confirmation',
        'source':'https://archive.ics.uci.edu/dataset/231/pamap2%2Bphysical%2Bactivity%2Bmonitoring',
        'source_archive':'https://archive.ics.uci.edu/static/public/231/pamap2%2Bphysical%2Bactivity%2Bmonitoring.zip',
        'records':'Protocol only; Optional excluded',
        'primary_subjects':SUBJECTS, 'auxiliary_subjects':[109],
        'auxiliary_policy':'audit 109 but exclude from main 12-activity evaluation because its protocol record is partial; verify coverage from raw data',
        'activities':ACTIVITIES, 'nodes_zero_based_raw_columns':NODES,
        'channels_per_node':['acc16g_x','acc16g_y','acc16g_z','gyro_x','gyro_y','gyro_z'],
        'excluded_signals':['heart rate','temperature','6g accelerometer','magnetometer','invalid orientation'],
        'sample_rate_hz':100, 'window_samples':WINDOW, 'stride_samples':STRIDE,
        'window_duration_seconds':2, 'overlap_fraction':0.5,
        'segment_breaks':'activity changes or nonpositive/nonfinite timestamp increment or increment >0.015s',
        'labels':'all 200 samples must have the same selected nonzero activity label',
        'missing':'linear interpolation only for fully bounded per-channel runs <=10 samples inside one continuous activity segment; drop windows with any remaining nonfinite selected channel',
        'normalization':'training-only channel/feature scaling; no per-window z-normalization',
        'folds':[{'fold':f'test_{s}', 'train':[x for x in SUBJECTS if x not in [s,SUBJECTS[(i+1)%8]]],
                  'validation':[SUBJECTS[(i+1)%8]], 'test':[s]} for i,s in enumerate(SUBJECTS)],
        'selection':'choose ridge alpha by fixed-12-class validation macro-F1; ties prefer first in ascending alpha grid; no refit on validation',
        'alpha_grid':[0.01,0.1,1,10,100,1000,10000],
        'baseline_models':['statistical features + ridge', 'MiniRocket(2016 requested kernels; implementation baseline) + ridge'],
        'baseline_conditions':['hand','chest','ankle','centralized','equal_score_fusion'],
        'random_seed':0, 'threads':1,
        'inference_units':'8 subjects; overlapping windows and model seeds are not independent replications',
        'cost_scope':'same-host CPU replay; serial compute wall time, no real wireless latency or measured energy',
    }

def bounded_interpolate(x, max_gap=MAX_GAP):
    """Return interpolated values and number of filled scalar entries."""
    result = np.asarray(x, dtype=np.float32).copy()
    filled = 0
    for c in range(result.shape[1]):
        missing = ~np.isfinite(result[:,c])
        edges = np.diff(np.r_[False, missing, False].astype(np.int8))
        starts, stops = np.flatnonzero(edges==1), np.flatnonzero(edges==-1)
        for a,b in zip(starts,stops):
            if a>0 and b<len(result) and b-a<=max_gap:
                result[a:b,c] = np.linspace(result[a-1,c],result[b,c],b-a+2)[1:-1]
                filled += int(b-a)
    return result, filled

def segment_ranges(time, labels):
    dt = np.diff(time)
    broken = (np.diff(labels)!=0) | ~np.isfinite(dt) | (dt<=0) | (dt>0.015)
    edges = np.r_[0,np.flatnonzero(broken)+1,len(time)]
    return zip(edges[:-1],edges[1:])

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    p = protocol()
    protocol_path = OUT/'protocol.json'
    if protocol_path.exists():
        if json.loads(protocol_path.read_text(encoding='utf-8')) != json.loads(json.dumps(p)):
            raise RuntimeError('Refusing to silently change the existing frozen protocol')
    else:
        write_json(protocol_path,p)
    records = sorted(DATA.glob('**/Protocol/subject*.dat'))
    if len(records)!=9:
        raise RuntimeError(f'Expected 9 Protocol records, found {len(records)}')
    profiles=[]
    metadata=[]
    shards=[]
    columns=sum(NODES.values(),[])
    for record in records:
        windows=[]
        subject=int(record.stem.removeprefix('subject'))
        print(f'load subject={subject}',flush=True)
        raw=pd.read_csv(record,sep=r'\s+',header=None,dtype=np.float64).to_numpy()
        if raw.shape[1]!=54:
            raise ValueError(f'{record}: expected 54 columns, found {raw.shape[1]}')
        time=raw[:,0]
        if not np.isfinite(time).all() or not np.isfinite(raw[:,1]).all():
            raise ValueError('Nonfinite timestamp or activity label')
        labels=raw[:,1].astype(np.int32)
        if not np.array_equal(labels,raw[:,1]):
            raise ValueError('Noninteger activity ID')
        x=raw[:,columns].astype(np.float32)
        profile={
            'subject':subject, 'file':str(record.relative_to(ROOT)),
            'sha256':hashlib.file_digest(record.open('rb'),'sha256').hexdigest(),
            'rows':len(raw), 'columns':raw.shape[1],
            'time_min':float(time.min()),'time_max':float(time.max()),
            'nonpositive_time_increments':int((np.diff(time)<=0).sum()),
            'large_time_gaps':int((np.diff(time)>0.015).sum()),
            'median_time_increment':float(np.median(np.diff(time))),
            'duplicate_timestamps':int(pd.Series(time).duplicated().sum()),
            'activity_rows':{str(int(a)):int(n) for a,n in zip(*np.unique(labels,return_counts=True))},
            'null_rates_all_54_columns':np.mean(~np.isfinite(raw),axis=0).tolist(),
            'selected_null_fraction':float(np.mean(~np.isfinite(x))),
            'selected_channel_quantiles':{str(q):np.nanquantile(x,q,axis=0).tolist() for q in [0,0.01,0.5,0.99,1]},
            'filled_entries':0, 'candidate_windows':0,'dropped_nonfinite_windows':0,
            'window_counts':{str(a):0 for a in ACTIVITIES},
        }
        for segment_id,(a,b) in enumerate(segment_ranges(time,labels)):
            label=int(labels[a])
            if label not in ACTIVITIES or b-a<WINDOW:
                continue
            values,filled=bounded_interpolate(x[a:b])
            profile['filled_entries']+=filled
            for local in range(0,b-a-WINDOW+1,STRIDE):
                profile['candidate_windows']+=1
                window=values[local:local+WINDOW]
                if not np.isfinite(window).all():
                    profile['dropped_nonfinite_windows']+=1
                    continue
                profile['window_counts'][str(label)]+=1
                if subject in SUBJECTS:
                    windows.append(window.T.copy())
                    start=a+local
                    metadata.append({'subject':subject,'activity':label,'record':record.name,
                                     'segment':segment_id,'start_row':int(start),'end_row_exclusive':int(start+WINDOW),
                                     'start_time':float(time[start]),'end_time':float(time[start+WINDOW-1]),
                                     'interpolated_entries':int((~np.isfinite(x[start:start+WINDOW])).sum())})
        profile['kept_windows']=sum(profile['window_counts'].values())
        profile['drop_fraction']=profile['dropped_nonfinite_windows']/max(1,profile['candidate_windows'])
        profiles.append(profile)
        if subject in SUBJECTS:
            shard=OUT/f'windows_subject{subject}.npy'
            np.save(shard,np.stack(windows).astype(np.float32))
            shards.append(shard)
            del windows
        print(f'subject={subject} rows={len(raw)} kept={profile["kept_windows"]} dropped={profile["dropped_nonfinite_windows"]}',flush=True)
        del raw,x
    frame=pd.DataFrame(metadata)
    array=np.lib.format.open_memmap(OUT/'windows.npy',mode='w+',dtype=np.float32,shape=(len(frame),18,WINDOW))
    offset=0
    for shard in shards:
        values=np.load(shard,mmap_mode='r')
        array[offset:offset+len(values)]=values
        offset+=len(values)
    array.flush()
    np.save(OUT/'labels.npy',frame.activity.to_numpy(dtype=np.int32))
    np.save(OUT/'subjects.npy',frame.subject.to_numpy(dtype=np.int32))
    frame.to_csv(OUT/'window_manifest.csv',index=False)
    coverage=pd.DataFrame([{'subject':r['subject'],'activity':int(a),'windows':n} for r in profiles for a,n in r['window_counts'].items()])
    coverage.to_csv(OUT/'subject_activity_coverage.csv',index=False)
    hashes={}
    duplicates=[]
    for i,window in enumerate(array):
        digest=hashlib.sha256(window.tobytes()).hexdigest()
        if digest in hashes and frame.iloc[hashes[digest]].subject!=frame.iloc[i].subject:
            duplicates.append({'index':i,'other_index':hashes[digest]})
        hashes[digest]=i
    if duplicates:
        raise ValueError(f'Cross-subject identical windows: {duplicates[:5]}')
    for fold in p['folds']:
        sets=[set(fold[k]) for k in ['train','validation','test']]
        assert not (sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])
        assert set.union(*sets)==set(SUBJECTS)
        fold['window_counts']={k:int(frame.subject.isin(fold[k]).sum()) for k in ['train','validation','test']}
    write_json(OUT/'split_manifest.json',{'folds':p['folds'],'subject_disjoint':True,'no_validation_refit':True})
    write_json(OUT/'data_audit.json',{
        'records':profiles,'X_shape':list(array.shape),'primary_subjects':SUBJECTS,
        'cross_subject_identical_window_count':len(duplicates),
        'window_label_boundary_violations':0,
        'windowing_uses_labels_to_exclude_activity_transitions':True,
        'raw_file_and_window_manifests_retained':True,
        'limits':['within-subject windows overlap; labels define clean activity segments',
                  'short-gap interpolation uses both endpoints inside each offline window segment',
                  'long-gap windows are excluded; this baseline evaluates surviving synchronized windows',
                  'Protocol-only data and a small participant population limit generalization'],
    })
    print(f'prepared shape={array.shape}; cross-subject duplicates={len(duplicates)}',flush=True)

if __name__=='__main__':
    main()
