"""Post-development protocol factorial: executable, lossless score/control replay.

No fitting or policy selection. Native-four encoding changes wire width only;
the frozen 52-feature controller still receives a zero-padded twelve-slot state.
"""
import hashlib
import struct
import numpy as np
from causal_score_codec import HEADER, ExactCodec
from bounded_score_codec import pack_fields, BitReader, delta, undelta
from continuous_screen_accounting import setup_packets
from continuous_causal_controls import METHODS
from validity_diagnostic import profile
from adaptive_lease_oracle import grant_packet, INTERVALS
from event_refresh_v21 import request_packet, parse_request
from run_matched_calibration import pack
from scalar_risk_calibration import parse_weight_packet, runtime_parameters, choose_interval as scalar_interval
from lease_prediction import choose_interval as full_interval

POLICIES = ('complete_push', 'periodic_h2', 'platt_t0.01', 'isotonic_t0.01',
            'direct_t0.01', 'survival_t0.01', 'drift_t0.025')
VARIANTS = {'legacy12': (12, False), 'compact12': (12, True),
            'legacy4': (4, False), 'compact4': (4, True)}
COMPACT = struct.Struct('<HB')  # session-local tick, action code; channel binds peer


class RiceWidthCodec:
    """One-row Rice2/3 with raw escape and an explicitly negotiated width."""
    def __init__(self, method, width):
        if method not in ('rice2', 'rice3') or width not in (4, 12):
            raise ValueError('Unsupported negotiated codec')
        self.k, self.width, self.previous = int(method[-1]), width, None

    def encode(self, row, node, window, stamp):
        row = np.asarray(row)
        if row.dtype != np.uint8 or row.shape != (self.width,):
            raise ValueError('Wrong wire width')
        kind, body = 20, row.tobytes()
        if self.previous is not None:
            symbols = delta(row, self.previous)
            values, widths = [], []
            for value in symbols:
                values.extend((1, int(value) & ((1 << self.k)-1)))
                widths.extend(((int(value) >> self.k)+1, self.k))
            residual = pack_fields(values, widths)
            if len(residual) < len(body):
                kind, body = 30+2*self.k, residual
        self.previous = row.copy()
        return HEADER.pack(kind, node, window, stamp)+body

    def decode(self, packet, node, window, stamp):
        kind, peer, tick, timestamp = HEADER.unpack_from(packet)
        if (peer, tick, timestamp) != (node, window, stamp):
            raise ValueError('Wrong score identity')
        body = packet[14:]
        if kind == 20:
            if len(body) != self.width:
                raise ValueError('Wrong raw width')
            row = np.frombuffer(body, np.uint8).copy()
        elif kind == 30+2*self.k and self.previous is not None:
            reader, symbols = BitReader(body), []
            for _ in range(self.width):
                quotient = 0
                while reader.read(1) == 0:
                    quotient += 1
                    if quotient > (510 >> self.k):
                        raise ValueError('Rice quotient overflow')
                value = (quotient << self.k) | reader.read(self.k)
                if value > 510:
                    raise ValueError('Rice symbol overflow')
                symbols.append(value)
            reader.finish()
            row = undelta(np.array(symbols), self.previous).astype(np.uint8)
        else:
            raise ValueError('Wrong codec kind or missing keyframe')
        self.previous = row.copy()
        return row


def compact_packet(tick, interval):
    if not 0 <= tick < 2048 or interval not in (0, *INTERVALS):
        raise ValueError('Compact action outside negotiated session')
    return COMPACT.pack(tick, 0 if interval == 0 else 1+list(INTERVALS).index(interval))


def decode_compact(packet, tick):
    if len(packet) != 3:
        raise ValueError('Wrong compact length')
    actual_tick, code = COMPACT.unpack(packet)
    if actual_tick != tick or not 0 <= code <= len(INTERVALS):
        raise ValueError('Wrong compact tick/action')
    return 0 if code == 0 else INTERVALS[code-1]


def extension_packets(width, compact, window, stamp):
    """Three 18-byte schema/peer bindings, charged at every session start."""
    if width == 12 and not compact:
        return []
    packets = [HEADER.pack(207, node, window, stamp)+bytes((1, width, int(compact), 11))
               for node in range(3)]
    for node, packet in enumerate(packets):
        assert HEADER.unpack_from(packet) == (207, node, window, stamp)
        assert packet[14:] == bytes((1, width, int(compact), 11))
        assert len(packet) == 18
    return packets


def restore_model(model):
    if model is None:
        return b'', None
    packet = pack(model)
    if model['kind'] in ('platt', 'isotonic'):
        return packet, runtime_parameters(parse_weight_packet(packet))
    values = np.frombuffer(packet[30:], '<f8').copy()
    assert hashlib.sha256(values.tobytes()).digest()[:16] == packet[14:30]
    if model['kind'] == 'direct':
        heads = values.reshape(4, 53)
        matrix, intercept = heads[:, :52].copy(), heads[:, 52].copy()
    elif model['kind'] == 'survival':
        matrix, intercept = np.tile(values[:52], (4, 1)), values[56]+values[52:56]
    else:
        raise ValueError('Unplanned predictor')
    np.testing.assert_allclose(matrix, model['matrix'], rtol=0, atol=1e-14)
    np.testing.assert_allclose(intercept, model['intercept'], rtol=0, atol=1e-14)
    return packet, (matrix, intercept)


def replay(f, models, policy, variant, obtain=None):
    """Execute causal decisions with remote score access only on actual refresh.

    obtain(t,node), when supplied, runs a raw-window node classifier. Otherwise
    it reads only that node's requested row from the frozen score stream.
    All emitted score/control packets are decoded, including complete push.
    """
    if policy not in POLICIES or variant not in VARIANTS:
        raise ValueError('Unplanned policy/variant')
    width, compact = VARIANTS[variant]
    n = len(f['q'])
    assert (f['q'][:, :, 4:] == 0).all() and f['session_start'][0]
    get = (lambda t, node: f['q'][t, node].copy()) if obtain is None else obtain
    complete = policy == 'complete_push'
    codec = 'rice3' if complete else 'rice2'
    enc = [RiceWidthCodec(codec, width) for _ in range(3)]
    dec = [RiceWidthCodec(codec, width) for _ in range(3)]
    cache = np.zeros((3, 12), np.uint8)
    sent = np.zeros((n, 3), bool)
    grants = np.zeros(n, np.int16)
    prediction = np.empty(n, np.int16)
    parts = {k: np.zeros(n, np.int64) for k in ('score', 'control', 'setup', 'model', 'status')}
    kind = policy.split('_t')[0]
    model = models[kind] if kind in ('platt', 'isotonic', 'direct', 'survival') else None
    weight, parameters = restore_model(model)
    threshold = float(np.float32(.01))
    anchor, due, session_origin, decisions = 0, -1, 0, 0
    legacy_packets_checked = 0
    old_enc = [ExactCodec(codec) for _ in range(3)] if variant == 'legacy12' else None
    for t in range(n):
        reset = bool(f['reset'][t])
        window, stamp = int(f['continuous_global_indices'][t]), int(round(f['end_time'][t]*1e6))
        if f['session_start'][t]:
            session_origin = t
            configs = setup_packets(METHODS.index(codec), 0) if complete else profile(
                POLICIES.index(policy), 2 if policy == 'periodic_h2' else 16,
                float(np.float32(.025)) if policy == 'drift_t0.025' else (0. if policy == 'periodic_h2' else threshold))
            # Existing setup parsers validate their payloads; extension binds schema.
            parts['setup'][t] = sum(map(len, configs+extension_packets(width, compact, window, stamp)))
            parts['model'][t] = len(weight)
        if reset:
            for state in enc+dec+(old_enc or []):
                state.previous = None
        primary = np.asarray(get(t, 0), np.uint8)
        np.testing.assert_array_equal(primary, f['q'][t, 0])
        refresh, action = complete or reset, None
        if not refresh:
            if policy == 'periodic_h2':
                refresh = t-anchor >= 2
            elif policy == 'drift_t0.025':
                decisions += 1
                refresh = t-anchor >= 16 or np.abs(primary.astype(int)-cache[0].astype(int)).mean()/255 >= .025
                if refresh:
                    action, grants[t] = 0, 1
            elif due == t:
                refresh = True
            elif t == anchor+1 and due < 0:
                if kind in ('platt', 'isotonic'):
                    interval = int(scalar_interval(primary, cache, parameters, ('platt', 'isotonic').index(kind), threshold))
                else:
                    matrix, intercept = parameters
                    interval = int(full_interval(primary, cache, matrix, intercept, ('geometric', 'direct', 'survival').index(kind), threshold))
                decisions += 1
                action, grants[t], due = interval, interval, anchor+interval
                refresh = due == t
        if action is not None:
            tick = t-session_origin
            for peer in (1, 2):
                if compact:
                    packet = compact_packet(tick, action)
                    recovered = decode_compact(packet, tick)
                elif action == 0:
                    packet = request_packet(peer, window, stamp)
                    parse_request(packet, peer, window, stamp)
                    recovered = 0
                else:
                    packet = grant_packet(peer, window, stamp, action)
                    assert HEADER.unpack_from(packet) == (93, peer, window, stamp)
                    recovered = INTERVALS[packet[14]]
                assert recovered == action
                parts['control'][t] += len(packet)
        if refresh:
            anchor, due = t, -1
        fused = np.zeros(12, np.int32)
        for node in range(3):
            if node > 0 and not refresh:
                fused += cache[node].astype(np.int32)
                continue
            row = primary if node == 0 else np.asarray(get(t, node), np.uint8)
            np.testing.assert_array_equal(row, f['q'][t, node])
            packet = enc[node].encode(row[:width], node, window, stamp)
            decoded = dec[node].decode(packet, node, window, stamp)
            np.testing.assert_array_equal(decoded, row[:width])
            restored = np.zeros(12, np.uint8)
            restored[:width] = decoded
            np.testing.assert_array_equal(restored, row)
            if old_enc is not None:
                assert packet == old_enc[node].encode(row[None], node, window, stamp)
                legacy_packets_checked += 1
            sent[t, node] = True
            parts['score'][t] += len(packet)
            fused += restored.astype(np.int32)
            if refresh:
                cache[node] = restored
        prediction[t] = np.argmax(fused)
        if f['status'][t]:
            for node in range(3):
                packet = HEADER.pack(3, node, window, stamp)+b'\0'
                assert HEADER.unpack_from(packet) == (3, node, window, stamp)
                parts['status'][t] += len(packet)
    return dict(send=sent, grants=grants, prediction=prediction,
                total_bytes=sum(parts.values()), **{k+'_bytes': v for k, v in parts.items()},
                controller_calls=np.array(decisions), legacy_packets_checked=np.array(legacy_packets_checked))
