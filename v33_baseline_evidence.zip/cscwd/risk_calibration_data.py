"""V19 deepest subject-excluded nodes and current-risk crossfit training scores."""
import argparse
from datetime import datetime, timezone
import gc
import hashlib
from pathlib import Path
import time
import warnings
import joblib
import numpy as np
from sklearn.linear_model import RidgeClassifier
from threadpoolctl import threadpool_limits
from nested_validity_data import ROOT, OLD, DATA, CONFIG, read, write, sha, mapped_decision, signature
from continuous_training_data import TrainingWindowStore
from continuous_oof_models import (join_training_annotations, fit_positions, materialize_node,
    ContinuousRocketTransform, transform_and_scale, close_map, remove_scratch, BATCH)
from run_lease_oracle import PREVIOUS, SCENARIOS, OUT as V18
from run_lease_prediction import check as check_previous
from validity_survival import frame
from lease_prediction import landmarks, fit_logistic

OUT = ROOT/'results'/'risk_only_calibration_v19'


def identifier(dataset, node, subjects):
    return hashlib.sha256(str((dataset, node, tuple(sorted(subjects)), 'v19-fixed-alpha1-double')).encode()).hexdigest()[:24]


def make_plan(groups):
    heads, jobs = {}, {}
    for group in groups:
        training, dataset = group['controller_train_subjects'], group['dataset']
        for inner in group['inner']:
            fit = inner['fit_subjects']
            key = identifier(dataset, -1, fit)
            if key not in heads:
                heads[key] = dict(id=key, dataset=dataset, fit_subjects=fit,
                    canonical_train_fold=group['outer_fold'], node_sources=[], parent_references=[])
                for subject in fit:
                    node_fit = [s for s in fit if s != subject]
                    assert node_fit
                    for node in range(3):
                        node_key = identifier(dataset, node, node_fit)
                        if node_key not in jobs:
                            jobs[node_key] = dict(id=node_key, dataset=dataset, node=node, fit_subjects=node_fit,
                                canonical_train_fold=group['outer_fold'], predictions={})
                        jobs[node_key]['predictions'].setdefault(str(subject), group['outer_fold'])
                        heads[key]['node_sources'].append(dict(subject=subject, node=node, model_id=node_key,
                            fit_subjects=node_fit))
            assert set(fit).isdisjoint(inner['predict_subjects']+group['controller_held_subjects'])
            assert sorted(fit+inner['predict_subjects']) == sorted(training)
            heads[key]['parent_references'].append(dict(group_id=group['id'], split=inner['split'],
                calibration_score_subjects=inner['predict_subjects'], final_held_subjects=group['controller_held_subjects']))
    return dict(heads=list(heads.values()), jobs=list(jobs.values()))


def prepare():
    check_previous()
    OUT.mkdir(parents=True, exist_ok=True)
    plan = make_plan(read(PREVIOUS/'plan.json')['groups'])
    sources = {name: sha(ROOT/name) for name in ('risk_calibration_data.py', 'test_risk_calibration_data.py',
        'CSCWD2027_当前风险多时域校准协议V19.md', 'nested_validity_data.py', 'continuous_oof_models.py',
        'continuous_training_data.py', 'lease_prediction.py', 'validity_survival.py')}
    inputs = {str((V18/name).relative_to(ROOT)): sha(V18/name) for name in
        ('artifact_manifest.json', 'final_integrity.json', 'learner_inputs.json', 'learner_source_lock.json')}
    inputs[str((PREVIOUS/'plan.json').relative_to(ROOT))] = sha(PREVIOUS/'plan.json')
    for parent in read(PREVIOUS/'plan.json')['groups']:
        for path in (PREVIOUS/'groups'/parent['id']/'training_scores.npz',
                     V18/'learners'/parent['id']/'stride1_offset0'/'models.json'):
            inputs[str(path.relative_to(ROOT))] = sha(path)
    # Existing manifests cover all raw TRAIN recording bytes and their authorized views.
    inputs[str((PREVIOUS/'inputs.json').relative_to(ROOT))] = sha(PREVIOUS/'inputs.json')
    if (OUT/'base_source_lock.json').exists():
        assert read(OUT/'base_source_lock.json') == sources
        assert read(OUT/'base_inputs.json') == inputs
        assert read(OUT/'base_plan.json') == plan
        return
    write(OUT/'base_plan.json', plan)
    write(OUT/'base_source_lock.json', sources)
    write(OUT/'base_inputs.json', inputs)
    write(OUT/'design_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
        document_sha256=sha(ROOT/'CSCWD2027_当前风险多时域校准协议V19.md'),
        base_plan_sha256=sha(OUT/'base_plan.json'), sources_sha256=sha(OUT/'base_source_lock.json'),
        input_sha256=sha(OUT/'base_inputs.json'), new_fitting_started=False, alpha=1.,
        new_node_models=len(plan['jobs']), current_risk_subject_subsets=len(plan['heads'])))


def check(inputs=False):
    for name, value in read(OUT/'base_source_lock.json').items():
        assert sha(ROOT/name) == value, name
    if inputs:
        for name, value in read(OUT/'base_inputs.json').items():
            assert sha(ROOT/name) == value, name
        for name, value in read(PREVIOUS/'inputs.json').items():
            assert sha(ROOT/name) == value, name


def fit_job(job):
    target = OUT/'node_models'/job['id']
    target.mkdir(parents=True, exist_ok=True)
    begun = time.perf_counter()
    with TrainingWindowStore(job['dataset'], job['canonical_train_fold']) as store:
        annotations = join_training_annotations(store)
        sig = signature(store, annotations, job['fit_subjects'], job['node'])
        done = target/'complete.json'
        if done.exists():
            saved = read(done)
            assert saved['signature'] == sig and sha(target/'model.joblib') == saved['model_sha256']
        else:
            scratch = target/'scratch'
            scratch.mkdir(exist_ok=True)
            paths = [scratch/name for name in ('x.npy', 'normalized.npy', 'features.npy')]
            positions = fit_positions(store, annotations, job['fit_subjects'])
            x = materialize_node(store, positions, job['node'], paths[0])
            transform = ContinuousRocketTransform().fit(x, paths[1])
            features, scaler = transform_and_scale(x, transform, paths[2])
            values = np.asarray(features, np.float64)
            y = annotations.endpoint_target.to_numpy()[positions]
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                model = RidgeClassifier(alpha=1., solver='cholesky', copy_X=True).fit(values, y)
            assert not caught, [str(w.message) for w in caught]
            yy = model._label_binarizer.transform(y).astype(np.float64)
            centered = values-values.mean(0)
            centered_y = yy-yy.mean(0)
            rhs = centered.T@centered_y
            residual = centered.T@(centered@model.coef_.T-centered_y)+model.coef_.T
            relative = float(np.linalg.norm(residual)/max(np.linalg.norm(rhs), 1e-30))
            assert relative < 1e-8 and np.isfinite(model.coef_).all(), relative
            bundle = dict(transform=transform, scaler=scaler, model=model, dataset=job['dataset'], node=job['node'],
                fit_subjects=job['fit_subjects'], fit_continuous_global_indices=store.index.continuous_global_index.to_numpy()[positions],
                class_slots=np.asarray(CONFIG[job['dataset']]['classes']), absent_class_score=-4., alpha=1.)
            joblib.dump(bundle, target/'model.joblib', compress=0)
            write(target/'fit_metadata.json', dict(signature=sig, fixed_alpha=1., selected_on_held_subject=False,
                readout_dtype=str(model.coef_.dtype), warnings=[], relative_normal_equation_residual=relative,
                trained_classes=model.classes_.tolist(), missing_classes=[int(c) for c in bundle['class_slots'] if c not in model.classes_]))
            write(done, dict(signature=sig, model_sha256=sha(target/'model.joblib'),
                metadata_sha256=sha(target/'fit_metadata.json'), elapsed_fit_seconds=time.perf_counter()-begun))
            close_map(x)
            close_map(features)
            del x, features, values, centered, centered_y, rhs, residual, bundle, model, transform
            gc.collect()
            remove_scratch(paths, scratch)
    bundle = joblib.load(target/'model.joblib')
    for subject_text, fold in job['predictions'].items():
        subject = int(subject_text)
        score_path = target/f'subject{subject}_scores.npz'
        if score_path.with_suffix('.json').exists():
            assert sha(score_path) == read(score_path.with_suffix('.json'))['score_sha256']
            continue
        assert subject not in bundle['fit_subjects']
        with TrainingWindowStore(job['dataset'], fold) as store:
            positions = np.flatnonzero(store.index.subject.to_numpy() == subject)
            scores = np.empty((len(positions), 12), np.float32)
            width = CONFIG[job['dataset']]['selected_axes_per_node']
            for start in range(0, len(positions), BATCH):
                raw, _ = store.batch(positions[start:start+BATCH])
                scores[start:start+len(raw)] = mapped_decision(bundle, raw[:, job['node']*width:(job['node']+1)*width])
            ids = store.index.continuous_global_index.to_numpy()[positions]
        np.savez_compressed(score_path, scores=scores, continuous_global_indices=ids)
        write(score_path.with_suffix('.json'), dict(subject=subject, authorized_train_fold=fold,
            fit_subjects=bundle['fit_subjects'], model_sha256=sha(target/'model.joblib'), score_sha256=sha(score_path), windows=len(scores)))
    print(f'V19 base {job["dataset"]} node{job["node"]} fit={job["fit_subjects"]} elapsed={time.perf_counter()-begun:.1f}s', flush=True)


def assemble_head(head):
    target = OUT/'current_heads'/head['id']
    target.mkdir(parents=True, exist_ok=True)
    train_path = target/'training_scores.npz'
    if not train_path.exists():
        template = OLD/head['dataset']/head['canonical_train_fold']/'training_oof_scores.npz'
        with np.load(template) as old:
            keep = np.isin(old['subjects'], head['fit_subjects'])
            arrays = {key: old[key] if key == 'classes' else old[key][keep] for key in old.files
                if key not in ('scores', 'reference_prediction')}
        scores = np.empty((int(keep.sum()), 3, 12), np.float32)
        for ref in head['node_sources']:
            source = OUT/'node_models'/ref['model_id']/f'subject{ref["subject"]}_scores.npz'
            at = np.flatnonzero(arrays['subjects'] == ref['subject'])
            with np.load(source) as saved:
                np.testing.assert_array_equal(arrays['continuous_global_indices'][at], saved['continuous_global_indices'])
                scores[at, ref['node']] = saved['scores']
        np.savez_compressed(train_path, scores=scores, **arrays)
        write(target/'training_scores_lineage.json', dict(plan=head, source_template_sha256=sha(template),
            training_scores_sha256=sha(train_path), every_scored_subject_excluded_from_its_node_fits=True))
    else:
        assert sha(train_path) == read(target/'training_scores_lineage.json')['training_scores_sha256']
    for stride, offset in SCENARIOS:
        model_path = target/f'stride{stride}_offset{offset}.json'
        if model_path.exists():
            continue
        f = frame(train_path, head['dataset'], stride, offset)
        data = landmarks(f, True)
        model = fit_logistic(data['x'], (data['first'] == 0).astype(int), data['subjects'])
        model['coefficient'] = model['coefficient'].tolist()
        model['current_head_fit_subjects'] = head['fit_subjects']
        model['training_scores_sha256'] = sha(train_path)
        write(model_path, model)


def run(limit=None):
    check(True)
    plan = read(OUT/'base_plan.json')
    for i, job in enumerate(plan['jobs']):
        fit_job(job)
        gc.collect()
        if limit and i+1 >= limit:
            return
    for head in plan['heads']:
        assemble_head(head)
    write(OUT/'base_fit_complete.json', dict(node_models=len(plan['jobs']),
        current_risk_subject_subsets=len(plan['heads']), current_risk_heads=3*len(plan['heads']),
        new_outer_validation_or_test_predictions=False, completed_utc=datetime.now(timezone.utc).isoformat()))
    print('V19 nested calibration inputs complete', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        prepare() if args.prepare_only else run(args.limit)
