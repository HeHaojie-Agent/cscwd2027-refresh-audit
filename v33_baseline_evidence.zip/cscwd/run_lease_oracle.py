"""V18 phase A: frozen, nondeployable, byte-optimal zero-conflict lease opportunity."""
import argparse
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from nested_validity_data import ROOT, OLD, read, write, sha, assert_frozen
from validity_survival import frame
from run_nested_survival import subject_frame
from validity_diagnostic import packet_cost
from adaptive_lease_oracle import lease_oracle, verify_lease

PREVIOUS = ROOT/'results'/'nested_validity_v17r'
OUT = ROOT/'results'/'adaptive_lease_v18'
SCENARIOS = ((1, 0), (2, 0), (2, 1))
SOURCES = ('adaptive_lease_oracle.py', 'run_lease_oracle.py', 'test_adaptive_lease.py',
           'validity_survival.py', 'validity_diagnostic.py', 'causal_score_codec.py',
           'run_nested_survival.py', 'continuous_screen_accounting.py')


def prepare():
    assert_frozen()
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = dict(version='adaptive_lease_v18', client_date='2026-10-19',
        document_sha256=sha(ROOT/'CSCWD2027_自适应刷新期限协议V18.md'), intervals=[1, 2, 4, 8, 16],
        decision_age=1, grant_bytes_per_decision=30, source_scores='nested_validity_v17r',
        head_horizons=[1, 3, 7, 15], primary='survival_epsilon0.01', thresholds=[.01, .05, .1],
        head_C=1., max_iterations=500, max_training_landmarks_per_subject=512,
        gate_is_sufficient_zero_conflict_opportunity_not_universal_impossibility_test=True,
        no_new_validation=True, no_new_test=True)
    lock = {name: sha(ROOT/name) for name in SOURCES}
    if (OUT/'protocol.json').exists():
        assert read(OUT/'protocol.json') == protocol
        assert read(OUT/'oracle_source_lock.json') == lock
        return
    paths = [PREVIOUS/name for name in ('plan.json', 'precision_correction_protocol.json', 'precision_correction_summary.json',
        'independent_verification.json', 'controller_source_lock.json', 'handoff_complete.json')]
    for group in read(PREVIOUS/'plan.json')['groups']:
        directory = PREVIOUS/'groups'/group['id']
        lineage = read(directory/'lineage.json')
        source = ROOT/lineage['evaluation_scores']
        assert sha(source) == lineage['evaluation_scores_sha256']
        paths += [directory/'complete.json', directory/'lineage.json', source]
    v15 = ROOT/'results'/'continuous_collaboration_v15'
    paths += [v15/'research_decision.json']+list(v15.glob('*/*/subject*/s2048_stride*_complete.json'))
    write(OUT/'protocol.json', protocol)
    write(OUT/'oracle_source_lock.json', lock)
    write(OUT/'oracle_inputs.json', {str(p.relative_to(ROOT)): sha(p) for p in sorted(set(paths))})
    write(OUT/'oracle_implementation_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
        source_lock_sha256=sha(OUT/'oracle_source_lock.json'), input_sha256=sha(OUT/'oracle_inputs.json'),
        protocol_sha256=sha(OUT/'protocol.json'), oracle_started=False, new_heads_fitted=False))


def check():
    for name, value in read(OUT/'oracle_source_lock.json').items():
        assert sha(ROOT/name) == value, name
    assert sha(ROOT/'CSCWD2027_自适应刷新期限协议V18.md') == read(OUT/'protocol.json')['document_sha256']


def baseline(dataset, fold, subject, stride, offset):
    root = ROOT/'results'/'continuous_collaboration_v15'
    decision = read(root/'research_decision.json')['datasets'][dataset]
    name = decision['strongest_zero_wait_control'] if stride == 1 else decision['nonoverlap'][offset]['strongest_control']
    path = root/dataset/fold/f'subject{subject}'/f's2048_stride{stride}_offset{offset}_complete.json'
    row = next(r for r in read(path)['rows'] if r['method'] == name and r['max_extra_wait_seconds'] == 0)
    return name, row['total_bytes']/row['windows']


def run():
    check()
    for name, value in read(OUT/'oracle_inputs.json').items():
        assert sha(ROOT/name) == value, name
    rows, audits, input_windows = [], 0, 0
    for group in read(PREVIOUS/'plan.json')['groups']:
        lineage = read(PREVIOUS/'groups'/group['id']/'lineage.json')
        for stride, offset in SCENARIOS:
            target = OUT/'oracle'/group['id']/f'stride{stride}_offset{offset}'
            done = target/'complete.json'
            if done.exists():
                state = read(done)
                for filename, value in state['files_sha256'].items():
                    assert sha(target/filename) == value
                rows += state['rows']
                audits += state['packet_inverse_samples']
                input_windows += sum(row['windows'] for row in state['rows'])
                continue
            held = frame(ROOT/lineage['evaluation_scores'], group['dataset'], stride, offset)
            target.mkdir(parents=True, exist_ok=True)
            result, count = [], 0
            for subject in group['controller_held_subjects']:
                f = subject_frame(held, subject)
                q, reset, n = f['q'], f['reset'], len(f['q'])
                send, grants, prediction, edges = lease_oracle(q, reset)
                verify_lease(q, reset, send, grants, prediction)
                np.testing.assert_array_equal(prediction, f['reference'])
                stamps = np.rint(f['end_time']*1e6).astype(np.int64)
                data, checks = packet_cost(q, send, reset, f['continuous_global_indices'], stamps)
                initial = np.zeros_like(send)
                initial[:, 0] = True
                initial[reset] = True
                common_data, more = packet_cost(q, initial, reset, f['continuous_global_indices'], stamps)
                grant_bytes = 30*(grants > 0).astype(np.int32)
                assert int(data.sum()+grant_bytes.sum()) == int(common_data.sum()+edges)
                prefix = 45*f['status'].astype(np.int32)+134*f['session_start'].astype(np.int32)
                total = data+grant_bytes+prefix
                method, control = baseline(group['dataset'], group['outer_fold'], subject, stride, offset)
                row = dict(dataset=group['dataset'], outer_fold=group['outer_fold'], group=group['group'],
                    subject=subject, stride=stride, offset=offset, windows=n, total_bytes=int(total.sum()),
                    bytes_per_window=float(total.mean()), baseline_method=method, baseline_bytes_per_window=control,
                    grant_decisions=int((grants > 0).sum()), grant_bytes=int(grant_bytes.sum()),
                    hypothetical_known_schedule_full_models_per_window=float(send.sum()/n),
                    actual_oracle_full_models_per_window=3., reference_disagreement=0.,
                    packet_inverse_samples=checks+more, future_information_used=True)
                result.append(row)
                count += checks+more
                np.savez_compressed(target/f'subject{subject}.npz', send=send, grants=grants,
                    prediction=prediction, total_bytes=total, continuous_global_indices=f['continuous_global_indices'])
            files = list(target.glob('*.npz'))
            write(done, dict(rows=result, packet_inverse_samples=count,
                files_sha256={p.name: sha(p) for p in files}))
            rows += result
            audits += count
            input_windows += sum(row['windows'] for row in result)
            print(f'V18 oracle {group["id"]} stride{stride}/{offset}', flush=True)
    view = pd.DataFrame(rows)
    assert len(view) == 384
    view.to_csv(OUT/'oracle_view_metrics.csv', index=False)
    subject = view.groupby(['dataset', 'stride', 'offset', 'subject'], as_index=False).mean(numeric_only=True)
    subject['positive_savings'] = subject.bytes_per_window < subject.baseline_bytes_per_window
    subject.to_csv(OUT/'oracle_subject_equal.csv', index=False)
    equal = subject.groupby(['dataset', 'stride', 'offset'], as_index=False).mean(numeric_only=True)
    equal['savings_fraction'] = 1-equal.bytes_per_window/equal.baseline_bytes_per_window
    equal.to_csv(OUT/'oracle_dataset_equal.csv', index=False)
    gates = []
    for _, row in equal.iterrows():
        item = row.to_dict()
        item['checks'] = dict(bytes=bool(row.savings_fraction >= .1), positive_subjects=bool(row.positive_savings >= .75),
            hypothetical_model_calls=bool(row.hypothetical_known_schedule_full_models_per_window <= 2.7))
        item['passed'] = all(item['checks'].values())
        gates.append(item)
    write(OUT/'oracle_gate.json', dict(client_date='2026-10-19', enter_learned_phase=all(x['passed'] for x in gates),
        scenarios=gates, scope='nondeployable byte-optimal zero-conflict oracle under frozen interval and grant protocol',
        actual_oracle_observes_all_nodes_and_future=True, hypothetical_calls_not_cpu_measurement=True,
        failed_gate_not_a_proof_for_all_policies_allowing_one_percent_error=True))
    write(OUT/'oracle_audit.json', dict(scenarios=384, input_windows=input_windows,
        all_predictions_equal_integer_reference=True, all_grants_and_cached_outputs_independently_reconstructed=True,
        all_dynamic_program_edge_totals_equal_actual_schedule_packet_lengths=True,
        stratified_packet_inverse_samples=audits, full_wire_replay=False,
        source_lock_sha256=sha(OUT/'oracle_source_lock.json')))
    print(read(OUT/'oracle_gate.json'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        prepare() if args.prepare_only else run()
