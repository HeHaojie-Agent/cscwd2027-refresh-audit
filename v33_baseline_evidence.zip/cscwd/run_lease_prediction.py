"""V18 phase B, strictly nested paid deadline learners and matched controls."""
import argparse
from datetime import datetime, timezone
import time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from nested_validity_data import ROOT, DATA, read, write, sha
from run_lease_oracle import OUT, PREVIOUS, SCENARIOS, check as oracle_check, baseline
from run_nested_survival import subject_frame
from validity_survival import frame
from lease_prediction import KINDS, landmarks, fit_models, weight_packet, lease_schedule, verify_decisions, risk_metrics
from adaptive_lease_oracle import verify_lease
from validity_diagnostic import packet_cost, profile, longest_error
from survival_schedule import run_schedule, verify_schedule
from continuous_screen_accounting import latency, macro_f1
from run_validity_diagnostic import onset_metrics

SOURCES = ('lease_prediction.py', 'run_lease_prediction.py', 'test_lease_prediction.py',
    'adaptive_lease_oracle.py', 'run_lease_oracle.py', 'validity_survival.py',
    'survival_schedule.py', 'validity_diagnostic.py', 'continuous_screen_accounting.py',
    'causal_score_codec.py', 'run_validity_diagnostic.py', 'run_nested_survival.py')


def jsonable(value):
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def prepare():
    oracle_check()
    assert read(OUT/'oracle_gate.json')['enter_learned_phase']
    lock = {name: sha(ROOT/name) for name in SOURCES}
    inputs = {}
    for group in read(PREVIOUS/'plan.json')['groups']:
        directory = PREVIOUS/'groups'/group['id']
        lineage = read(directory/'lineage.json')
        for path in (directory/'training_scores.npz', directory/'complete.json', directory/'lineage.json',
                     ROOT/lineage['evaluation_scores']):
            inputs[str(path.relative_to(ROOT))] = sha(path)
    for name in ('protocol.json', 'oracle_gate.json', 'oracle_inputs.json', 'oracle_audit.json'):
        inputs[str((OUT/name).relative_to(ROOT))] = sha(OUT/name)
    if (OUT/'learner_source_lock.json').exists():
        assert read(OUT/'learner_source_lock.json') == lock
        assert read(OUT/'learner_inputs.json') == inputs
        return
    write(OUT/'learner_source_lock.json', lock)
    write(OUT/'learner_inputs.json', inputs)
    write(OUT/'learner_implementation_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
        source_lock_sha256=sha(OUT/'learner_source_lock.json'), inputs_sha256=sha(OUT/'learner_inputs.json'),
        protocol_sha256=sha(OUT/'protocol.json'), real_v18_head_fitting_started=False,
        constant_scaler_columns='exactly constant columns get mean=x0 and scale=1; StandardScaler on variable columns',
        no_new_validation=True, no_new_test=True))


def check(inputs=True):
    oracle_check()
    for name, value in read(OUT/'learner_source_lock.json').items():
        assert sha(ROOT/name) == value, name
    if inputs:
        for name, value in read(OUT/'learner_inputs.json').items():
            assert sha(ROOT/name) == value, name


def policies(models):
    result = [(f'periodic_h{h}', h, 0., None) for h in (1, 2, 4, 8, 16)]
    for kind in KINDS:
        result += [(f'{kind}_t{t:g}', 16, float(np.float32(t)), models[kind]) for t in (.01, .05, .1)]
    return result+[('complete_rice3', 1, 0., None)]


def evaluate(f, group, stride, offset, models):
    q, reset = f['q'], f['reset']
    n, subject = len(q), int(f['subjects'][0])
    windows = f['continuous_global_indices']
    stamps = np.rint(f['end_time']*1e6).astype(np.int64)
    events = pd.read_csv(DATA/group['dataset']/'records'/f'subject{subject}'/'annotated_onsets.csv').to_dict('records')
    known = f['endpoint_targets'] != -1
    classes, reference = f['classes'], f['reference']
    ref_f1 = macro_f1(f['endpoint_targets'][known], classes[reference[known]], classes)
    common = dict(dataset=group['dataset'], outer_fold=group['outer_fold'], group=group['group'],
        subject=subject, stride=stride, offset=offset, windows=n)
    control_name, control_bytes = baseline(group['dataset'], group['outer_fold'], subject, stride, offset)
    rows, onsets, saved = [], [], {}
    for policy_id, (name, horizon, threshold, model) in enumerate(policies(models)):
        if model:
            send, grants, pred = lease_schedule(q, reset, np.asarray(model['matrix']), np.asarray(model['intercept']),
                KINDS.index(model['kind']), threshold)
            verify_lease(q, reset, send, grants, pred)
            verify_decisions(f, model, threshold, send, grants)
        else:
            result = run_schedule(q, reset, 0, horizon, 0., np.zeros(57), 0.)
            send, requests, pred, _ = result
            assert not requests.any()
            verify_schedule(q, reset, 0, horizon, 0., None, result)
            grants = np.zeros(n, np.int16)
        data, checks = packet_cost(q, send, reset, windows, stamps, 'rice3' if name == 'complete_rice3' else 'rice2')
        assert sum(map(len, profile(policy_id, horizon, threshold))) == 134
        weights = weight_packet(model) if model else b''
        prefix = 45*f['status'].astype(np.int32)+(134+len(weights))*f['session_start'].astype(np.int32)
        extra = 30*(grants > 0).astype(np.int32)
        total = data+prefix+extra
        messages = 3*f['status'].astype(np.int32)+(4+int(bool(weights)))*f['session_start'].astype(np.int32)
        messages = messages+send.sum(1)+2*(grants > 0)
        timing = latency(f['end_time'], np.arange(n), np.ones(n, int), total, messages, np.zeros(n, int), np.zeros(n, int), 0)
        channel = timing['latency_250000_1_ms']
        error = pred != reference
        f1 = macro_f1(f['endpoint_targets'][known], classes[pred[known]], classes)
        metadata = dict(**common, method=name)
        row = dict(**metadata, total_bytes=int(total.sum()), bytes_per_window=float(total.mean()),
            baseline_method=control_name, baseline_bytes_per_window=control_bytes,
            score_bytes=int(data.sum()), grant_bytes=int(extra.sum()), setup_status_bytes=int(prefix.sum()),
            weight_deployment_bytes=int(len(weights)*f['session_start'].sum()), grant_decisions=int((grants > 0).sum()),
            full_model_calls=int(send.sum()), full_models_per_window=float(send.sum()/n),
            deployable_full_models_per_window=float(send.sum()/n), controller_calls=int((grants > 0).sum()),
            reference_mismatches=int(error.sum()), reference_disagreement=float(error.mean()),
            known_endpoint_macro_f1=f1, known_endpoint_reference_f1=ref_f1, known_endpoint_macro_f1_drop=ref_f1-f1,
            longest_reference_error_windows=longest_error(pred, reference, reset),
            channel_p95_ms=float(np.quantile(channel, .95)), packet_inverse_samples=checks,
            known_windows=int(known.sum()), unknown_windows=int((~known).sum()))
        for node in range(3):
            row[f'node{node}_calls'] = int(send[:, node].sum())
        for kind in ('pure_known', 'mixed', 'unknown_only'):
            select = f['window_kind'] == kind
            row[f'{kind}_windows'] = int(select.sum())
            row[f'{kind}_reference_disagreement'] = float(error[select].mean()) if select.any() else None
        rows.append(row)
        onsets += onset_metrics(f, pred, channel, events, metadata)
        key = f'm{policy_id}_'
        saved.update({key+'send': send, key+'grants': grants, key+'prediction': pred,
            key+'total_bytes': total, key+'channel_ms': channel})
    saved.update(continuous_global_indices=windows, reset=reset)
    return saved, dict(metrics=rows, onsets=onsets)


def run(limit=None):
    check()
    completed = 0
    for group in read(PREVIOUS/'plan.json')['groups']:
        directory = PREVIOUS/'groups'/group['id']
        lineage = read(directory/'lineage.json')
        assert sha(directory/'training_scores.npz') == read(directory/'complete.json')['train_sha256']
        for stride, offset in SCENARIOS:
            target = OUT/'learners'/group['id']/f'stride{stride}_offset{offset}'
            done = target/'complete.json'
            if done.exists():
                for name, value in read(done)['files_sha256'].items():
                    assert sha(target/name) == value, name
                completed += 1
                continue
            begun = time.perf_counter()
            training = frame(directory/'training_scores.npz', group['dataset'], stride, offset)
            held = frame(ROOT/lineage['evaluation_scores'], group['dataset'], stride, offset)
            np.testing.assert_array_equal(np.unique(training['subjects']), group['controller_train_subjects'])
            np.testing.assert_array_equal(np.unique(held['subjects']), group['controller_held_subjects'])
            assert set(training['subjects']).isdisjoint(held['subjects'])
            train = landmarks(training, True)
            models = fit_models(train)
            target.mkdir(parents=True, exist_ok=True)
            write(target/'models.json', jsonable(models))
            for kind, model in models.items():
                (target/f'{kind}_deployment.bin').write_bytes(weight_packet(model))
            write(target/'lineage.json', dict(group=group, training_scores_sha256=sha(directory/'training_scores.npz'),
                evaluation_scores_sha256=sha(ROOT/lineage['evaluation_scores']),
                training_landmarks=len(train['first']), training_landmark_ids=training['continuous_global_indices'][train['current']].tolist(),
                source_lock_sha256=sha(OUT/'learner_source_lock.json'), no_held_subject_in_head_fit=True))
            test = landmarks(held)
            risk = [dict(dataset=group['dataset'], outer_fold=group['outer_fold'], group=group['group'],
                stride=stride, offset=offset, **row) for model in models.values() for row in risk_metrics(model, test)]
            write(target/'risk_metrics.json', risk)
            all_rows, all_onsets = [], []
            for subject in group['controller_held_subjects']:
                arrays, results = evaluate(subject_frame(held, subject), group, stride, offset, models)
                np.savez_compressed(target/f'subject{subject}_trace.npz', **arrays)
                all_rows += results['metrics']
                all_onsets += results['onsets']
            write(target/'metrics.json', all_rows)
            write(target/'onsets.json', all_onsets)
            files = [p for p in target.iterdir() if p.is_file() and p.name != 'complete.json']
            write(done, dict(files_sha256={p.name: sha(p) for p in files}, elapsed_seconds=time.perf_counter()-begun))
            completed += 1
            print(f'V18 learned {completed}/192 {group["id"]} stride{stride}/{offset}', flush=True)
            if limit and completed >= limit:
                return
    assert completed == 192
    write(OUT/'learner_run_complete.json', dict(cases=completed, fitted_predictor_sets=completed*3,
        held_subject_scenarios=384, methods=15, source_lock_sha256=sha(OUT/'learner_source_lock.json'),
        completed_utc=datetime.now(timezone.utc).isoformat()))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        prepare() if args.prepare_only else run(args.limit)
