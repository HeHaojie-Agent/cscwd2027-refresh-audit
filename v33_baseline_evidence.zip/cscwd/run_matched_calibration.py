"""V20 common-source calibrators and paid closed-loop comparisons."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[name]='1'
import argparse
from datetime import datetime,timezone
import gc
import time
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from matched_calibration_data import ROOT,BASE,HEADS,OUT,SCENARIOS,read,write,sha,check as data_check
from validity_survival import frame,logistic
from lease_prediction import (landmarks,fit_models,probabilities as full_probabilities,
    weight_packet as full_packet,lease_schedule as full_schedule,verify_decisions as verify_full,risk_metrics as full_risk)
from scalar_risk_calibration import (fit_calibrators,current_probability,scalar_probabilities,
    weight_packet as scalar_packet,parse_weight_packet,runtime_parameters,
    lease_schedule as scalar_schedule,verify_decisions as verify_scalar,risk_metrics as scalar_risk)
from run_nested_survival import subject_frame
from run_lease_prediction import jsonable
from adaptive_lease_oracle import verify_lease
from survival_schedule import run_schedule,verify_schedule
from validity_diagnostic import packet_cost,profile,longest_error
from continuous_screen_accounting import latency,macro_f1,setup_packets
from continuous_causal_controls import METHODS
from run_validity_diagnostic import onset_metrics
from continuous_training_data import OUT as DATA

KINDS=('geometric','platt','isotonic','direct','survival')


def prepare():
    data_check(True)
    assert (OUT/'data_complete.json').exists()
    names=('run_matched_calibration.py','test_matched_controller.py','lease_prediction.py','scalar_risk_calibration.py',
        'validity_survival.py','validity_diagnostic.py','survival_schedule.py','adaptive_lease_oracle.py',
        'continuous_screen_accounting.py','continuous_causal_controls.py','causal_score_codec.py',
        'run_validity_diagnostic.py','run_nested_survival.py','run_lease_prediction.py',
        'audit_matched_calibration.py','summarize_matched_calibration.py','test_matched_summary.py')
    sources={name:sha(ROOT/name) for name in names}
    inputs={str(p.relative_to(ROOT)):sha(p) for p in (OUT/'plan.json',OUT/'data_frozen.json',OUT/'data_complete.json',
        ROOT/'results/continuous_collaboration_v15/research_decision.json')}
    for path in (OUT/'score_views').rglob('*'):
        if path.is_file():inputs[str(path.relative_to(ROOT))]=sha(path)
    for case in read(OUT/'plan.json')['cases']:
        for subject in case['evaluation_subjects']:
            path=DATA/case['dataset']/'records'/f'subject{subject}'/'annotated_onsets.csv'
            inputs[str(path.relative_to(ROOT))]=sha(path)
    if (OUT/'controller_frozen.json').exists():
        locked=read(OUT/'controller_source_revision1.json')['sources'] if (OUT/'controller_source_revision1.json').exists() else read(OUT/'controller_sources.json')
        assert locked==sources
        assert read(OUT/'controller_inputs.json')==inputs
    else:
        write(OUT/'controller_sources.json',sources);write(OUT/'controller_inputs.json',inputs)
        write(OUT/'controller_frozen.json',dict(client_date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
            new_head_fitting_started=False,source_sha256=sha(OUT/'controller_sources.json'),input_sha256=sha(OUT/'controller_inputs.json'),
            directions=128,cases=384,methods=22,expected_subject_policy_traces=16896))
    print(read(OUT/'controller_frozen.json'),flush=True)


def check(inputs=True):
    data_check()
    locked=read(OUT/'controller_source_revision1.json')['sources'] if (OUT/'controller_source_revision1.json').exists() else read(OUT/'controller_sources.json')
    for name,value in locked.items():assert sha(ROOT/name)==value,name
    if inputs:
        for name,value in read(OUT/'controller_inputs.json').items():assert sha(ROOT/name)==value,name


def fit_matched(data,head):
    params=np.r_[head['coefficient'],head['intercept']]
    assert len(params)==53 and set(head['subjects']).isdisjoint(np.unique(data['subjects']))
    models=fit_models(data)
    models['geometric']=dict(kind='geometric',matrix=np.tile(params[:52],(4,1)),intercept=np.repeat(params[52],4),
        parameters=params,training_subjects=head['subjects'],heads=[head])
    p=logistic(data['x']@params[:52]+params[52])
    models.update(fit_calibrators(data,p,params))
    for kind in KINDS:
        model=models[kind]
        packet=pack(model)
        if kind in ('platt','isotonic'):
            restored=parse_weight_packet(packet)
            np.testing.assert_allclose(scalar_probabilities(restored,p),scalar_probabilities(model,p),atol=1e-14)
        else:
            values=np.frombuffer(packet[30:],'<f8')
            np.testing.assert_array_equal(values,np.asarray(model['parameters']))
    return models,p


def pack(model):
    return scalar_packet(model) if model['kind'] in ('platt','isotonic') else full_packet(model)


def forecasts(model,data):
    return scalar_probabilities(model,current_probability(model,data['x'])) if model['kind'] in ('platt','isotonic') else full_probabilities(model,data['x'])


def policies(models):
    result=[]
    for kind in KINDS:
        for t in (.01,.05,.1):result.append((f'{kind}_t{t:g}',models[kind],float(np.float32(t)),None))
    result += [(f'periodic_h{h}',None,0.,h) for h in (1,2,4,8,16)]
    result += [(f'complete_{codec}',None,0.,1) for codec in ('rice2','rice3')]
    assert len(result)==22
    return result


def fixed_baseline_name(dataset,stride,offset):
    old=read(ROOT/'results/continuous_collaboration_v15/research_decision.json')['datasets'][dataset]
    return old['strongest_zero_wait_control'] if stride==1 else old['nonoverlap'][offset]['strongest_control']


def schedule(f,model,threshold,horizon):
    q,reset=f['q'],f['reset']
    if model is None:
        result=run_schedule(q,reset,0,horizon,0.,np.zeros(57),0.)
        verify_schedule(q,reset,0,horizon,0.,None,result)
        sent,_,pred,_=result
        grants=np.zeros(len(q),np.int16)
    elif model['kind'] in ('platt','isotonic'):
        sent,grants,pred=scalar_schedule(q,reset,runtime_parameters(model),('platt','isotonic').index(model['kind']),threshold)
        verify_scalar(f,model,threshold,sent,grants)
    else:
        sent,grants,pred=full_schedule(q,reset,np.asarray(model['matrix']),np.asarray(model['intercept']),
            ('geometric','direct','survival').index(model['kind']),threshold)
        verify_full(f,model,threshold,sent,grants)
    if model is not None:verify_lease(q,reset,sent,grants,pred)
    return sent,grants,pred


def accounting(f,sent,grants,model,codec,complete=False,policy_id=0,horizon=16,threshold=.01):
    threshold=float(np.float32(threshold))
    stamps=np.rint(f['end_time']*1e6).astype(np.int64)
    score,inverses=packet_cost(f['q'],sent,f['reset'],f['continuous_global_indices'],stamps,codec)
    if complete:
        assert model is None and not grants.any()
        assert sum(map(len,setup_packets(METHODS.index(codec),0)))==116
        config=116;weights=b''
    else:
        assert sum(map(len,profile(policy_id,horizon,threshold)))==134
        config=134;weights=pack(model) if model else b''
    setup=45*f['status'].astype(np.int32)+config*f['session_start'].astype(np.int32)
    deployment=len(weights)*f['session_start'].astype(np.int32)
    notices=30*(grants>0).astype(np.int32)
    total=score+setup+deployment+notices
    messages=sent.sum(1)+2*(grants>0)+3*f['status']+(4+int(bool(weights)))*f['session_start']
    channel=latency(f['end_time'],np.arange(len(sent)),np.ones(len(sent),int),total,messages,
        np.zeros(len(sent),int),np.zeros(len(sent),int),0)['latency_250000_1_ms']
    return total,channel,dict(score_bytes=int(score.sum()),grant_bytes=int(notices.sum()),
        configuration_status_bytes=int(setup.sum()),weight_deployment_bytes=int(deployment.sum()),
        setup_status_bytes=int((setup+deployment).sum()),packet_inverse_samples=inverses)


def evaluate(f,case,stride,offset,models):
    n=len(f['q']);subject=int(f['subjects'][0]);classes=f['classes'];reference=f['reference']
    known=f['endpoint_targets']!=-1
    ref_f1=macro_f1(f['endpoint_targets'][known],classes[reference[known]],classes)
    events=pd.read_csv(DATA/case['dataset']/'records'/f'subject{subject}'/'annotated_onsets.csv').to_dict('records')
    codec=fixed_baseline_name(case['dataset'],stride,offset)
    baseline_total,_,_=accounting(f,np.ones((n,3),bool),np.zeros(n,np.int16),None,codec,True)
    common=dict(dataset=case['dataset'],outer_fold=case['outer_fold'],group=case['group'],direction=case['direction'],
        subject=subject,stride=stride,offset=offset,windows=n)
    rows=[];onsets=[]
    saved=dict(continuous_global_indices=f['continuous_global_indices'],reset=f['reset'])
    for policy_id,(name,model,threshold,h) in enumerate(policies(models)):
        sent,grants,pred=schedule(f,model,threshold,h)
        is_complete=name.startswith('complete_')
        codec_now=name.removeprefix('complete_') if is_complete else 'rice2'
        total,channel,fees=accounting(f,sent,grants,model,codec_now,is_complete,policy_id,h or 16,threshold)
        if name=='complete_'+codec:np.testing.assert_array_equal(total,baseline_total)
        f1=macro_f1(f['endpoint_targets'][known],classes[pred[known]],classes)
        row=dict(**common,method=name,baseline_method='complete_'+codec,baseline_bytes_per_window=float(baseline_total.mean()),
            total_bytes=int(total.sum()),bytes_per_window=float(total.mean()),**fees,grant_decisions=int((grants>0).sum()),
            full_model_calls=int(sent.sum()),full_models_per_window=float(sent.sum()/n),deployable_full_models_per_window=float(sent.sum()/n),
            controller_calls=int((grants>0).sum()),reference_mismatches=int((pred!=reference).sum()),
            reference_disagreement=float((pred!=reference).mean()),known_endpoint_macro_f1=f1,
            known_endpoint_reference_f1=ref_f1,known_endpoint_macro_f1_drop=ref_f1-f1,
            longest_reference_error_windows=longest_error(pred,reference,f['reset']),channel_p95_ms=float(np.quantile(channel,.95)),
            known_windows=int(known.sum()),unknown_windows=int((~known).sum()))
        for node in range(3):row[f'node{node}_calls']=int(sent[:,node].sum())
        for window_kind in ('pure_known','mixed','unknown_only'):
            at=f['window_kind']==window_kind
            row[window_kind+'_windows']=int(at.sum())
            row[window_kind+'_reference_disagreement']=float((pred!=reference)[at].mean()) if at.any() else None
        rows.append(row)
        onsets += onset_metrics(f,pred,channel,events,dict(**common,method=name))
        prefix=f'm{policy_id}_'
        saved.update({prefix+'send':sent,prefix+'grants':grants,prefix+'prediction':pred,prefix+'total_bytes':total,prefix+'channel_ms':channel})
    return saved,rows,onsets


def describe(p):
    return dict(n=len(p),mean=float(np.mean(p)),std=float(np.std(p)),minimum=float(np.min(p)),maximum=float(np.max(p)),
        q05=float(np.quantile(p,.05)),median=float(np.median(p)),q95=float(np.quantile(p,.95)))


def run(limit=None):
    check()
    count=0
    for case in read(OUT/'plan.json')['cases']:
        for stride,offset in SCENARIOS:
            target=OUT/'controllers'/case['id']/f'stride{stride}_offset{offset}'
            done=target/'complete.json'
            count+=1
            if done.exists():
                for name,value in read(done)['files_sha256'].items():assert sha(target/name)==value
                continue
            started=time.perf_counter()
            head_path=HEADS/'current_heads'/case['current_head_id']/f'stride{stride}_offset{offset}.json'
            head=read(head_path)
            b=frame(OUT/'score_views'/case['id']/'calibration.npz',case['dataset'],stride,offset)
            a=frame(OUT/'score_views'/case['id']/'evaluation.npz',case['dataset'],stride,offset)
            training=landmarks(b,True);test=landmarks(a)
            models,p_b=fit_matched(training,head)
            p_a=current_probability(models['platt'],test['x'])
            np.testing.assert_array_equal(models['platt']['current_parameters'],models['isotonic']['current_parameters'])
            np.testing.assert_array_equal(models['platt']['current_parameters'],models['geometric']['parameters'])
            target.mkdir(parents=True,exist_ok=True)
            write(target/'models.json',jsonable(models))
            for kind,model in models.items():(target/f'{kind}_deployment.bin').write_bytes(pack(model))
            write(target/'lineage.json',dict(case=case,current_head_sha256=sha(head_path),current_head_unchanged_B_and_A=True,
                node_models_identical_B_and_A=True,current_parameters_sha256=__import__('hashlib').sha256(np.asarray(models['platt']['current_parameters'],'<f8').tobytes()).hexdigest(),
                calibration_scores_sha256=sha(OUT/'score_views'/case['id']/'calibration.npz'),
                evaluation_scores_sha256=sha(OUT/'score_views'/case['id']/'evaluation.npz')))
            write(target/'probability_shift.json',dict(calibration=describe(p_b),evaluation=describe(p_a),
                evaluation_below_calibration_range=float((p_a<p_b.min()).mean()),evaluation_above_calibration_range=float((p_a>p_b.max()).mean()),
                current_head_fit_subjects=head['subjects'],training_and_evaluation_use_same_head=True))
            np.savez_compressed(target/'prediction_outputs.npz',training_current_probability=p_b,evaluation_current_probability=p_a,
                evaluation_subjects=test['subjects'],evaluation_first=test['first'],evaluation_observed=test['observed'],
                **{kind:forecasts(model,test) for kind,model in models.items()})
            risk=[]
            for model in models.values():
                metrics=scalar_risk(model,test) if model['kind'] in ('platt','isotonic') else full_risk(model,test)
                risk += [dict(dataset=case['dataset'],outer_fold=case['outer_fold'],group=case['group'],direction=case['direction'],stride=stride,offset=offset,**r) for r in metrics]
            write(target/'risk_metrics.json',risk)
            rows=[];events=[]
            for subject in case['evaluation_subjects']:
                arrays,metrics,onsets=evaluate(subject_frame(a,subject),case,stride,offset,models)
                np.savez_compressed(target/f'subject{subject}_trace.npz',**arrays)
                rows+=metrics;events+=onsets
            write(target/'metrics.json',rows);write(target/'onsets.json',events)
            write(done,dict(files_sha256={p.name:sha(p) for p in target.iterdir() if p.is_file() and p.name!='complete.json'},
                elapsed_seconds=time.perf_counter()-started))
            print(f'V20 controller {count}/384 {case["id"]} grid{stride}/{offset} {time.perf_counter()-started:.1f}s',flush=True)
            gc.collect()
            if limit and count>=limit:return
    assert count==384
    write(OUT/'controller_complete.json',dict(cases=count,predictor_sets=5*count,subject_policy_traces=16896,
        completed_utc=datetime.now(timezone.utc).isoformat(),new_outer_validation_or_test=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--limit',type=int)
    a=parser.parse_args()
    with threadpool_limits(limits=1):prepare() if a.prepare_only else run(a.limit)
