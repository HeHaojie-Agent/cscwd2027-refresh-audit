"""V17 subject-held evaluation; freeze controller implementation before fitting."""
import argparse
import time
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

from nested_validity_data import ROOT, OLD, OUT, DATA, CONFIG, read, write, sha, assert_frozen
from validity_survival import frame, landmarks, fit_predictor, prediction_metrics, weight_packet
from survival_schedule import run_schedule, verify_schedule
from validity_diagnostic import packet_cost, profile, schedule, independent_schedule_check, longest_error
from continuous_screen_accounting import latency, macro_f1
from run_validity_diagnostic import onset_metrics

SCENARIOS = ((1, 0), (2, 0), (2, 1))
SOURCES = ('validity_survival.py', 'survival_schedule.py', 'run_nested_survival.py',
           'test_survival_prediction.py', 'test_nested_validity.py')


def prepare():
    assert_frozen()
    lock = {name: sha(ROOT/name) for name in SOURCES}
    implementation = dict(independent_controller_fit_per_stride_offset=True,
        reason='ages, labels and two-window risk refer to each actual sampling grid',
        future_horizon_binary_metrics='same current-conflict probability as explicitly labelled proxy; no recalibration',
        constant_brier='training-subject-weighted empirical bin hazards, 0.5 pseudocount',
        evaluation='only complete followup at each horizon, censoring coverage also reported',
        wire_threshold='nominal decimal thresholds rounded to transmitted IEEE float32 before online decisions',
        main='survival_t0.01', maxage=16, thresholds=[.01, .05, .1], primary_node=0)
    if (OUT/'controller_source_lock.json').exists():
        assert read(OUT/'controller_source_lock.json') == lock
        assert read(OUT/'controller_implementation.json') == implementation
    else:
        write(OUT/'controller_source_lock.json', lock)
        write(OUT/'controller_implementation.json', implementation)
        write(OUT/'controller_implementation_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
            source_lock_sha256=sha(OUT/'controller_source_lock.json'),
            implementation_sha256=sha(OUT/'controller_implementation.json'), head_fitting_started=False))


def check():
    assert_frozen()
    for name, value in read(OUT/'controller_source_lock.json').items():
        assert sha(ROOT/name) == value, name


def subject_frame(f, subject):
    select = f['subjects'] == subject
    return {key: value if key == 'classes' else value[select] for key, value in f.items()}


def raw_features(f, dataset, subject):
    path = ROOT/'results'/'collaboration_validity_v16'/'raw_features'/f'{dataset}_subject{subject}.npz'
    metadata = read(path.with_suffix('.json'))
    assert sha(path) == metadata['file_sha256']
    with np.load(path, allow_pickle=False) as saved:
        ids = saved['continuous_global_indices']
        where = np.searchsorted(ids, f['continuous_global_indices'])
        np.testing.assert_array_equal(ids[where], f['continuous_global_indices'])
        return saved['features'][where]


def evaluate(f, dataset, group, stride, offset, models):
    rows, onsets, saved = [], [], {}
    n = len(f['q'])
    q, reset = f['q'], f['reset']
    windows = f['continuous_global_indices']
    stamps = np.rint(f['end_time']*1e6).astype(np.int64)
    subject = int(f['subjects'][0])
    features = raw_features(f, dataset, subject)
    events = pd.read_csv(DATA/dataset/'records'/f'subject{subject}'/'annotated_onsets.csv').to_dict('records')
    policies = [(f'periodic_h{h}', 0, h, 0., None) for h in (1, 2, 4, 8, 16)]
    for kind, mode in [('survival', 1), ('current', 2)]:
        policies += [(f'{kind}_t{t:g}', mode, 16, t, models[kind]) for t in (.01, .05, .1)]
    policies += [(f'gap_t{t}', 3, 16, float(t), None) for t in (4, 16, 32)]
    policies += [('sentinel_h8_t0.25', 4, 8, .25, None)]
    # Strong complete-push Rice3 control matters for MHEALTH; main codec stays Rice2.
    policies += [('complete_rice3', 5, 1, 0., None)]
    reference = f['reference']
    classes = f['classes']
    known = f['endpoint_targets'] != -1
    ref_f1 = macro_f1(f['endpoint_targets'][known], classes[reference[known]], classes)
    common = dict(dataset=dataset, outer_fold=group['outer_fold'], group=group['group'],
                  subject=subject, stride=stride, offset=offset, windows=n)
    for policy_id, (name, mode, horizon, threshold, model) in enumerate(policies):
        threshold = float(np.float32(threshold))
        if mode == 4:
            send, requests, pred = schedule(q, features, reset, 0, 1, horizon, threshold)
            independent_schedule_check(q, features, reset, 0,
                                       dict(mode=1, horizon=horizon, threshold=threshold), send, requests, pred)
        else:
            coefficient = np.asarray(model['coefficient']) if model else np.zeros(57)
            intercept = model['intercept'] if model else 0.
            result = run_schedule(q, reset, min(mode, 3) if mode != 5 else 0,
                                  horizon, threshold, coefficient, intercept)
            send, requests, pred, probabilities = result
            verify_schedule(q, reset, min(mode, 3) if mode != 5 else 0,
                            horizon, threshold, model, result)
        data_bytes, checks = packet_cost(q, send, reset, windows, stamps, 'rice3' if mode == 5 else 'rice2')
        packets = profile(policy_id, horizon, threshold)
        assert sum(map(len, packets)) == 134
        weights = weight_packet(model) if model else b''
        prefix = 45*f['status'].astype(np.int32)+(134+len(weights))*f['session_start'].astype(np.int32)
        prefix_messages = 3*f['status'].astype(np.int32)+(4+int(bool(weights)))*f['session_start'].astype(np.int32)
        query_bytes = 14*requests.sum(1).astype(np.int32)
        byte_count = prefix+query_bytes+data_bytes
        messages = prefix_messages+requests.sum(1)+send.sum(1)
        timing = latency(f['end_time'], np.arange(n), np.ones(n, int), byte_count, messages,
                         np.zeros(n, int), np.zeros(n, int), 0)
        error = pred != reference
        endpoint_f1 = macro_f1(f['endpoint_targets'][known], classes[pred[known]], classes)
        metadata = dict(**common, method=name)
        row = dict(**metadata, total_bytes=int(byte_count.sum()), bytes_per_window=float(byte_count.mean()),
            score_bytes=int(data_bytes.sum()), query_bytes=int(query_bytes.sum()),
            setup_status_bytes=int(prefix.sum()), weight_deployment_bytes=int(len(weights)*f['session_start'].sum()),
            full_model_calls=int(send.sum()), full_models_per_window=float(send.sum()/n),
            sentinel_calls=int(2*n if mode == 4 else 0), controller_calls=int((~reset).sum() if model else 0),
            reference_mismatches=int(error.sum()), reference_disagreement=float(error.mean()),
            known_endpoint_macro_f1=endpoint_f1, known_endpoint_reference_f1=ref_f1,
            known_endpoint_macro_f1_drop=ref_f1-endpoint_f1,
            longest_reference_error_windows=longest_error(pred, reference, reset),
            channel_p95_ms=float(np.quantile(timing['latency_250000_1_ms'], .95)),
            packet_inverse_samples=checks, known_windows=int(known.sum()), unknown_windows=int((~known).sum()))
        for node in range(3):
            row[f'node{node}_calls'] = int(send[:, node].sum())
        for kind in ('pure_known', 'mixed', 'unknown_only'):
            select = f['window_kind'] == kind
            row[f'{kind}_windows'] = int(select.sum())
            row[f'{kind}_reference_disagreement'] = float(error[select].mean()) if select.any() else None
        rows.append(row)
        onsets += onset_metrics(f, pred, timing['latency_250000_1_ms'], events, metadata)
        key = f'm{policy_id}_'
        saved.update({key+'send': send, key+'requests': requests, key+'prediction': pred,
                      key+'total_bytes': byte_count, key+'channel_ms': timing['latency_250000_1_ms']})
    saved.update(continuous_global_indices=windows, reset=reset)
    return saved, dict(metrics=rows, onsets=onsets)


def run():
    check()
    assert (OUT/'base_fit_complete.json').exists(), 'Complete nested base scores first'
    assert read(OUT/'base_fit_complete.json')['groups_completed'] == 64
    for group in read(OUT/'plan.json')['groups']:
        directory = OUT/'groups'/group['id']
        lineage = read(directory/'lineage.json')
        assert sha(directory/'training_scores.npz') == read(directory/'complete.json')['train_sha256']
        eval_path = ROOT/lineage['evaluation_scores']
        assert sha(eval_path) == lineage['evaluation_scores_sha256']
        for stride, offset in SCENARIOS:
            begun = time.perf_counter()
            target = OUT/'controllers'/group['id']/f'stride{stride}_offset{offset}'
            done = target/'complete.json'
            if done.exists():
                for name, value in read(done)['files_sha256'].items():
                    assert sha(target/name) == value
                continue
            training = frame(directory/'training_scores.npz', group['dataset'], stride, offset)
            held = frame(eval_path, group['dataset'], stride, offset)
            np.testing.assert_array_equal(np.unique(training['subjects']), group['controller_train_subjects'])
            np.testing.assert_array_equal(np.unique(held['subjects']), group['controller_held_subjects'])
            train_data = landmarks(training, training=True)
            eval_data = landmarks(held)
            models, risk_rows = {}, []
            target.mkdir(parents=True, exist_ok=True)
            for kind in ('survival', 'current'):
                model = fit_predictor(train_data, kind)
                assert not set(model['training_subjects']) & set(group['controller_held_subjects'])
                models[kind] = model
                (target/f'{kind}_deployment.bin').write_bytes(weight_packet(model))
                risk_rows += [dict(dataset=group['dataset'], outer_fold=group['outer_fold'],
                    group=group['group'], stride=stride, offset=offset, **row)
                    for row in prediction_metrics(model, eval_data)]
            write(target/'models.json', {kind: {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in model.items()}
                                        for kind, model in models.items()})
            write(target/'lineage.json', dict(group=group, training_scores_sha256=sha(directory/'training_scores.npz'),
                evaluation_scores_sha256=sha(eval_path), training_landmarks=len(train_data['x']),
                evaluation_landmarks=len(eval_data['x']), controller_source_lock_sha256=sha(OUT/'controller_source_lock.json')))
            metric_rows, onset_rows = [], []
            for subject in group['controller_held_subjects']:
                saved, result = evaluate(subject_frame(held, subject), group['dataset'], group, stride, offset, models)
                np.savez_compressed(target/f'subject{subject}_trace.npz', **saved)
                metric_rows += result['metrics']
                onset_rows += result['onsets']
            write(target/'results.json', dict(risk=risk_rows, metrics=metric_rows, onsets=onset_rows))
            files = [*target.glob('*.json'), *target.glob('*.npz'), *target.glob('*.bin')]
            write(done, dict(files_sha256={p.name: sha(p) for p in files}, elapsed_seconds=time.perf_counter()-begun))
            print(f'V17 controllers {group["id"]} stride{stride}/{offset} complete in {time.perf_counter()-begun:.1f}s', flush=True)
    write(OUT/'controller_fit_complete.json', dict(cases_completed=len(list((OUT/'controllers').glob('*/*/*/*/complete.json'))),
          independent_cases=192, models_per_case=2, no_new_validation=True, no_new_test=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    with threadpool_limits(limits=1):
        prepare() if args.prepare_only else run()
