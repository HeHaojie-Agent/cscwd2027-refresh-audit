"""Subject-disjoint statistical/MiniRocket baselines with saved predictions.

No model is proposed here. Equal-score fusion is a fixed baseline. All search
decisions are committed before this runner makes test predictions for a fold.
"""
from __future__ import annotations
import os
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
os.environ['NUMBA_NUM_THREADS']='1'
import argparse
import hashlib
import json
import platform
import struct
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import psutil
import sklearn
from sklearn.linear_model import RidgeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from prepare_pamap2 import ACTIVITIES, NODES, OUT, SUBJECTS, write_json

if __name__=='__main__':
    sys.modules['run_pamap2_baselines']=sys.modules[__name__]

CLASSES=np.asarray(list(ACTIVITIES),dtype=np.int32)
NODE_SLICES={'hand':slice(0,6),'chest':slice(6,12),'ankle':slice(12,18)}
ALPHAS=[0.01,0.1,1,10,100,1000,10000]

def statistical_features(x):
    """12 per-axis statistics + 6 correlations per physical node."""
    x=np.asarray(x,dtype=np.float32)
    t=x.shape[-1]
    mean=x.mean(axis=2)
    std=x.std(axis=2)
    q=np.quantile(x,[0.25,0.5,0.75],axis=2)
    diff=np.diff(x,axis=2)
    axis=np.linspace(-1,1,t,dtype=np.float32)
    slope=np.mean(x*axis[None,None,:],axis=2)/np.mean(axis**2)
    spectrum=np.abs(np.fft.rfft(x-mean[:,:,None],axis=2))**2
    frequency=np.fft.rfftfreq(t,1/100)
    high_ratio=spectrum[:,:,frequency>5].sum(axis=2)/(spectrum.sum(axis=2)+1e-12)
    pieces=[mean,std,x.min(axis=2),x.max(axis=2),q[0],q[1],q[2],
            np.sqrt(np.mean(x*x,axis=2)),np.mean(np.abs(diff),axis=2),diff.std(axis=2),slope,high_ratio]
    correlations=[]
    for start in range(0,x.shape[1],6):
        for offset in [0,3]:
            z=x[:,start+offset:start+offset+3]-mean[:,start+offset:start+offset+3,None]
            for a,b in [(0,1),(0,2),(1,2)]:
                denominator=std[:,start+offset+a]*std[:,start+offset+b]
                correlations.append(np.mean(z[:,a]*z[:,b],axis=1)/np.maximum(denominator,1e-8))
    return np.concatenate([v.reshape(len(x),-1) for v in pieces]+[np.stack(correlations,axis=1)],axis=1).astype(np.float64)

class StatisticalTransform:
    def fit(self,x):
        return self
    def transform(self,x):
        return np.concatenate([statistical_features(x[i:i+128]) for i in range(0,len(x),128)])

class RocketTransform:
    def __init__(self,kernels):
        from aeon.transformations.collection.convolution_based import MiniRocket
        self.transformer=MiniRocket(n_kernels=kernels,n_jobs=1,random_state=0)
    def fit(self,x):
        self.mean=x.mean(axis=(0,2),keepdims=True,dtype=np.float64).astype(np.float32)
        self.std=np.maximum(x.std(axis=(0,2),keepdims=True,dtype=np.float64),1e-8).astype(np.float32)
        self.transformer.fit(((x-self.mean)/self.std).astype(np.float32))
        return self
    def transform(self,x):
        return np.concatenate([np.asarray(self.transformer.transform(((x[i:i+256]-self.mean)/self.std).astype(np.float32))) for i in range(0,len(x),256)])

StatisticalTransform.__module__='run_pamap2_baselines'
RocketTransform.__module__='run_pamap2_baselines'

def fit_selected(x,y,xv,yv,kind,kernels):
    transform=StatisticalTransform() if kind=='statistical' else RocketTransform(kernels)
    start=time.perf_counter()
    transform.fit(x)
    ft=transform.transform(x)
    fv=transform.transform(xv)
    scaler=StandardScaler().fit(ft)
    ft=scaler.transform(ft)
    fv=scaler.transform(fv)
    choices=[]
    best=-np.inf
    model=None
    for alpha in ALPHAS:
        candidate=RidgeClassifier(alpha=alpha,solver='cholesky').fit(ft,y)
        score=float(f1_score(yv,candidate.predict(fv),labels=CLASSES,average='macro',zero_division=0))
        choices.append({'alpha':alpha,'validation_macro_f1':score})
        if score>best+1e-12:
            best=score
            model=candidate
    if not np.array_equal(model.classes_,CLASSES):
        raise ValueError(f'Training classes differ: {model.classes_}')
    return {'transform':transform,'scaler':scaler,'model':model}, {
        'selected_alpha':model.alpha,'validation_macro_f1':best,'candidates':choices,
        'feature_count':int(ft.shape[1]),'fit_and_search_seconds':time.perf_counter()-start,
    }

def decision(bundle,x):
    features=bundle['transform'].transform(x)
    return bundle['model'].decision_function(bundle['scaler'].transform(features)).astype(np.float32)

def metrics(y,scores):
    prediction=CLASSES[np.argmax(scores,axis=1)]
    return {'accuracy':float(accuracy_score(y,prediction)),
            'macro_f1':float(f1_score(y,prediction,labels=CLASSES,average='macro',zero_division=0)),
            'macro_f1_present_classes':float(f1_score(y,prediction,labels=np.unique(y),average='macro',zero_division=0)),
            'test_class_count':int(len(np.unique(y))),
            'class_recall':recall_score(y,prediction,labels=CLASSES,average=None,zero_division=0).tolist(),
            'confusion_matrix':confusion_matrix(y,prediction,labels=CLASSES).tolist()},prediction

def benchmark(predict,x):
    samples=x[:min(64,len(x))]
    results={}
    for batch in [1,32]:
        current=samples[:min(batch,len(samples))]
        for _ in range(3):
            predict(current)
        durations=[]
        for _ in range(30):
            start=time.perf_counter_ns()
            predict(current)
            durations.append((time.perf_counter_ns()-start)/1e6)
        results[f'batch_{len(current)}']={
            'batch_median_ms':float(np.median(durations)),
            'batch_p95_ms':float(np.quantile(durations,0.95)),
            'amortized_median_ms_per_window':float(np.median(durations)/len(current)),
            'repetitions':30,
        }
    return results

def serialize_scores(scores,node=0,window=0):
    """13-byte header: uint32 window + uint8 node + uint64 timestamp ns."""
    vector=np.asarray(scores,dtype='<f4')
    return struct.pack('<IBQ',window,node,0)+vector.tobytes()

def environment():
    import scipy,aeon
    return {'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),
            'cpu_logical_count':os.cpu_count(),'numpy':np.__version__,'pandas':pd.__version__,
            'scipy':scipy.__version__,'sklearn':sklearn.__version__,'aeon':aeon.__version__,
            'threads':1,'seed':0,'window_dtype':'float32','statistical_feature_and_ridge_dtype':'float64',
            'scope':'offline same-host serial CPU replay; no wireless network or power measurement'}

def run(kind,fold_filter=None,kernels=2016):
    target=OUT/kind
    target.mkdir(parents=True,exist_ok=True)
    x=np.load(OUT/'windows.npy',mmap_mode='r')
    y=np.load(OUT/'labels.npy')
    subject=np.load(OUT/'subjects.npy')
    folds=json.loads((OUT/'split_manifest.json').read_text(encoding='utf-8'))['folds']
    if fold_filter:
        folds=[f for f in folds if f['test'][0] in fold_filter]
    write_json(target/'environment.json',environment())
    write_json(target/'run_protocol.json',{
        'model':kind,'minirocket_requested_kernels':kernels if kind=='minirocket' else None,
        'status':'exploratory implementation baseline; no new collaborative method',
        'folds':[f['fold'] for f in folds], 'alpha_grid':ALPHAS,
        'validation_selection':'fixed-12-class macro-F1; ascending alpha tie order; no validation refit',
        'fusion':'arithmetic mean of the three node RidgeClassifier decision-score vectors; no probability calibration or reliability weighting',
        'benchmark':'batch 1/32, 3 warmups, 30 repeats; transform+scale+ridge included; serial nodes for fusion',
        'protocol_sha256':hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest(),
    })
    with threadpool_limits(limits=1):
        for fold in folds:
            directory=target/fold['fold']
            directory.mkdir(exist_ok=True)
            if (directory/'metrics.json').exists():
                print(f'skip completed {kind} {fold["fold"]}',flush=True)
                continue
            masks={k:np.isin(subject,fold[k]) for k in ['train','validation','test']}
            yt,yv,ye=[y[masks[k]] for k in ['train','validation','test']]
            bundles={}
            selections={}
            for node,channels in list(NODE_SLICES.items())+[('centralized',slice(None))]:
                print(f'fit {kind} {fold["fold"]} {node}',flush=True)
                bundles[node],selections[node]=fit_selected(x[masks['train'],channels,:],yt,x[masks['validation'],channels,:],yv,kind,kernels)
                joblib.dump(bundles[node],directory/f'{node}.joblib',compress=0)
            write_json(directory/'selection_before_test.json',{'fold':fold,'selections':selections,'all_choices_saved_before_test_predictions':True})
            test=x[masks['test']]
            np.save(directory/'cost_input.npy',test[:64])
            scores={}
            report={}
            for node,channels in list(NODE_SLICES.items())+[('centralized',slice(None))]:
                scores[node]=decision(bundles[node],test[:,channels,:])
            scores['equal_score_fusion']=np.mean(np.stack([scores[n] for n in NODE_SLICES]),axis=0)
            predictions={'y_true':ye,'subject':subject[masks['test']]}
            for condition,value in scores.items():
                result,yp=metrics(ye,value)
                predictions[f'{condition}_scores']=value
                predictions[f'{condition}_prediction']=yp
                if condition=='equal_score_fusion':
                    predict=lambda z: np.mean(np.stack([decision(bundles[n],z[:,ch,:]) for n,ch in NODE_SLICES.items()]),axis=0)
                else:
                    ch=NODE_SLICES.get(condition,slice(None))
                    predict=lambda z,b=bundles[condition],ch=ch: decision(b,z[:,ch,:])
                result['latency']=benchmark(predict,test)
                result['model_files_bytes']=sum((directory/f'{n}.joblib').stat().st_size for n in (list(NODE_SLICES) if condition=='equal_score_fusion' else [condition]))
                result['test_windows']=len(ye)
                report[condition]=result
            stress={}
            for omitted in NODE_SLICES:
                retained=[n for n in NODE_SLICES if n!=omitted]
                value=np.mean(np.stack([scores[n] for n in retained]),axis=0)
                stress[f'missing_{omitted}']=metrics(ye,value)[0]
            write_json(directory/'missing_node_metrics.json',stress)
            np.savez_compressed(directory/'predictions.npz',**predictions)
            write_json(directory/'metrics.json',report)
            print(f'finished {kind} {fold["fold"]}: '+', '.join(f'{c} F1={r["macro_f1"]:.4f}' for c,r in report.items()),flush=True)
    rows=[]
    for path in sorted(target.glob('test_*/metrics.json')):
        fold=path.parent.name
        report=json.loads(path.read_text(encoding='utf-8'))
        for condition,r in report.items():
            rows.append({'model':kind,'fold':fold,'subject':int(fold.split('_')[1]),'condition':condition,
                         'accuracy':r['accuracy'],'macro_f1':r['macro_f1'],'test_windows':r['test_windows'],
                         'batch1_median_ms':r['latency']['batch_1']['batch_median_ms'],
                         'batch1_p95_ms':r['latency']['batch_1']['batch_p95_ms'],
                         'batch32_amortized_ms':r['latency']['batch_32']['amortized_median_ms_per_window'],
                         'model_files_bytes':r['model_files_bytes']})
    pd.DataFrame(rows).to_csv(target/'fold_metrics.csv',index=False)
    cost={'header_format':'<IBQ; uint32 window id, uint8 node id, uint64 timestamp ns; 13 bytes',
          'transport_headers_and_handshake_excluded':True,
          'score_float32_bytes_per_node':len(serialize_scores(np.zeros(len(CLASSES)))),
          'score_float32_bytes_three_nodes':3*len(serialize_scores(np.zeros(len(CLASSES)))),
          'raw_float32_bytes_per_node':13+200*6*4,
          'raw_float32_bytes_three_nodes':3*(13+200*6*4),
          'communication_scope':'actual defined application-payload serialization, not measured wireless traffic',
          'peak_rss_note':'see isolated cost workers; model storage is not peak RAM'}
    write_json(target/'payload_costs.json',cost)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--model',choices=['statistical','minirocket'],default='statistical')
    parser.add_argument('--test-subjects',type=int,nargs='+')
    parser.add_argument('--kernels',type=int,default=2016)
    args=parser.parse_args()
    run(args.model,args.test_subjects,args.kernels)
