"""Frozen train-only V16 diagnostics; no fitted routing or model selection."""
import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from continuous_training_data import TrainingWindowStore, CONFIG, OUT as V13
from continuous_screen_accounting import latency, macro_f1
from validity_diagnostic import (HORIZONS, POLICIES, summaries, schedule, packet_cost, profile,
                                  independent_schedule_check, validity, longest_error, auc_diagnostics)

ROOT = Path(__file__).resolve().parent
V15 = ROOT/'results'/'continuous_collaboration_v15'
OUT = ROOT/'results'/'collaboration_validity_v16'
STEMS = ('s2048_stride1_offset0', 's2048_stride2_offset0', 's2048_stride2_offset1')
SOURCES = ('validity_diagnostic.py', 'run_validity_diagnostic.py', 'summarize_validity_diagnostic.py',
           'test_validity_diagnostic.py', 'causal_score_codec.py', 'bounded_score_codec.py',
           'continuous_screen_accounting.py', 'continuous_training_data.py',
           'continuous_causal_controls.py', 'prepare_pamap2.py')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def freeze_design():
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = dict(version='collaboration_validity_v16', phase='no-fit train diagnostic',
                    primary=dict(primary_node=0, policy='sentinel_h8_t0.25'), policies=POLICIES,
                    horizons=list(HORIZONS), stems=list(STEMS), reference='V15 integer quantized fusion',
                    document_sha256=digest(ROOT/'CSCWD2027_信息有效期诊断协议V16.md'),
                    no_fitted_controller=True, no_new_validation=True, no_new_test=True)
    if (OUT/'protocol.json').exists():
        assert read(OUT/'protocol.json') == protocol
    else:
        write(OUT/'protocol.json', protocol)
        write(OUT/'design_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
              protocol_sha256=digest(OUT/'protocol.json'), outcome_files_present=False))
    return protocol


def prepare():
    freeze_design()
    lock = {name: digest(ROOT/name) for name in SOURCES}
    for name, value in read(V15/'source_lock.json').items():
        assert digest(ROOT/name) == value
    if (OUT/'source_lock.json').exists():
        assert read(OUT/'source_lock.json') == lock
        return
    paths = []
    manifest = read(V15/'artifact_manifest.json')
    for stem in STEMS:
        group = sorted(V15.glob(f'*/*/subject*/{stem}.npz'))
        assert len(group) == 128
        for path in group:
            assert digest(path) == manifest[str(path.relative_to(V15))]
            paths.extend([path, path.with_name(stem+'_complete.json')])
    paths += [V15/'source_lock.json', V15/'protocol.json', V15/'research_decision.json', V15/'independent_verification.json']
    for dataset in CONFIG:
        paths += [V13/dataset/'split_manifest.json']
        for record in sorted((V13/dataset/'records').glob('subject*')):
            paths += [record/'signal.npy', record/'window_index.csv', record/'annotated_onsets.csv']
        paths += sorted((V13/dataset/'training_views').glob('*/train_windows.csv'))
    write(OUT/'inputs.json', {str(path.relative_to(ROOT)): digest(path) for path in sorted(set(paths))})
    write(OUT/'source_lock.json', lock)
    write(OUT/'implementation_frozen.json', dict(created_utc=datetime.now(timezone.utc).isoformat(),
          protocol_sha256=digest(OUT/'protocol.json'), source_lock_sha256=digest(OUT/'source_lock.json'),
          inputs_sha256=digest(OUT/'inputs.json'), actual_diagnostics_started=False))


def assert_frozen():
    freeze_design()
    assert (OUT/'implementation_frozen.json').exists()
    for name, value in read(OUT/'source_lock.json').items():
        assert digest(ROOT/name) == value, name
    for name, value in read(V15/'source_lock.json').items():
        assert digest(ROOT/name) == value, name
    for name, value in read(OUT/'inputs.json').items():
        assert digest(ROOT/name) == value, name


def features_for(dataset, fold, subject):
    file = OUT/'raw_features'/f'{dataset}_subject{subject}.npz'
    if file.exists() and file.with_suffix('.json').exists():
        assert digest(file) == read(file.with_suffix('.json'))['file_sha256']
        with np.load(file, allow_pickle=False) as data:
            return data['continuous_global_indices'], data['features']
    with TrainingWindowStore(dataset, fold) as store:
        positions = np.flatnonzero(store.index.subject.to_numpy() == subject)
        features, indices = [], []
        begun = time.perf_counter()
        for start in range(0, len(positions), 64):
            x, frame = store.batch(positions[start:start+64])
            features.append(summaries(x, CONFIG[dataset]['selected_axes_per_node']))
            indices.append(frame.continuous_global_index.to_numpy())
        features, indices = np.concatenate(features), np.concatenate(indices)
        file.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(file, continuous_global_indices=indices, features=features)
        write(file.with_suffix('.json'), dict(dataset=dataset, subject=subject, source_train_fold=fold,
              windows=len(indices), file_sha256=digest(file),
              batch_feature_preparation_seconds=time.perf_counter()-begun,
              timing_scope='includes training-window access and batch statistics; not isolated online CPU'))
        return indices, features


def onset_metrics(f, prediction, channel, events, metadata):
    rows = []
    endrows = f['end_rows_exclusive']-1
    classes = f['classes']
    correct = classes[prediction] == f['endpoint_targets']
    reference_correct = classes[f['reference']] == f['endpoint_targets']
    for event in events:
        eligible = ((endrows >= event['onset_row']) & (endrows < event['raw_labeled_episode_end_exclusive'])
                    & (f['endpoint_targets'] == event['activity']))
        observable = bool(eligible.any())
        for criterion in ('first_correct', 'two_consecutive_correct'):
            target, ref_target = eligible & correct, eligible & reference_correct
            if criterion == 'two_consecutive_correct':
                target = target & np.r_[False, target[:-1]] & ~f['physical_reset']
                ref_target = ref_target & np.r_[False, ref_target[:-1]] & ~f['physical_reset']
            choices, ref_choices = np.flatnonzero(target), np.flatnonzero(ref_target)
            at = int(choices[0]) if len(choices) else -1
            ref = int(ref_choices[0]) if len(ref_choices) else -1
            rows.append(dict(**metadata, onset_row=int(event['onset_row']), activity=int(event['activity']),
                             onset_kind=event['onset_kind'], criterion=criterion, observable=observable,
                             candidate_observed=at >= 0, reference_observed=ref >= 0,
                             candidate_failure=observable and at < 0,
                             reference_failure=observable and ref < 0,
                             additional_failure=observable and ref >= 0 and at < 0,
                             delay_seconds=float(f['end_time'][at]-event['onset_time']) if at >= 0 else None,
                             extra_recovery_windows=(at-ref) if at >= 0 and ref >= 0 else None,
                             response_channel_ms=float(channel[at]) if at >= 0 else None))
    return rows


def evaluate(f, features, dataset, fold, subject, stem, events):
    n = len(f['q'])
    stride = 1 if 'stride1' in stem else 2
    offset = int(stem[-1])
    common = dict(dataset=dataset, outer_fold=fold, subject=subject, stride=stride, offset=offset, windows=n)
    windows = f['continuous_global_indices']
    stamps = np.rint(f['end_time']*1e6).astype(np.int64)
    prefix = f['prefix_bytes'].astype(np.int32)+18*f['session_start'].astype(np.int32)
    prefix_messages = f['prefix_messages']
    reference = f['reference']
    known = f['endpoint_targets'] != -1
    classes = f['classes']
    reference_f1 = macro_f1(f['endpoint_targets'][known], classes[reference[known]], classes)
    rows, onset_rows, validity_rows, risk_rows, saved = [], [], [], [], {}
    saved['continuous_global_indices'] = windows
    saved['reset'] = f['reset']
    total_audits = 0
    for primary in range(3):
        first, observed = validity(f['q'], features, f['reset'], primary)
        saved[f'p{primary}_validity_first'] = first
        saved[f'p{primary}_validity_observed'] = observed
        for h in HORIZONS:
            complete = observed >= h
            validity_rows.append(dict(**common, primary=primary, horizon=h, complete_followup=int(complete.sum()),
                                      right_censored=int((~complete).sum()),
                                      conflicts=int(((first > 0) & (first <= h) & complete).sum()),
                                      conflict_fraction=float(((first > 0) & (first <= h))[complete].mean()) if complete.any() else None))
        risk_rows += [dict(**common, **row) for row in auc_diagnostics(f['q'], features, f['reset'], primary, stride)]
        for policy_id, policy in enumerate(POLICIES):
            send, requests, pred = schedule(f['q'], features, f['reset'], primary,
                                           policy['mode'], policy['horizon'], policy['threshold'])
            independent_schedule_check(f['q'], features, f['reset'], primary, policy, send, requests, pred)
            data_bytes, checks = packet_cost(f['q'], send, f['reset'], windows, stamps)
            total_audits += checks
            profile(policy_id, policy['horizon'], policy['threshold'])
            request_bytes = requests.sum(1).astype(np.int32)*14
            byte_count = data_bytes+request_bytes+prefix
            messages = send.sum(1)+requests.sum(1)+prefix_messages
            timing = latency(f['end_time'], np.arange(n), np.ones(n, int), byte_count, messages,
                             np.zeros(n, int), np.zeros(n, int), 0)
            channel = timing['latency_250000_1_ms']
            epoch = f['reset'] | send[:, np.arange(3) != primary].any(1)
            starts = np.flatnonzero(epoch)
            error = pred != reference
            epoch_error = np.maximum.reduceat(error.astype(np.int8), starts)
            calls = send.sum(1).astype(np.int16)
            metadata = dict(**common, primary=primary, method=policy['name'])
            row = dict(**metadata, mode=policy['mode'], horizon=policy['horizon'], threshold=policy['threshold'],
                       total_bytes=int(byte_count.sum()), bytes_per_window=float(byte_count.mean()),
                       query_bytes=int(request_bytes.sum()), queries_per_window=float(requests.sum()/n),
                       selected_full_models_per_window=float(calls.mean()),
                       deployable_full_models_per_window=float(calls.mean()) if policy['mode'] != 3 else 3.,
                       sentinel_node_evaluations_per_window=2. if policy['mode'] == 1 else 0.,
                       oracle_hidden_full_scores=policy['mode'] == 3,
                       reference_mismatches=int(error.sum()), reference_disagreement=float(error.mean()),
                       known_endpoint_macro_f1=macro_f1(f['endpoint_targets'][known], classes[pred[known]], classes),
                       known_endpoint_reference_f1=reference_f1,
                       known_endpoint_macro_f1_drop=reference_f1-macro_f1(f['endpoint_targets'][known], classes[pred[known]], classes),
                       longest_reference_error_windows=longest_error(pred, reference, f['reset']),
                       epochs=int(len(starts)), epochs_with_reference_error_fraction=float(epoch_error.mean()),
                       channel_p95_ms=float(np.quantile(channel, .95)),
                       setup_status_bytes=int(prefix.sum()), packet_inverse_samples=checks,
                       known_windows=int(known.sum()), unknown_windows=int((~known).sum()))
            for kind in ('pure_known', 'mixed', 'unknown_only'):
                selected = f['window_kind'] == kind
                row[f'{kind}_windows'] = int(selected.sum())
                row[f'{kind}_reference_disagreement'] = float(error[selected].mean()) if selected.any() else None
            selected = f['window_kind'] == 'pure_known'
            row['pure_known_macro_f1'] = macro_f1(f['endpoint_targets'][selected], classes[pred[selected]], classes)
            rows.append(row)
            onset_rows += onset_metrics(f, pred, channel, events, metadata)
            key = f'p{primary}m{policy_id}_'
            saved.update({key+'send': send, key+'requests': requests, key+'prediction': pred,
                          key+'total_bytes': byte_count, key+'channel_ms': channel})
    # Same new configuration fee for complete-push controls; keep V15 comparator separate.
    for method, index in [('rice2', 6), ('rice3', 7)]:
        # Resolve source indices from its frozen original method list, checked once below.
        from continuous_causal_controls import METHODS
        index = METHODS.index(method)
        key = f'm{index}w0_'
        complete_send = np.ones((n, 3), bool)
        own, checks = packet_cost(f['q'], complete_send, f['reset'], windows, stamps, method)
        assert np.array_equal(own, f[key+'pre_bytes'])
        total_audits += checks
        byte_count = own+prefix
        channel = latency(f['end_time'], np.arange(n), np.ones(n, int), byte_count,
                          3+prefix_messages, np.zeros(n, int), np.zeros(n, int), 0)['latency_250000_1_ms']
        rows.append(dict(**common, primary=-1, method='complete_'+method, mode=-1, horizon=1, threshold=0.,
                         total_bytes=int(byte_count.sum()), bytes_per_window=float(byte_count.mean()),
                         original_v15_bytes_per_window=float((own+f['prefix_bytes']).mean()),
                         deployable_full_models_per_window=3., selected_full_models_per_window=3.,
                         reference_disagreement=0., known_endpoint_macro_f1=reference_f1,
                         known_endpoint_macro_f1_drop=0., channel_p95_ms=float(np.quantile(channel, .95))))
    return saved, dict(rows=rows, onsets=onset_rows, validity=validity_rows, risk=risk_rows,
                       packet_inverse_samples=total_audits)


def run(dataset):
    assert_frozen()
    begun = time.perf_counter()
    finished = 0
    for fold in read(V13/dataset/'split_manifest.json')['folds']:
        for subject in fold['train']:
            feature_indices, all_features = features_for(dataset, fold['fold'], subject)
            events = pd.read_csv(V13/dataset/'records'/f'subject{subject}'/'annotated_onsets.csv').to_dict('records')
            for stem in STEMS:
                source = V15/dataset/fold['fold']/f'subject{subject}'/(stem+'.npz')
                target = OUT/dataset/fold['fold']/f'subject{subject}'/(stem+'.npz')
                done = target.with_name(stem+'_complete.json')
                if done.exists():
                    assert digest(target) == read(done)['array_sha256']
                    finished += 1
                    continue
                with np.load(source, allow_pickle=False) as data:
                    needed = ['q', 'reference', 'classes', 'continuous_global_indices', 'end_time',
                              'endpoint_targets', 'end_rows_exclusive', 'window_kind', 'physical_reset',
                              'reset', 'prefix_bytes', 'prefix_messages', 'session_start']
                    from continuous_causal_controls import METHODS
                    needed += [f'm{METHODS.index(method)}w0_pre_bytes' for method in ('rice2', 'rice3')]
                    f = {name: data[name] for name in needed}
                positions = np.searchsorted(feature_indices, f['continuous_global_indices'])
                np.testing.assert_array_equal(feature_indices[positions], f['continuous_global_indices'])
                features = all_features[positions]
                arrays, record = evaluate(f, features, dataset, fold['fold'], subject, stem, events)
                target.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(target, **arrays)
                record.update(array_sha256=digest(target), source_sha256=digest(source),
                              independent_schedule_reconstruction=True, all_packet_lengths_and_sampled_inverses_checked=True)
                write(done, record)
                finished += 1
            print(f'V16 {dataset}/{fold["fold"]}/subject{subject}: {finished} scenarios; invocation {time.perf_counter()-begun:.1f}s', flush=True)
    records = [read(path) for path in sorted((OUT/dataset).glob('*/*/*_complete.json'))]
    expected = 144 if dataset == 'pamap2' else 240
    assert len(records) == expected, len(records)
    for name in ('rows', 'onsets', 'validity', 'risk'):
        pd.DataFrame([row for record in records for row in record[name]]).to_csv(OUT/dataset/(name+'.csv'), index=False)
    write(OUT/dataset/'complete.json', dict(scenarios=len(records),
          packet_inverse_samples=sum(record['packet_inverse_samples'] for record in records),
          all_scenarios_independently_reconstructed=all(record['independent_schedule_reconstruction'] for record in records),
          invocation_elapsed_seconds=time.perf_counter()-begun,
          no_new_validation=True, no_new_test=True,
          files_sha256={p.name: digest(p) for p in sorted((OUT/dataset).glob('*.csv'))}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze-design', action='store_true')
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--dataset', choices=tuple(CONFIG))
    args = parser.parse_args()
    if args.freeze_design:
        freeze_design()
        print('V16 design frozen before real diagnostics')
    elif args.prepare_only:
        prepare()
        print('V16 input and implementation hashes frozen')
    else:
        run(args.dataset)
