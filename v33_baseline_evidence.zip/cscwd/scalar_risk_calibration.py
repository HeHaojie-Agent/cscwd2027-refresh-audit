"""V19 four cumulative horizons from a single current-risk probability."""
import hashlib
import numpy as np
from numba import njit
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import roc_auc_score
from lease_prediction import fit_logistic, HORIZONS
from validity_survival import logistic, paid_features
from survival_schedule import feature_one
from causal_score_codec import HEADER

KINDS = ('platt', 'isotonic')


def fit_calibrators(data, probability, current_parameters):
    probability = np.asarray(probability, np.float64)
    assert probability.shape == data['first'].shape and np.isfinite(probability).all()
    x = np.log(np.clip(probability, 1e-9, 1-1e-9)/(1-np.clip(probability, 1e-9, 1-1e-9)))[:, None]
    output = {kind: dict(kind=kind, current_parameters=list(current_parameters), calibrators=[],
        training_subjects=np.unique(data['subjects']).tolist()) for kind in KINDS}
    for horizon in HORIZONS:
        event = (data['first'] >= 0) & (data['first'] < horizon)
        keep = (data['observed'] >= horizon) | event
        subjects, y = data['subjects'][keep], event[keep].astype(int)
        fitted = fit_logistic(x[keep], y, subjects)
        fitted['coefficient'] = fitted['coefficient'].tolist()
        output['platt']['calibrators'].append(fitted)
        labels, counts = np.unique(subjects, return_counts=True)
        weights = np.ones(len(y), np.float64)
        for subject, count in zip(labels, counts):
            weights[subjects == subject] = len(y)/(len(labels)*count)
        if len(np.unique(y)) == 1:
            isotonic = dict(x=[float(probability[keep][0])], y=[float(((weights*y).sum()+.5)/(weights.sum()+1))])
        else:
            model = IsotonicRegression(increasing=True, out_of_bounds='clip').fit(probability[keep], y, sample_weight=weights)
            isotonic = dict(x=model.X_thresholds_.tolist(), y=model.y_thresholds_.tolist())
            np.testing.assert_allclose(np.interp(probability[keep], isotonic['x'], isotonic['y']), model.predict(probability[keep]), atol=1e-14)
        isotonic.update(subjects=labels.tolist(), rows=len(y), positives=int(y.sum()))
        output['isotonic']['calibrators'].append(isotonic)
    for model in output.values():
        packet = weight_packet(model)
        decoded = parse_weight_packet(packet)
        np.testing.assert_allclose(scalar_probabilities(model, probability), scalar_probabilities(decoded, probability), atol=1e-14)
    return output


def scalar_probabilities(model, probability):
    p = np.atleast_1d(probability)
    values = []
    for head in model['calibrators']:
        if model['kind'] == 'platt':
            safe = np.clip(p, 1e-9, 1-1e-9)
            values.append(logistic(np.log(safe/(1-safe))*head['coefficient'][0]+head['intercept']))
        else:
            values.append(np.interp(p, head['x'], head['y']))
    return np.maximum.accumulate(np.stack(values, axis=1), axis=1)


def current_probability(model, x):
    parameters = np.asarray(model['current_parameters'])
    return logistic(np.atleast_2d(x)@parameters[:52]+parameters[52])


def weight_packet(model):
    current = np.asarray(model['current_parameters'], '<f8')
    assert current.shape == (53,) and np.isfinite(current).all()
    if model['kind'] == 'platt':
        extra = np.asarray([[head['coefficient'][0], head['intercept']] for head in model['calibrators']], '<f8')
        assert extra.shape == (4, 2)
        payload = current.tobytes()+extra.tobytes()
    else:
        counts = np.asarray([len(head['x']) for head in model['calibrators']], '<u4')
        assert len(counts) == 4 and (counts > 0).all()
        pairs = b''.join(np.column_stack([head['x'], head['y']]).astype('<f8').tobytes() for head in model['calibrators'])
        payload = current.tobytes()+counts.tobytes()+pairs
    packet = HEADER.pack(97+KINDS.index(model['kind']), 0, 0, 0)+hashlib.sha256(payload).digest()[:16]+payload
    expected = 518 if model['kind'] == 'platt' else 470+16*sum(len(head['x']) for head in model['calibrators'])
    assert len(packet) == expected
    return packet


def parse_weight_packet(packet):
    kind, node, window, stamp = HEADER.unpack_from(packet)
    assert kind in (97, 98) and (node, window, stamp) == (0, 0, 0)
    payload = packet[30:]
    assert packet[14:30] == hashlib.sha256(payload).digest()[:16]
    current = np.frombuffer(payload[:424], '<f8').copy()
    assert len(current) == 53 and np.isfinite(current).all()
    heads = []
    if kind == 97:
        assert len(packet) == 518
        pairs = np.frombuffer(payload[424:], '<f8').reshape(4, 2)
        heads = [dict(coefficient=[float(a)], intercept=float(b)) for a, b in pairs]
    else:
        sizes = np.frombuffer(payload[424:440], '<u4')
        assert len(sizes) == 4 and (sizes > 0).all()
        offset = 440
        for size in sizes:
            end = offset+int(size)*16
            pairs = np.frombuffer(payload[offset:end], '<f8').reshape(int(size), 2)
            assert (np.diff(pairs[:, 0]) > 0).all() and (np.diff(pairs[:, 1]) >= -1e-14).all()
            assert np.isfinite(pairs).all() and ((pairs[:, 1] >= 0) & (pairs[:, 1] <= 1)).all()
            heads.append(dict(x=pairs[:, 0].tolist(), y=pairs[:, 1].tolist()))
            offset = end
        assert offset == len(payload)
    return dict(kind=KINDS[kind-97], current_parameters=current.tolist(), calibrators=heads)


def runtime_parameters(model):
    if model['kind'] == 'platt':
        extra = np.asarray([[head['coefficient'][0], head['intercept']] for head in model['calibrators']]).ravel()
    else:
        extra = np.r_[[len(head['x']) for head in model['calibrators']],
            np.concatenate([np.column_stack([head['x'], head['y']]).ravel() for head in model['calibrators']])]
    return np.r_[model['current_parameters'], extra].astype(np.float64)


@njit(cache=True)
def sigmoid(z):
    return 1/(1+np.exp(-z)) if z >= 0 else np.exp(z)/(1+np.exp(z))


@njit(cache=True)
def select_from_probability(p, parameters, mode, threshold):
    safe = min(max(p, 1e-9), 1-1e-9)
    z = np.log(safe/(1-safe))
    offset, previous, interval = 57, 0., 1
    for j in range(4):
        if mode == 0:
            risk = sigmoid(parameters[53+2*j]*z+parameters[54+2*j])
        else:
            count = int(parameters[53+j])
            if p <= parameters[offset]:
                risk = parameters[offset+1]
            elif p >= parameters[offset+2*(count-1)]:
                risk = parameters[offset+2*(count-1)+1]
            else:
                low, high = 0, count-1
                while high-low > 1:
                    middle = (low+high)//2
                    if parameters[offset+2*middle] <= p:
                        low = middle
                    else:
                        high = middle
                x0, y0 = parameters[offset+2*low], parameters[offset+2*low+1]
                x1, y1 = parameters[offset+2*high], parameters[offset+2*high+1]
                risk = y0+(p-x0)/(x1-x0)*(y1-y0)
            offset += 2*count
        previous = max(previous, risk)
        if previous <= threshold:
            interval = 2**(j+1)
    return interval


@njit(cache=True)
def choose_interval(primary, cache, parameters, mode, threshold):
    x = feature_one(primary, cache, 1)
    z = parameters[52]
    for j in range(52):
        z += parameters[j]*x[j]
    return select_from_probability(sigmoid(z), parameters, mode, threshold)


@njit(cache=True)
def lease_schedule(q, reset, parameters, mode, threshold):
    send = np.zeros((len(q), 3), np.bool_)
    send[:, 0] = True
    grants = np.zeros(len(q), np.int16)
    prediction = np.empty(len(q), np.int16)
    anchor, due = 0, -1
    for t in range(len(q)):
        refresh = bool(reset[t])
        if not refresh:
            if due == t:
                refresh = True
            elif t == anchor+1 and due < 0:
                h = choose_interval(q[t, 0], q[anchor], parameters, mode, threshold)
                grants[t] = h
                due = anchor+h
                refresh = due == t
        if refresh:
            send[t, 1:] = True
            anchor, due = t, -1
        best, winner = -1, 0
        for c in range(12):
            value = int(q[t, 0, c])+int(q[anchor, 1, c])+int(q[anchor, 2, c])
            if value > best:
                best, winner = value, c
        prediction[t] = winner
    return send, grants, prediction


def verify_decisions(f, model, threshold, send, grants):
    n = len(send)
    last = np.maximum.accumulate(np.where(send[:, 1], np.arange(n), -1))
    previous = np.r_[0, last[:-1]]
    t = np.flatnonzero(grants > 0)
    p = current_probability(model, paid_features(f['q'], t, previous[t]))
    risk = scalar_probabilities(model, p)
    expected = np.ones(len(t), int)
    for j, h in enumerate((2, 4, 8, 16)):
        expected[risk[:, j] <= threshold] = h
    np.testing.assert_array_equal(expected, grants[t])


def risk_metrics(model, data):
    forecasts = scalar_probabilities(model, current_probability(model, data['x']))
    rows = []
    for subject in np.unique(data['subjects']):
        for j, h in enumerate(HORIZONS):
            keep = (data['subjects'] == subject) & (data['observed'] >= h)
            y = ((data['first'][keep] >= 0) & (data['first'][keep] < h)).astype(int)
            p = forecasts[keep, j]
            rows.append(dict(subject=int(subject), model=model['kind'], horizon=h,
                complete_followup=int(keep.sum()), right_censored=int((data['subjects'] == subject).sum()-keep.sum()),
                positives=int(y.sum()), auc=float(roc_auc_score(y, p)) if 0 < y.sum() < len(y) else None,
                brier=float(np.mean((p-y)**2)), mean_predicted_risk=float(p.mean()), observed_event_rate=float(y.mean())))
    return rows
