"""V20 direction-aware subject-equal summaries; no result-dependent selection."""
from datetime import datetime,timezone
import numpy as np
import pandas as pd
from matched_calibration_data import ROOT,OUT,read,write,sha
from summarize_validity_diagnostic import checks
from confirm_lease_contribution import weighted_quantile
from summarize_nested_survival import clean

KEYS=['dataset','stride','offset','method']
VIEW=KEYS+['outer_fold','group','subject']


def equal_summary(frame,keys):
    # Directions share the same original view and are not additional subjects.
    view=frame.groupby(keys+['outer_fold','group','subject'],as_index=False).mean(numeric_only=True)
    subject=view.groupby(keys+['subject'],as_index=False).mean(numeric_only=True)
    equal=subject.groupby(keys,as_index=False).mean(numeric_only=True)
    return view,subject,equal


def recovery(events):
    rows=[]
    for key,part in events.groupby(VIEW+['direction'],sort=False):
        item=dict(zip(VIEW+['direction'],key))
        for criterion,subset in part.groupby('criterion'):
            visible=subset[subset.observable]
            paired=subset.extra_recovery_windows.dropna()
            item[criterion+'_additional_failure_fraction']=float(visible.additional_failure.mean()) if len(visible) else np.nan
            item[criterion+'_candidate_failure_fraction']=float(visible.candidate_failure.mean()) if len(visible) else np.nan
            item[criterion+'_reference_failure_fraction']=float(visible.reference_failure.mean()) if len(visible) else np.nan
            item[criterion+'_observable_events']=len(visible)
            item[criterion+'_paired_successes']=len(paired)
        rows.append(item)
    return pd.DataFrame(rows)


def recovery_mixture(events):
    keys=KEYS+['criterion']
    original_view=keys+['subject','outer_fold','group']
    directional_view=original_view+['direction']
    paired=events.dropna(subset=['extra_recovery_windows']).copy()
    paired['events_in_direction']=paired.groupby(directional_view).extra_recovery_windows.transform('size')
    counts=paired[directional_view].drop_duplicates().groupby(original_view,as_index=False).size().rename(columns={'size':'available_directions'})
    paired=paired.merge(counts,on=original_view,validate='many_to_one')
    counts=paired[original_view].drop_duplicates().groupby(keys+['subject'],as_index=False).size().rename(columns={'size':'available_views'})
    paired=paired.merge(counts,on=keys+['subject'],validate='many_to_one')
    paired['available_subjects']=paired.groupby(keys).subject.transform('nunique')
    paired['weight']=1/(paired.events_in_direction*paired.available_directions*paired.available_views*paired.available_subjects)
    rows=[]
    for key,part in paired.groupby(keys):
        assert np.isclose(part.weight.sum(),1.)
        rows.append(dict(zip(keys,key),p95=weighted_quantile(part.extra_recovery_windows,part.weight),
            fraction_over_one=float(part.loc[part.extra_recovery_windows>1,'weight'].sum()),
            subjects=int(part.subject.nunique()),directional_paired_events=len(part)))
    return pd.DataFrame(rows)


def main():
    assert (OUT/'controller_complete.json').exists()
    assert read(OUT/'independent_verification.json')['all_passed']
    sources={name:sha(ROOT/name) for name in ('summarize_matched_calibration.py','audit_matched_calibration.py','test_matched_summary.py')}
    if (OUT/'analysis_sources.json').exists():assert read(OUT/'analysis_sources.json')==sources
    else:
        write(OUT/'analysis_sources.json',sources)
        write(OUT/'analysis_frozen.json',dict(created_utc=datetime.now(timezone.utc).isoformat(),aggregation_started=False,
            source_sha256=sha(OUT/'analysis_sources.json')))
    targets=sorted((OUT/'controllers').glob('*/*/*/*/stride*_offset*'))
    assert len(targets)==384,len(targets)
    rows=pd.DataFrame([row for p in targets for row in read(p/'metrics.json')])
    risk=pd.DataFrame([row for p in targets for row in read(p/'risk_metrics.json')])
    events=pd.DataFrame([row for p in targets for row in read(p/'onsets.json')])
    assert len(rows)==16896 and len(risk)==15360,(len(rows),len(risk))
    assert not rows.duplicated(VIEW+['direction']).any()
    assert (rows.groupby(VIEW).direction.nunique()==2).all()
    rec=recovery(events)
    rows=rows.merge(rec,on=VIEW+['direction'],validate='one_to_one')
    rows.to_csv(OUT/'view_metrics.csv',index=False)
    risk.to_csv(OUT/'risk_view_metrics.csv',index=False)
    events.to_csv(OUT/'onsets.csv',index=False)
    view,subject,equal=equal_summary(rows,KEYS)
    subject['positive_savings']=subject.bytes_per_window<subject.baseline_bytes_per_window
    directions=subject.groupby(KEYS,as_index=False).positive_savings.mean().rename(columns={'positive_savings':'positive_subject_fraction'})
    equal=equal.merge(directions,on=KEYS,validate='one_to_one')
    equal['savings_fraction']=1-equal.bytes_per_window/equal.baseline_bytes_per_window
    mixture=recovery_mixture(events)
    mixture.to_csv(OUT/'recovery_mixture.csv',index=False)
    for criterion in ('first_correct','two_consecutive_correct'):
        part=mixture[mixture.criterion==criterion][KEYS+['p95']].rename(columns={'p95':criterion+'_p95_extra_recovery_windows'})
        equal=equal.merge(part,on=KEYS,how='left',validate='one_to_one')
    view.to_csv(OUT/'direction_averaged_metrics.csv',index=False)
    subject.to_csv(OUT/'subject_equal_metrics.csv',index=False)
    equal.to_csv(OUT/'dataset_equal_metrics.csv',index=False)
    _,risk_subject,risk_equal=equal_summary(risk,['dataset','stride','offset','model','horizon'])
    risk_subject.to_csv(OUT/'risk_subject_equal.csv',index=False)
    risk_equal.to_csv(OUT/'risk_dataset_equal.csv',index=False)
    pairs=[]
    for full in ('direct','survival'):
        for scalar in ('platt','isotonic','geometric'):
            keys=['dataset','stride','offset','subject','horizon']
            joined=risk_subject[risk_subject.model==full].merge(risk_subject[risk_subject.model==scalar],on=keys,suffixes=('_full','_scalar'),validate='one_to_one')
            for _,row in joined.iterrows():
                pairs.append(dict(**{key:row[key] for key in keys},comparison=full+' minus '+scalar,
                    brier_difference=row.brier_full-row.brier_scalar,auc_difference=row.auc_full-row.auc_scalar))
    paired=pd.DataFrame(pairs)
    paired.to_csv(OUT/'predictive_subject_pairs.csv',index=False)
    pair_summary=paired.groupby(['dataset','stride','offset','horizon','comparison'],as_index=False).agg(
        brier_difference=('brier_difference','mean'),auc_difference=('auc_difference','mean'),
        subjects=('subject','size'),full_brier_better_subjects=('brier_difference',lambda x:int((x<-1e-12).sum())))
    pair_summary.to_csv(OUT/'predictive_pair_summary.csv',index=False)
    points=[]
    for _,row in equal.iterrows():
        item=row.to_dict();item['checks']=checks(item);item['all_checks_passed']=all(item['checks'].values());points.append(item)
    passed=[name for name,part in pd.DataFrame(points).groupby('method') if part.all_checks_passed.all()]
    shifts=[]
    for p in targets:
        lineage=read(p/'lineage.json');case=lineage['case'];shift=read(p/'probability_shift.json')
        # Store group/direction summaries without calling them subject-equal.
        scenario=p.name.split('_');stride=int(scenario[0].removeprefix('stride'));offset=int(scenario[1].removeprefix('offset'))
        shifts.append(dict(dataset=case['dataset'],outer_fold=case['outer_fold'],group=case['group'],direction=case['direction'],stride=stride,offset=offset,
            calibration_probability_mean=shift['calibration']['mean'],evaluation_probability_mean=shift['evaluation']['mean'],
            evaluation_below_calibration_range=shift['evaluation_below_calibration_range'],
            evaluation_above_calibration_range=shift['evaluation_above_calibration_range'],same_current_head=True))
    pd.DataFrame(shifts).to_csv(OUT/'probability_shift_view_metrics.csv',index=False)
    decision=dict(version='matched_calibration_v20',client_date='2026-10-21',cases=384,methods=22,
        all_six_passing_methods=passed,primary_hazard_all_six=all(x['all_checks_passed'] for x in points if x['method']=='survival_t0.01'),
        primary_scalar_all_six=all(x['all_checks_passed'] for x in points if x['method']=='platt_t0.01'),
        controlled_model_switch=True,independent_time_information_established=False,
        independent_outer_validation=False,new_CPU_wireless_energy_measurements=False,
        interpretation='matched-source development comparison; not causal attribution of the V19-to-V20 difference; not risk-matched tuning')
    write(OUT/'research_decision.json',decision)
    write(OUT/'report_data.json',clean(dict(decision=decision,metrics=points,risk=risk_equal.to_dict('records'),
        predictive_pairs=pair_summary.to_dict('records'),audit=read(OUT/'independent_verification.json'))))
    print(decision)


if __name__=='__main__':main()
