"""Subject-equal V17 outcomes with the frozen primary and explicit CPU scope."""
import json
import numpy as np
import pandas as pd
from nested_validity_data import ROOT, OUT, read, write, sha
from summarize_validity_diagnostic import checks


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, list):
        return [clean(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    return value


def onset_summary(events):
    keys = ['dataset', 'outer_fold', 'group', 'subject', 'stride', 'offset', 'method']
    rows = []
    for key, part in events.groupby(keys, sort=False):
        row = dict(zip(keys, key))
        for criterion, subset in part.groupby('criterion'):
            visible = subset[subset.observable]
            paired = subset.extra_recovery_windows.dropna()
            row[criterion+'_observable_events'] = len(visible)
            row[criterion+'_additional_failure_fraction'] = visible.additional_failure.mean() if len(visible) else np.nan
            row[criterion+'_candidate_failure_fraction'] = visible.candidate_failure.mean() if len(visible) else np.nan
            row[criterion+'_reference_failure_fraction'] = visible.reference_failure.mean() if len(visible) else np.nan
            row[criterion+'_paired_p95_extra_at_most_one_window_count'] = int((paired <= 1).sum())
            row[criterion+'_paired_successes'] = len(paired)
            row[criterion+'_p95_extra_recovery_windows'] = paired.quantile(.95) if len(paired) else np.nan
            row[criterion+'_unobservable_events'] = int((~subset.observable).sum())
        rows.append(row)
    return pd.DataFrame(rows)


def add_cost_estimates(subject, components):
    subject['estimated_component_cpu_ms_per_window'] = np.nan
    subject['estimated_full_push_component_cpu_ms_per_window'] = np.nan
    for dataset, measurement in components.items():
        c = measurement['components']
        mean = lambda name: c[name]['precision_cpu']['mean_ms']
        for index, row in subject[subject.dataset == dataset].iterrows():
            # These are representative component sums, not full-trajectory direct CPU timings.
            total = 0.
            for node in range(3):
                calls = row[f'node{node}_calls']/row.windows
                total += calls*(mean(f'node{node}_full')+mean('quantize_one_node')+mean('rice2_encode')+mean('rice2_decode'))
            total += mean('integer_fusion')
            head = 'survival_features_and_head' if row.method.startswith('survival_') else 'current_features_and_head'
            if row.method.startswith(('survival_', 'current_')):
                total += row.controller_calls/row.windows*mean(head)
            if row.method == 'sentinel_h8_t0.25':
                total += 2*mean('raw_stats_sentinel')
            total += row.query_bytes/(14*row.windows)*mean('query_serialize')
            base = sum(mean(f'node{node}_full') for node in range(3))
            base += 3*(mean('quantize_one_node')+mean('rice2_encode')+mean('rice2_decode'))+mean('integer_fusion')
            if row.method == 'complete_rice3' or row.method.startswith('gap_'):
                continue  # no Rice3 codec or gap-rule timer: do not invent precision.
            subject.loc[index, 'estimated_component_cpu_ms_per_window'] = total
            subject.loc[index, 'estimated_full_push_component_cpu_ms_per_window'] = base
    return subject


def main():
    assert (OUT/'independent_verification.json').exists()
    results = [read(path) for path in sorted((OUT/'controllers').glob('*/*/*/*/results.json'))]
    assert len(results) == 192
    metrics = pd.DataFrame([row for result in results for row in result['metrics']])
    risk = pd.DataFrame([row for result in results for row in result['risk']])
    onsets = pd.DataFrame([row for result in results for row in result['onsets']])
    metrics.to_csv(OUT/'view_metrics.csv', index=False)
    risk.to_csv(OUT/'risk_view_metrics.csv', index=False)
    onsets.to_csv(OUT/'onsets.csv', index=False)
    onset_views = onset_summary(onsets)
    onset_views.to_csv(OUT/'onset_view_metrics.csv', index=False)
    keys = ['dataset', 'outer_fold', 'group', 'subject', 'stride', 'offset', 'method']
    metrics = metrics.merge(onset_views, on=keys, validate='one_to_one')
    # Preserve the stronger V15 comparator, including its cheaper 116 B setup profile.
    old_decision = read(ROOT/'results'/'continuous_collaboration_v15'/'research_decision.json')['datasets']
    baseline_rows = []
    for key, part in metrics.groupby(['dataset', 'outer_fold', 'group', 'subject', 'stride', 'offset']):
        dataset, fold, group, subject, stride, offset = key
        name = old_decision[dataset]['strongest_zero_wait_control'] if stride == 1 else old_decision[dataset]['nonoverlap'][offset]['strongest_control']
        source = ROOT/'results'/'continuous_collaboration_v15'/dataset/fold/f'subject{subject}'/f's2048_stride{stride}_offset{offset}_complete.json'
        old = next(row for row in read(source)['rows'] if row['method'] == name and row['max_extra_wait_seconds'] == 0)
        baseline_rows.append(dict(dataset=dataset, outer_fold=fold, group=group, subject=subject, stride=stride, offset=offset,
            baseline_method=name, baseline_bytes_per_window=old['total_bytes']/old['windows']))
    metrics = metrics.merge(pd.DataFrame(baseline_rows), on=['dataset', 'outer_fold', 'group', 'subject', 'stride', 'offset'], validate='many_to_one')
    subject_keys = ['dataset', 'stride', 'offset', 'method', 'subject']
    subject = metrics.groupby(subject_keys, as_index=False).mean(numeric_only=True)
    subject['savings_fraction'] = 1-subject.bytes_per_window/subject.baseline_bytes_per_window
    subject['positive_savings'] = subject.savings_fraction > 0
    subject['deployable_full_models_per_window'] = subject.full_models_per_window
    components = {dataset: read(OUT/'component_measurements'/f'{dataset}_measurements.json') for dataset in ('pamap2', 'mhealth')}
    subject = add_cost_estimates(subject, components)
    subject.to_csv(OUT/'subject_equal_metrics.csv', index=False)
    equal = subject.groupby(['dataset', 'stride', 'offset', 'method'], as_index=False).mean(numeric_only=True)
    equal['savings_fraction'] = 1-equal.bytes_per_window/equal.baseline_bytes_per_window
    equal['positive_subject_fraction'] = equal.positive_savings
    equal.to_csv(OUT/'dataset_equal_metrics.csv', index=False)
    risk_subject = risk.groupby(['dataset', 'stride', 'offset', 'model', 'horizon', 'subject'], as_index=False).mean(numeric_only=True)
    risk_subject['brier_skill_vs_training_constant'] = 1-risk_subject.brier/risk_subject.training_constant_brier
    risk_subject.to_csv(OUT/'risk_subject_equal.csv', index=False)
    risk_equal = risk_subject.groupby(['dataset', 'stride', 'offset', 'model', 'horizon'], as_index=False).mean(numeric_only=True)
    coverage = risk_subject.groupby(['dataset', 'stride', 'offset', 'model', 'horizon'], as_index=False).agg(subjects=('subject', 'count'), auc_defined_subjects=('auc', 'count'))
    risk_equal = risk_equal.merge(coverage, validate='one_to_one')
    risk_equal.to_csv(OUT/'risk_dataset_equal.csv', index=False)
    primary = []
    for _, row in equal[equal.method == 'survival_t0.01'].iterrows():
        item = row.to_dict()
        item['checks'] = checks(item)
        item['all_checks_passed'] = all(item['checks'].values())
        primary.append(item)
    passing = []
    for method, part in equal.groupby('method'):
        if len(part) == 6 and all(all(checks(row.to_dict()).values()) for _, row in part.iterrows()):
            passing.append(method)
    decision = dict(version='nested_validity_v17', primary='survival_t0.01', primary_replaced=False,
        primary_all_scenarios_passed=all(row['all_checks_passed'] for row in primary), primary_scenarios=primary,
        predeclared_points_passing_all_scenarios=passing,
        actual_component_measurement=True, actual_representative_short_stream_measurement=True,
        full_trajectory_cpu_measurement=False, actual_wireless_measurement=False, energy_measurement=False,
        new_core_contribution_established=False, no_new_validation=True, no_new_test=True)
    write(OUT/'research_decision.json', clean(decision))
    write(OUT/'report_data.json', clean(dict(decision=decision, risk=risk_equal.to_dict('records'),
        metrics=equal.to_dict('records'), components=components, audit=read(OUT/'independent_verification.json'))))
    report = ['# V17：跨受试者任务失效时间预测与组件实测', '',
        '仅使用原 18 个外层 TRAIN 角色，完成严格嵌套训练和受试者留出评估；没有新增验证／测试预测。预定主策略不随结果替换，新核心贡献尚未确立。', '',
        '## 数据与评价口径', '',
        '64 个控制器留出组、96 个新节点模型，控制器训练分数的拟合及选参均排除其留出组。192 组采样网格分别训练失效时间／当前冲突两个固定预测器，共 384 个。相同模型按精确拟合集合共享，每个引用保留谱系。', '',
        '失效指继续复用缓存辅助分数后，首次与完整量化融合参考冲突；主 horizon 是当前起 2 窗（偏移 0、1），不等于未来两个采样点，也不等于真实标签识别错误。只对 horizon 有完整随访的 landmark 算预测指标，删失单列。', '',
        '先在受试者内平均原外层重复，再等权受试者；重复窗口与重复外层结果不当独立样本。内层节点模型用 2／3 名受试者，而评估节点模型用 4／6 名，存在训练规模变化。缺类模型保留缺类惩罚，缺失槽固定 -4，没有借留出标签补齐。', '',
        '## 主场景预测与闭环结果']
    for dataset in ('pamap2', 'mhealth'):
        risk_row = risk_equal[(risk_equal.dataset == dataset) & (risk_equal.stride == 1) & (risk_equal.horizon == 2) & (risk_equal.model == 'survival')].iloc[0]
        binary = risk_equal[(risk_equal.dataset == dataset) & (risk_equal.stride == 1) & (risk_equal.horizon == 2) & (risk_equal.model == 'current')].iloc[0]
        row = equal[(equal.dataset == dataset) & (equal.stride == 1) & (equal.method == 'survival_t0.01')].iloc[0]
        current = equal[(equal.dataset == dataset) & (equal.stride == 1) & (equal.method == 'current_t0.01')].iloc[0]
        report += ['', f"{dataset}：当前起 2 窗 AUC {risk_row.auc:.4f}（{int(risk_row.auc_defined_subjects)}/{int(risk_row.subjects)} 名定义），"
            f"Brier {risk_row.brier:.5f}，训练常量对照 {risk_row.training_constant_brier:.5f}，ECE {risk_row.ece:.5f}。"
            f"当前冲突分类器作为同 horizon 排序代理的 AUC {binary.auc:.4f}；它的概率不是累计时间风险，不能直接当作已校准生存概率。",
            '', f"主策略 {row.bytes_per_window:.4f} B/窗，相对原最强完整推送 {row.baseline_bytes_per_window:.4f} B/窗节省 {row.savings_fraction*100:.2f}%；"
            f"参考差异 {row.reference_disagreement*100:.3f}%，已知终点 macro-F1 降幅 {row.known_endpoint_macro_f1_drop*100:.3f} 个百分点，"
            f"完整节点调用 {row.full_models_per_window:.4f}/窗。当前冲突策略为 {current.bytes_per_window:.4f} B/窗、参考差异 {current.reference_disagreement*100:.3f}%。"]
    report += ['', f"预定主策略全部场景保护：{'通过，仅代表训练内可行' if decision['primary_all_scenarios_passed'] else '未通过'}。"
        f"通过全部保护的预定方法数 {len(passing)}；没有据此替换主策略。", '',
        '## 实际组件成本与边界', '',
        '所有拟合结束后单独启动计时进程，固定单核、数值库单线程、批量 1。每个数据集在预定 TRAIN 受试者按时间均匀取 64 窗口，32 次预热后交错执行 8 轮，6 个代表节点模型共 3,072 次完整节点组件实测。均值、中位数、p95、CPU 时间、逐轮变化和原始纳秒记录全部保留，未扣除空计时器开销。', '',
        '测量开始前发现 Windows process CPU 时钟实际以 15.625 ms 更新，故留存了实施修订及原源码；另给每个组件增加至少 250 ms process CPU 的连续批量 1 精度块（含 Python 循环开销）。每次调用的原始 CPU 读数仍保留，但其零值不代表组件免费。全轨迹组件加总使用精度块均值，而非低分辨率逐次 CPU 均值。']
    for dataset, component in components.items():
        c = component['components']
        report += ['', f"{dataset}：节点 0 完整推理 wall 中位数 {c['node0_full']['wall']['median_ms']:.4f} ms；"
            f"本地原始统计哨兵 {c['raw_stats_sentinel']['wall']['median_ms']:.4f} ms；"
            f"特征＋失效预测头 {c['survival_features_and_head']['wall']['median_ms']:.4f} ms；"
            f"特征＋当前冲突头 {c['current_features_and_head']['wall']['median_ms']:.4f} ms。"]
        base, learned = (component['direct_stream'][name] for name in ('complete_push', 'survival_t0.01'))
        report += [f"同一 {base['windows']} 窗口短流，8 轮交错实测：完整推送 wall 中位数 {base['wall']['median_ms']:.3f} ms，"
            f"主学习策略 {learned['wall']['median_ms']:.3f} ms；实际节点调用 {sum(base['node_calls'])}/{sum(learned['node_calls'])}，"
            f"应用字节 {base['total_bytes']}/{learned['total_bytes']}。该短流未经标签筛选，不能代表整条受试者轨迹的平均收益。"]
    report += ['', '完整轨迹的组件加总仅为代表组件成本估计，未涵盖全部进程管理／规则／系统开销；完整轨迹没有逐窗实测 CPU。短流计时包含真实节点调用、控制器、量化、报文编码逆变换与融合，但不含磁盘读取、2 秒信号采集、真实无线和能耗。模型加载及首次调用单列；首次调用可能利用磁盘 JIT 缓存。', '',
        '学习策略已计每会话 134 B 配置及 494／454 B 真实 float64 权重包，状态、查询和回复都计费。固定周期主动推送无查询费；学习策略和当前风险对照采用相同成对查询。名义概率阈值按实际报文 float32 表示取值。', '',
        '## 审计与复现', '',
        '完整来源及冻结记录位于 results/nested_validity_v17/。independent_verification.json 分别记录全量谱系／训练分数拼接／保存输出／报文字节／FCFS 复核及抽样原始模型重放；分层报文逆变换不等于全部报文回放。此轮新闭环时延仅核验 250 kbps、每消息 1 ms 的模拟共享链路，不能解释为硬件时延。', '',
        'risk_subject_equal.csv 保留逐受试者预测指标，subject_equal_metrics.csv 保留通信、真实标签终点、未知／混合窗口及恢复指标；两个非重叠偏移和所有阈值见 dataset_equal_metrics.csv。report_data.json 是报告与展示的唯一结果来源。', '',
        '```powershell', 'rtk proxy python cscwd/run_v17_pipeline.py', '```', '']
    (ROOT/'CSCWD2027_严格嵌套失效时间预测结果V17.md').write_text('\n'.join(report), encoding='utf-8')
    readme_path = ROOT/'README.md'
    readme = readme_path.read_text(encoding='utf-8')
    first_section = readme.index('## V16：')
    intro = ['# CSCWD 多传感器协同识别工作区', '',
        '当前阶段：V17 已完成跨受试者任务失效时间预测的严格嵌套训练、固定策略闭环评估、真实 CPU 组件及短流测量。'
        + ('预定主候选通过训练内全部门槛；' if decision['primary_all_scenarios_passed'] else '预定主候选未通过训练内全部门槛；')
        + '尚未确立新核心贡献。没有新增验证／测试，V14—V16 冻结协议、结果及 IJCNN 稿保留。', '',
        '## V17：严格嵌套失效时间预测与实测（2026-10-18）', '',
        '新增 96 个内层节点模型，64 个控制器留出组；192 个采样网格各拟合失效时间与当前冲突模型，共 384 个固定预测器。'
        + '训练分数与全部选参均排除控制器留出受试者。所有阈值、两个非重叠偏移、混合／未知窗口及恢复失败均保留。', '']
    for dataset in ('pamap2', 'mhealth'):
        row = equal[(equal.dataset == dataset) & (equal.stride == 1) & (equal.method == 'survival_t0.01')].iloc[0]
        r = risk_equal[(risk_equal.dataset == dataset) & (risk_equal.stride == 1) & (risk_equal.model == 'survival') & (risk_equal.horizon == 2)].iloc[0]
        intro += [f"{dataset}：当前起 2 窗 AUC {r.auc:.4f}；主策略 {row.bytes_per_window:.4f} B/窗，节省 {row.savings_fraction*100:.2f}%，"
                  f"参考差异 {row.reference_disagreement*100:.3f}%，完整节点调用 {row.full_models_per_window:.4f}/窗。", '']
    intro += ['在所有拟合结束后的独立单核进程实测 6 个节点模型及原始哨兵、量化、编码逆变换、融合和预测头；'
        + '每项 32 次预热及 8×64 次交错测量。另直接运行两个数据集的真实短流完整推送／主学习策略，各 8 轮。'
        + '完整轨迹 CPU 仍只是组件加总估计；没有实测无线或能耗。', '',
        '149 项测试通过。详见[冻结协议](CSCWD2027_严格嵌套失效时间预测协议V17.md)、'
        + '[结果与解释](CSCWD2027_严格嵌套失效时间预测结果V17.md)，结果目录 `results/nested_validity_v17/`。', '']
    readme_path.write_text('\n'.join(intro)+'\n'+readme[first_section:], encoding='utf-8')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'artifact_manifest.json'}
    write(OUT/'artifact_manifest.json', manifest)
    print(json.dumps(clean(dict(primary_all_scenarios_passed=decision['primary_all_scenarios_passed'],
          points_passing=passing, main=[row for row in primary if row['stride'] == 1])), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
