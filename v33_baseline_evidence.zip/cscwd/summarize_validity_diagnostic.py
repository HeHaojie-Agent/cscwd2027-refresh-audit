"""Aggregate frozen V16 diagnostics without choosing a new primary."""
import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'results'/'collaboration_validity_v16'
V15 = ROOT/'results'/'continuous_collaboration_v15'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, obj):
    def clean(value):
        if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
        if isinstance(value, list): return [clean(v) for v in value]
        if isinstance(value, (np.integer,)): return int(value)
        if isinstance(value, (np.bool_,)): return bool(value)
        if isinstance(value, (float, np.floating)): return float(value) if np.isfinite(value) else None
        return value
    Path(path).write_text(json.dumps(clean(obj), ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def onset_summary(events):
    groups = ['dataset', 'outer_fold', 'subject', 'stride', 'offset', 'primary', 'method']
    rows = []
    for key, frame in events.groupby(groups, sort=False):
        row = dict(zip(groups, key))
        for criterion, part in frame.groupby('criterion', sort=False):
            visible = part[part.observable]
            extra = part.loc[part.extra_recovery_windows.notna(), 'extra_recovery_windows']
            row[criterion+'_observable_events'] = len(visible)
            row[criterion+'_additional_failure_fraction'] = float(visible.additional_failure.mean()) if len(visible) else None
            row[criterion+'_reference_failure_fraction'] = float(visible.reference_failure.mean()) if len(visible) else None
            row[criterion+'_candidate_failure_fraction'] = float(visible.candidate_failure.mean()) if len(visible) else None
            row[criterion+'_paired_successes'] = len(extra)
            row[criterion+'_p95_extra_recovery_windows'] = float(extra.quantile(.95)) if len(extra) else None
            row[criterion+'_right_censored_unobservable_events'] = int((~part.observable).sum())
        rows.append(row)
    return pd.DataFrame(rows)


def checks(row):
    result = dict(ten_percent_bytes_saved=bool(row['savings_fraction'] >= .1),
                  seventyfive_percent_subjects_positive=bool(row['positive_subject_fraction'] >= .75),
                  ten_percent_fewer_full_model_calls=bool(row['deployable_full_models_per_window'] <= 2.7),
                  reference_disagreement_at_most_one_percent=bool(row['reference_disagreement'] <= .01),
                  known_macro_f1_drop_at_most_half_pp=bool(row['known_endpoint_macro_f1_drop'] <= .005))
    for criterion in ('first_correct', 'two_consecutive_correct'):
        result[criterion+'_added_failures_at_most_one_pp'] = bool(row.get(criterion+'_additional_failure_fraction', np.nan) <= .01)
        result[criterion+'_paired_p95_extra_at_most_one_window'] = bool(row.get(criterion+'_p95_extra_recovery_windows', np.nan) <= 1.)
    return result


def summarize():
    from run_validity_diagnostic import assert_frozen, STEMS
    assert_frozen()
    completions = [json.loads((OUT/d/'complete.json').read_text()) for d in ('pamap2', 'mhealth')]
    assert sum(c['scenarios'] for c in completions) == 384
    assert all(c['all_scenarios_independently_reconstructed'] for c in completions)
    rows = pd.concat([pd.read_csv(OUT/d/'rows.csv') for d in ('pamap2', 'mhealth')], ignore_index=True)
    assert len(rows) == 15744, len(rows)
    onsets = pd.concat([pd.read_csv(OUT/d/'onsets.csv') for d in ('pamap2', 'mhealth')], ignore_index=True)
    onsets = onset_summary(onsets)
    onsets.to_csv(OUT/'onset_view_metrics.csv', index=False)
    join = ['dataset', 'outer_fold', 'subject', 'stride', 'offset', 'primary', 'method']
    rows = rows.merge(onsets, how='left', on=join, validate='one_to_one')
    decision15 = json.loads((V15/'research_decision.json').read_text())['datasets']
    baseline = []
    for path in sorted(OUT.glob('*/*/subject*/*_complete.json')):
        relative = path.relative_to(OUT)
        dataset, fold, subj, filename = relative.parts
        stem = filename.removesuffix('_complete.json')
        stride = 1 if 'stride1' in stem else 2
        offset = int(stem[-1])
        name = decision15[dataset]['strongest_zero_wait_control'] if stride == 1 else decision15[dataset]['nonoverlap'][offset]['strongest_control']
        old = json.loads((V15/relative).read_text())['rows']
        selected = [r for r in old if r['method'] == name and r['max_extra_wait_seconds'] == 0]
        assert len(selected) == 1
        base = selected[0]
        baseline.append(dict(dataset=dataset, outer_fold=fold, subject=int(subj.removeprefix('subject')),
                             stride=stride, offset=offset, baseline_method=name,
                             baseline_bytes_per_window=base['total_bytes']/base['windows']))
    rows = rows.merge(pd.DataFrame(baseline), on=['dataset', 'outer_fold', 'subject', 'stride', 'offset'], validate='many_to_one')
    groups = ['dataset', 'stride', 'offset', 'primary', 'method', 'subject']
    subject = rows.groupby(groups, as_index=False).mean(numeric_only=True)
    subject['savings_fraction'] = 1-subject.bytes_per_window/subject.baseline_bytes_per_window
    subject['positive_savings'] = subject.savings_fraction > 0
    subject.to_csv(OUT/'subject_equal_metrics.csv', index=False)
    groups = ['dataset', 'stride', 'offset', 'primary', 'method']
    equal = subject.groupby(groups, as_index=False).mean(numeric_only=True)
    equal['savings_fraction'] = 1-equal.bytes_per_window/equal.baseline_bytes_per_window
    equal['positive_subject_fraction'] = equal.positive_savings
    equal.to_csv(OUT/'dataset_equal_metrics.csv', index=False)
    for name in ('validity', 'risk'):
        frame = pd.concat([pd.read_csv(OUT/d/(name+'.csv')) for d in ('pamap2', 'mhealth')], ignore_index=True)
        keys = ['dataset', 'stride', 'offset', 'primary'] + (['horizon'] if name == 'validity' else ['age_windows', 'target', 'signal'])
        frame = frame.groupby(keys+['subject'], as_index=False).mean(numeric_only=True)
        frame.to_csv(OUT/(name+'_subject_equal.csv'), index=False)
        frame.groupby(keys, as_index=False).mean(numeric_only=True).to_csv(OUT/(name+'_dataset_equal.csv'), index=False)
    primary = {}
    for dataset in ('pamap2', 'mhealth'):
        cases = equal[(equal.dataset == dataset) & (equal.primary == 0) & (equal.method == 'sentinel_h8_t0.25')]
        scenario_rows = []
        for _, row in cases.iterrows():
            item = row.to_dict()
            item['checks'] = checks(item)
            item['all_checks_passed'] = all(item['checks'].values())
            scenario_rows.append(item)
        assert len(scenario_rows) == 3
        primary[dataset] = dict(scenarios=scenario_rows, all_three_scenarios_passed=all(x['all_checks_passed'] for x in scenario_rows))
    # All alternative operating points remain diagnostic; primary is never replaced.
    passing = []
    for (node, method), part in equal[(equal.primary >= 0) & (equal['mode'] != 3)].groupby(['primary', 'method']):
        if len(part) == 6 and all(all(checks(row.to_dict()).values()) for _, row in part.iterrows()):
            passing.append(dict(primary_node=int(node), method=method))
    write(OUT/'research_decision.json', dict(version='collaboration_validity_v16',
          phase='no-fit training diagnostics only', primary_node=0, primary_method='sentinel_h8_t0.25',
          primary_replaced=False, datasets=primary,
          main_diagnostic_passed=all(x['all_three_scenarios_passed'] for x in primary.values()),
          all_predeclared_causal_points_passing_all_scenarios=passing,
          new_core_contribution_established=False, trained_validity_predictor=False,
          independent_new_controller_generalization_established=False,
          no_new_validation=True, no_new_test=True,
          oracle_is_noncausal_and_not_global_optimum=True,
          skipped_model_calls_are_simulated_not_measured_cpu_or_energy=True))
    audit = dict(scenarios=384, method_scenario_rows=len(rows),
                 primary_training_views=128, diagnostic_input_roles='TRAIN only',
                 schedule_and_prediction_reconstructed_independently_all_scenarios=True,
                 exact_packet_length_formula_checked_against_v15_full_controls=True,
                 deterministic_stratified_packet_inverses=sum(c['packet_inverse_samples'] for c in completions),
                 full_packet_by_packet_wire_replay=False,
                 frozen_inputs_and_sources_verified=True,
                 no_new_validation=True, no_new_test=True)
    write(OUT/'independent_verification.json', audit)
    write(OUT/'report_data.json', dict(decision=json.loads((OUT/'research_decision.json').read_text()),
                                     metrics=equal.to_dict('records'), audit=audit))
    write(OUT/'environment.json', dict(python=sys.version, platform=platform.platform(),
          cost_scope='exact application bytes and modeled channel; cached-score model-call simulation; no measured online CPU or energy saving',
          elapsed_scope='per invocation, can include restored checkpoints; not cumulative compute'))
    main = equal[(equal.stride == 1) & (equal.primary == 0) & (equal.method == 'sentinel_h8_t0.25')]
    report = ['# CSCWD：协作信息有效期训练诊断 V16', '',
              '本轮只完成训练内、无拟合的有效期与简单规则诊断。没有训练新控制器、没有新验证／测试，也未确立新贡献。', '',
              '## 预定主候选', '',
              '物理节点索引 0 持续运行；辅助节点运行本地原始信号哨兵，变化阈值 0.25，最大复用 8 窗口。参考仍为 V15 量化整数融合，不是原始 float32 无损。']
    for _, row in main.iterrows():
        report += ['', f"{row.dataset}：总费用 {row.bytes_per_window:.4f} B/窗口，对照 {row.baseline_bytes_per_window:.4f}，节省 {row.savings_fraction*100:.2f}%；"
                   f"参考不一致 {row.reference_disagreement*100:.3f}%；已知终点 macro-F1 降幅 {row.known_endpoint_macro_f1_drop*100:.3f} 个百分点；"
                   f"模拟完整模型调用 {row.deployable_full_models_per_window:.4f}/窗口；模拟信道 p95 {row.channel_p95_ms:.4f} ms。"]
    passed = all(x['all_three_scenarios_passed'] for x in primary.values())
    report += ['', f"主候选全部预设场景门槛：{'通过，但只是诊断可行' if passed else '未通过；不按敏感性结果替换主候选'}。",
               f"全部预定简单因果点中通过两数据集及两非重叠偏移的点数：{len(passing)}；详见 research_decision.json。", '',
               '## 如何解读', '',
               '原始信号哨兵统计在各辅助节点本地计算；未触发时当前隐藏分数不进入可部署选择器。周期、哨兵和置信度规则均不拟合参数。第一冲突 oracle 看到了隐藏完整分数，不可部署，也不是全局最优上界；其模型调用数按全观察 3 次/窗报告。', '',
               '每条消息计入 14 B 头、真实字节取整、配置、状态和必要查询。会话配置 134 B，比 V15 多 18 B；完整推送控制也支付该费用。V15 最强对照原费用仍单列用于严格比较。', '',
               '费用为精确长度公式，确定分层报文实际序列化并逆变换；没有把抽样核对说成全报文回放。所有情景的发送状态和输出由独立实现重构。模拟调用减少尚未证明实际总 CPU 或能耗节省，原始采样与哨兵仍持续运行。', '',
               '## 失效、前瞻信号和切换', '',
               'validity_dataset_equal.csv 报告完整随访中的首次冲突风险及右删失数量；risk_dataset_equal.csv 报告无拟合信号的当前冲突／未来两窗风险 AUC。全局最大本地变化仅是离线诊断，协调器没有免费得到它。没有正负例时 AUC 缺失。', '',
               'subject_equal_metrics.csv 保留每位受试者及混合／未知窗口情况、连续错误、复用周期错误及恢复失败。onset_view_metrics.csv 分开列出配对成功的额外恢复窗口与新增失败率；不能只看成功事件的平均延迟。活动标注起点不保证是未知间隔中的物理切换。', '',
               '全部结果先在受试者内平均重复外层划分，再等权受试者；365,108 条主场景角色预测不是独立样本。V14 分数只支持此处无拟合诊断；后续训练有效期预测器须重新按控制器内部划分嵌套生成底层分数。', '',
               '## 文件与复现', '',
               '协议见 CSCWD2027_信息有效期诊断协议V16.md；冻结记录、输入哈希、逐窗输出和全部比较均在 results/collaboration_validity_v16/。', '',
               '```powershell', 'rtk proxy python cscwd/run_validity_diagnostic.py --prepare-only',
               'rtk proxy python cscwd/run_validity_diagnostic.py --dataset pamap2',
               'rtk proxy python cscwd/run_validity_diagnostic.py --dataset mhealth',
               'rtk proxy python cscwd/summarize_validity_diagnostic.py', '```', '']
    (ROOT/'CSCWD2027_信息有效期诊断结果V16.md').write_text('\n'.join(report), encoding='utf-8')
    manifest = {str(p.relative_to(OUT)): digest(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name != 'artifact_manifest.json'}
    write(OUT/'artifact_manifest.json', manifest)
    print(json.dumps(dict(main_diagnostic_passed=passed, alternative_causal_points_passing=len(passing), audit=audit), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    summarize()
