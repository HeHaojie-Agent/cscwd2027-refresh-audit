"""V17 causal controller, with scalar paid inputs and paired helper refresh."""
import numpy as np
from numba import njit


@njit(cache=True)
def feature_one(current_primary, anchor_q, age):
    x = np.empty(52, np.float64)
    total_delta = 0.
    first, second, ffirst, fsecond = -1., -1., -1., -1.
    for c in range(12):
        now = float(current_primary[c])
        delta = now-float(anchor_q[0, c])
        fused = now+float(anchor_q[1, c])+float(anchor_q[2, c])
        x[c] = now/255
        x[12+c] = delta/255
        x[24+c] = float(anchor_q[1, c])/255
        x[36+c] = float(anchor_q[2, c])/255
        total_delta += abs(delta)
        if now > first:
            first, second = now, first
        elif now > second:
            second = now
        if fused > ffirst:
            ffirst, fsecond = fused, ffirst
        elif fused > fsecond:
            fsecond = fused
    x[48] = age/16.
    x[49] = (first-second)/255
    x[50] = (ffirst-fsecond)/765
    x[51] = total_delta/(12*255)
    return x


@njit(cache=True)
def risk_one(current_primary, anchor_q, age, coefficient, intercept, survival):
    x = feature_one(current_primary, anchor_q, age)
    base = intercept
    for j in range(52):
        base += x[j]*coefficient[j]
    remaining = 1.
    for bin_id in range(2 if survival else 1):
        value = base+coefficient[52+bin_id] if survival else base
        hazard = 1/(1+np.exp(-value)) if value >= 0 else np.exp(value)/(1+np.exp(value))
        remaining *= 1-hazard
    return 1-remaining


@njit(cache=True)
def run_schedule(q, reset, mode, horizon, threshold, coefficient, intercept):
    # mode 0 fixed periodic push; 1 survival query; 2 current query; 3 gap query.
    n = len(q)
    send = np.zeros((n, 3), np.bool_)
    requests = np.zeros((n, 3), np.bool_)
    prediction = np.empty(n, np.int16)
    probabilities = np.full(n, np.nan)
    anchor = 0
    for t in range(n):
        refresh = bool(reset[t])
        if not refresh:
            age = t-anchor
            if mode in (1, 2):
                probability = risk_one(q[t, 0], q[anchor], age, coefficient, intercept, mode == 1)
                probabilities[t] = probability
                refresh = age >= horizon or probability >= threshold
            elif mode == 3:
                values = np.sort(q[t, 0])
                refresh = age >= horizon or int(values[-1])-int(values[-2]) <= threshold
            else:
                refresh = age >= horizon
            if refresh and mode != 0:
                requests[t, 1:] = True
        send[t, 0] = True
        if refresh:
            send[t, 1:] = True
            anchor = t
        best, maximum = 0, -1
        for c in range(12):
            value = int(q[t, 0, c])+int(q[anchor, 1, c])+int(q[anchor, 2, c])
            if value > maximum:
                maximum, best = value, c
        prediction[t] = best
    return send, requests, prediction, probabilities


def verify_schedule(q, reset, mode, horizon, threshold, model, result):
    """Independent vectorized reconstruction, including decisions before refresh."""
    from validity_survival import paid_features, risks
    send, requests, prediction, probabilities = result
    n = len(q)
    assert send[:, 0].all() and send[reset].all()
    np.testing.assert_array_equal(send[:, 1], send[:, 2])
    last = np.maximum.accumulate(np.where(send[:, 1], np.arange(n), -1))
    assert (last >= 0).all()
    previous = np.r_[0, last[:-1]]
    expected = np.argmax(q[:, 0].astype(int)+q[last, 1].astype(int)+q[last, 2].astype(int), axis=1)
    np.testing.assert_array_equal(prediction, expected)
    due = np.arange(n)-previous >= horizon
    if mode in (1, 2):
        p = risks(model, paid_features(q, np.arange(n), previous))[:, 1 if mode == 1 else 0]
        np.testing.assert_allclose(probabilities[~reset], p[~reset], atol=1e-12, rtol=1e-12)
        early = p >= threshold
    elif mode == 3:
        values = np.sort(q[:, 0].astype(int), axis=1)
        early = values[:, -1]-values[:, -2] <= threshold
    else:
        early = np.zeros(n, bool)
    np.testing.assert_array_equal(send[:, 1], reset | due | early)
    np.testing.assert_array_equal(requests[:, 1], ~reset & (due | early) & (mode != 0))
    assert not requests[:, 0].any()
    np.testing.assert_array_equal(requests[:, 1], requests[:, 2])
