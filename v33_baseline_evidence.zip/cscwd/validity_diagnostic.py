"""V16 no-fit causal reuse controls and explicitly noncausal diagnostics."""
import struct
import numpy as np
from numba import njit
from causal_score_codec import ExactCodec, HEADER

HORIZONS = (1, 2, 4, 8, 16)
POLICIES = ([dict(name=f'periodic_h{h}', mode=0, horizon=h, threshold=0.) for h in HORIZONS]
            + [dict(name=f'sentinel_h8_t{v:g}', mode=1, horizon=8, threshold=v) for v in (.125, .25, .5, 1.)]
            + [dict(name=f'margin_h8_t{v}', mode=2, horizon=8, threshold=float(v)) for v in (4, 16, 32)]
            + [dict(name='oracle_first_conflict_h16', mode=3, horizon=16, threshold=0.)])


def summaries(x, axes):
    """Only local observed signals; input N,C,T, output N,3,4,axes."""
    z = np.asarray(x, np.float64).reshape(len(x), 3, axes, x.shape[-1])
    if not np.isfinite(z).all():
        raise ValueError('Nonfinite observed window')
    return np.stack([z.mean(-1), z.std(-1), np.sqrt(np.mean(np.diff(z, axis=-1)**2, axis=-1)),
                     np.sqrt(np.mean(z*z, axis=-1))], axis=2).astype(np.float32)


@njit(cache=True)
def distance(feature, anchor):
    largest = 0.
    for kind in range(3):
        for axis in range(feature.shape[1]):
            value = abs(np.float64(feature[kind, axis]) - np.float64(anchor[kind, axis])) / (np.float64(anchor[3, axis]) + 1e-6)
            largest = max(largest, value)
    return largest


@njit(cache=True)
def winner(q, t, anchors, primary):
    best, best_value = 0, -1
    for c in range(12):
        value = 0
        for node in range(3):
            at = t if node == primary else anchors[node]
            value += int(q[at, node, c])
        if value > best_value:
            best, best_value = c, value
    return best


@njit(cache=True)
def schedule(q, features, reset, primary, mode, horizon, threshold):
    """Modes 0..2 never read unscheduled helper current scores; mode 3 is oracle."""
    n = len(q)
    send = np.zeros((n, 3), np.bool_)
    requests = np.zeros((n, 3), np.bool_)
    prediction = np.empty(n, np.int16)
    anchors = np.zeros(3, np.int64)
    for t in range(n):
        if reset[t]:
            for node in range(3):
                send[t, node] = True
        else:
            send[t, primary] = True
            first, second = -1, -1
            for c in range(12):
                value = int(q[t, primary, c])
                if value > first:
                    first, second = value, first
                elif value > second:
                    second = value
            low_margin = first - second <= threshold
            conflict = False
            if mode == 3:
                current = np.full(3, t, np.int64)
                conflict = winner(q, t, anchors, primary) != winner(q, t, current, primary)
            for node in range(3):
                if node == primary:
                    continue
                due = t - anchors[node] >= horizon
                early = ((mode == 1 and distance(features[t, node], features[anchors[node], node]) > threshold)
                         or (mode == 2 and low_margin) or (mode == 3 and conflict))
                send[t, node] = due or early
                requests[t, node] = early and not due and mode in (2, 3)
        for node in range(3):
            if send[t, node]:
                anchors[node] = t
        prediction[t] = winner(q, t, anchors, primary)
    return send, requests, prediction


def packet_cost(q, send, reset, windows, stamps, method='rice2'):
    """Exact byte lengths, with real deterministic stratified packet inverses."""
    n = len(q)
    charged = np.zeros(n, np.int32)
    audits = 0
    for node in range(3):
        chosen = np.flatnonzero(send[:, node])
        if not len(chosen):
            raise ValueError('Missing initial helper state')
        rows = q[chosen, node]
        diff = rows.astype(np.int16) - np.vstack([np.zeros((1, 12), np.int16), rows[:-1].astype(np.int16)])
        symbols = np.where(diff >= 0, 2*diff, -2*diff-1)
        bits = ((symbols >> int(method[-1])) + 1 + int(method[-1])).sum(1)
        lengths = 14 + np.minimum(12, (bits+7)//8)
        initial = reset[chosen]
        lengths[initial] = 26
        charged[chosen] += lengths.astype(np.int32)
        gaps = np.r_[0, np.diff(chosen)]
        sampled = set(np.linspace(0, len(chosen)-1, min(16, len(chosen)), dtype=int).tolist())
        sampled.update(np.flatnonzero(initial).tolist())
        for gap in np.unique(gaps):
            indices = np.flatnonzero(gaps == gap)
            sampled.update((int(indices[0]), int(indices[-1])))
        for j in sorted(sampled):
            encoder, decoder = ExactCodec(method), ExactCodec(method)
            if not initial[j]:
                assert j > 0
                encoder.previous = rows[j-1].copy()
                decoder.previous = rows[j-1].copy()
            at = int(chosen[j])
            packet = encoder.encode(rows[j:j+1], node, int(windows[at]), int(stamps[at]))
            restored = decoder.decode(packet, 1, node, int(windows[at]), int(stamps[at]))
            assert len(packet) == lengths[j]
            np.testing.assert_array_equal(restored, rows[j:j+1])
            audits += 1
    return charged, audits


def profile(policy_id, horizon, threshold):
    packets = [HEADER.pack(4, 255, 0, 0) + np.tile([-4., 4.], (3, 1)).astype('<f8').tobytes()]
    for node in range(3):
        body = struct.pack('<BBHBBf', 2, 0, 128, policy_id, horizon, threshold)
        packet = HEADER.pack(5, node, 0, 0) + body
        assert len(packet) == 24
        assert struct.unpack('<BBHBBf', packet[14:]) == (2, 0, 128, policy_id, horizon, threshold)
        packets.append(packet)
    assert sum(map(len, packets)) == 134
    return packets


def independent_schedule_check(q, features, reset, primary, policy, send, requests, prediction):
    """Vectorized independent state reconstruction and current-information checks."""
    n = len(q)
    last = np.maximum.accumulate(np.where(send, np.arange(n)[:, None], -1), axis=0)
    previous = np.vstack([np.zeros((1, 3), int), last[:-1]])
    assert (last >= 0).all() and send[reset].all() and send[:, primary].all()
    cache = q[last, np.arange(3)[None, :]]
    recovered = np.argmax(cache.astype(np.int32).sum(1), axis=1)
    np.testing.assert_array_equal(recovered, prediction)
    best = np.sort(q[:, primary].astype(int), axis=1)
    low_margin = best[:, -1] - best[:, -2] <= policy['threshold']
    current = q[:, primary].astype(np.int32).copy()
    for node in range(3):
        if node != primary:
            current += q[previous[:, node], node].astype(np.int32)
    conflict = np.argmax(current, axis=1) != np.argmax(q.astype(np.int32).sum(1), axis=1)
    for node in range(3):
        if node == primary:
            assert not requests[:, node].any()
            continue
        due = np.arange(n) - previous[:, node] >= policy['horizon']
        anchor = features[previous[:, node], node].astype(float)
        change = (np.abs(features[:, node, :3].astype(float) - anchor[:, :3]) / (anchor[:, 3:4] + 1e-6)).max(axis=(1, 2))
        mode = policy['mode']
        early = change > policy['threshold'] if mode == 1 else low_margin if mode == 2 else conflict if mode == 3 else np.zeros(n, bool)
        np.testing.assert_array_equal(send[:, node], reset | due | early)
        np.testing.assert_array_equal(requests[:, node], ~reset & ~due & early & (mode in (2, 3)))


@njit(cache=True)
def validity(q, features, reset, primary):
    """First conflict and observed followup (<=16); never cross a reset."""
    n = len(q)
    first = np.zeros(n, np.int16)
    observed = np.zeros(n, np.int16)
    for anchor in range(n):
        anchors = np.full(3, anchor, np.int64)
        for delta in range(1, min(17, n-anchor)):
            t = anchor+delta
            if reset[t]:
                break
            observed[anchor] = delta
            current = np.full(3, t, np.int64)
            if first[anchor] == 0 and winner(q, t, anchors, primary) != winner(q, t, current, primary):
                first[anchor] = delta
    return first, observed


def longest_error(prediction, reference, reset):
    error = prediction != reference
    lengths, run = [], 0
    for t, value in enumerate(error):
        if reset[t] and run:
            lengths.append(run)
            run = 0
        if value:
            run += 1
        elif run:
            lengths.append(run)
            run = 0
    if run:
        lengths.append(run)
    return max(lengths, default=0)


def auc_diagnostics(q, features, reset, primary, step_seconds):
    from sklearn.metrics import roc_auc_score
    rows = []
    n = len(q)
    segment = np.cumsum(reset)
    reference = np.argmax(q.astype(np.int32).sum(1), axis=1)
    for age in (1, 2, 4, 8):
        at = np.arange(age, n-2)
        keep = segment[at-age] == segment[at+2]
        at = at[keep]
        anchor = at-age
        if not len(at):
            continue
        cache = q[anchor].astype(np.int32).sum(1)-q[anchor, primary].astype(np.int32)
        current_error = np.argmax(cache+q[at, primary], axis=1) != reference[at]
        future_error = np.zeros(len(at), bool)
        for offset in (1, 2):
            future_error |= np.argmax(cache+q[at+offset, primary], axis=1) != reference[at+offset]
        helper_scores = []
        for node in range(3):
            if node != primary:
                z = features[anchor, node].astype(float)
                helper_scores.append((np.abs(features[at, node, :3].astype(float)-z[:, :3])/(z[:, 3:4]+1e-6)).max((1, 2)))
        raw = np.maximum(*helper_scores)
        primary_values = np.sort(q[at, primary].astype(float), axis=1)
        margin = -(primary_values[:, -1]-primary_values[:, -2])
        for target, values in [('current_conflict', current_error), ('next_two_windows_any_conflict', future_error)]:
            for signal, scores in [('offline_max_local_raw_change', raw), ('paid_primary_negative_margin', margin)]:
                rows.append(dict(primary=primary, age_windows=age, step_seconds=step_seconds,
                                 target=target, signal=signal, samples=len(values), positives=int(values.sum()),
                                 auc=float(roc_auc_score(values, scores)) if 0 < values.sum() < len(values) else None))
    return rows
