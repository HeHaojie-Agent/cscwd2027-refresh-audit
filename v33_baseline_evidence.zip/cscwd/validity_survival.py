"""Paid-information-only landmark survival prediction for V17."""
import hashlib
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

from continuous_training_data import CONFIG
from continuous_screen_accounting import physical_resets, session_grid
from causal_score_codec import HEADER

HORIZONS = (1, 2, 4, 8, 16)
AGES = (1, 2, 4, 8, 16)
FEATURES = 52


def frame(path, dataset, stride=1, offset=0):
    with np.load(path, allow_pickle=False) as saved:
        f = {key: saved[key] for key in saved.files if key not in ('scores', 'reference_prediction')}
        scores = saved['scores']
    f['q'] = np.rint(np.clip((scores.astype(np.float64)+4)/8, 0, 1)*255).astype(np.uint8)
    physical = physical_resets(f['subjects'], f['stream_ids'], f['start_rows'], f['end_time'], CONFIG[dataset]['stride'])
    if stride == 2:
        starts = np.flatnonzero(physical)
        chosen = np.concatenate([np.arange(start, stop)[offset::2] for start, stop in zip(starts, np.r_[starts[1:], len(physical)])])
        f = {key: value if key == 'classes' else value[chosen] for key, value in f.items()}
        physical = physical_resets(f['subjects'], f['stream_ids'], f['start_rows'], f['end_time'], CONFIG[dataset]['stride']*2, seconds=2)
    f['physical_reset'] = physical
    f['reset'] = np.ones(len(physical), bool)
    f['session_start'] = np.zeros(len(physical), bool)
    f['status'] = np.zeros(len(physical), bool)
    for subject in np.unique(f['subjects']):
        at = np.flatnonzero(f['subjects'] == subject)
        f['reset'][at], f['session_start'][at], f['status'][at] = session_grid(physical[at], 2048)
    f['reference'] = np.argmax(f['q'].astype(np.int32).sum(1), axis=1)
    return f


def paid_features(q, current, anchor):
    current, anchor = np.atleast_1d(current), np.atleast_1d(anchor)
    now = q[current, 0].astype(np.float64)
    past = q[anchor].astype(np.float64)
    delta = now-past[:, 0]
    fused = now+past[:, 1:].sum(1)
    p = np.sort(now, axis=1)
    c = np.sort(fused, axis=1)
    result = np.column_stack([now/255, delta/255, past[:, 1:].reshape(-1, 24)/255,
                              (current-anchor)/16, (p[:, -1]-p[:, -2])/255,
                              (c[:, -1]-c[:, -2])/765, np.mean(np.abs(delta), axis=1)/255])
    assert result.shape[1] == FEATURES
    return result


def landmarks(f, training=False):
    q = f['q']
    n = len(q)
    segment = np.cumsum(f['reset'])
    blocks = []
    for age in AGES:
        t = np.arange(age, n)
        t = t[segment[t] == segment[t-age]]
        for subject in np.unique(f['subjects']):
            at = t[f['subjects'][t] == subject]
            if training and len(at) > 128:
                at = at[np.linspace(0, len(at)-1, 128, dtype=int)]
            if len(at):
                blocks.append((at, at-age))
    current = np.concatenate([b[0] for b in blocks]) if blocks else np.empty(0, int)
    anchor = np.concatenate([b[1] for b in blocks]) if blocks else np.empty(0, int)
    x = paid_features(q, current, anchor)
    first = np.full(len(current), -1, np.int16)
    observed = np.zeros(len(current), np.int16)
    helper = q[anchor, 1:].astype(np.int32).sum(1)
    for ahead in range(16):
        valid = current+ahead < n
        positions = np.flatnonzero(valid)
        positions = positions[segment[current[positions]] == segment[current[positions]+ahead]]
        t = current[positions]+ahead
        error = np.argmax(q[t, 0].astype(np.int32)+helper[positions], axis=1) != f['reference'][t]
        first[positions[(first[positions] < 0) & error]] = ahead
        observed[positions] = ahead+1
    return dict(x=x, first=first, observed=observed, subjects=f['subjects'][current],
                current=current, anchor=anchor)


def training_rows(data, kind):
    x, first, observed = data['x'], data['first'], data['observed']
    if kind == 'current':
        return x, (first == 0).astype(int), data['subjects']
    xs, ys, subjects = [], [], []
    previous = 0
    for bin_id, horizon in enumerate(HORIZONS):
        active = (first < 0) | (first >= previous)
        event = (first >= previous) & (first < horizon)
        keep = active & ((observed >= horizon) | event)
        onehot = np.zeros((int(keep.sum()), 5))
        onehot[:, bin_id] = 1
        xs.append(np.column_stack([x[keep], onehot]))
        ys.append(event[keep].astype(int))
        subjects.append(data['subjects'][keep])
        previous = horizon
    return np.concatenate(xs), np.concatenate(ys), np.concatenate(subjects)


def logistic(z):
    z = np.asarray(z, float)
    out = np.empty_like(z)
    positive = z >= 0
    out[positive] = 1/(1+np.exp(-z[positive]))
    exponent = np.exp(z[~positive])
    out[~positive] = exponent/(1+exponent)
    return out


def fit_predictor(data, kind):
    x, y, subjects = training_rows(data, kind)
    labels, counts = np.unique(subjects, return_counts=True)
    weights = np.zeros(len(y))
    for subject, count in zip(labels, counts):
        weights[subjects == subject] = len(y)/(len(labels)*count)
    scaler = StandardScaler().fit(x, sample_weight=weights)
    if len(np.unique(y)) == 1:
        probability = (float((y*weights).sum())+.5)/(float(weights.sum())+1)
        coefficient = np.zeros(x.shape[1])
        intercept = float(np.log(probability/(1-probability)))
        uncollapsed = np.full(min(len(x), 1024), probability)
        iterations = 0
    else:
        model = LogisticRegression(C=1., solver='lbfgs', max_iter=500).fit(scaler.transform(x), y, sample_weight=weights)
        coefficient = model.coef_[0]/scaler.scale_
        intercept = float(model.intercept_[0]-np.dot(model.coef_[0], scaler.mean_/scaler.scale_))
        uncollapsed = model.predict_proba(scaler.transform(x[:1024]))[:, 1]
        iterations = int(model.n_iter_.max())
        if iterations >= 500:
            raise RuntimeError('Fixed controller iteration limit reached; do not silently change it')
    folded = logistic(x[:1024]@coefficient+intercept)
    error = float(np.max(np.abs(folded-uncollapsed)))
    assert error < 1e-10
    for threshold in (.01, .05, .1):
        assert np.array_equal(folded >= threshold, uncollapsed >= threshold)
    constant = []
    for column in range(5 if kind == 'survival' else 1):
        select = x[:, FEATURES+column] == 1 if kind == 'survival' else np.ones(len(y), bool)
        constant.append(float(((y*weights)[select].sum()+.5)/(weights[select].sum()+1)))
    return dict(kind=kind, coefficient=coefficient, intercept=intercept, training_constant_hazard=constant,
                training_subjects=labels.tolist(), training_rows=len(y), positive_rows=int(y.sum()),
                folded_probability_error=error, iterations=iterations)


def risks(model, features):
    features = np.atleast_2d(features)
    if model['kind'] == 'current':
        return logistic(features@model['coefficient']+model['intercept'])[:, None]
    base = features@model['coefficient'][:FEATURES]+model['intercept']
    hazard = logistic(base[:, None]+model['coefficient'][FEATURES:][None, :])
    return 1-np.cumprod(1-hazard, axis=1)


def weight_packet(model):
    values = np.r_[model['coefficient'], model['intercept']].astype('<f8')
    identifier = hashlib.sha256(values.tobytes()).digest()[:16]
    packet = HEADER.pack(91 if model['kind'] == 'survival' else 92, 0, 0, 0)+identifier+values.tobytes()
    np.testing.assert_array_equal(np.frombuffer(packet[30:], '<f8'), values)
    return packet


def prediction_metrics(model, data):
    probabilities = risks(model, data['x'])
    constant = np.asarray(model['training_constant_hazard'])
    constant = 1-np.cumprod(1-constant) if model['kind'] == 'survival' else constant
    rows = []
    for subject in np.unique(data['subjects']):
        for column, horizon in enumerate(HORIZONS):
            keep = (data['subjects'] == subject) & (data['observed'] >= horizon)
            y = ((data['first'][keep] >= 0) & (data['first'][keep] < horizon)).astype(int)
            p = probabilities[keep, column if model['kind'] == 'survival' else 0]
            p_constant = constant[column if model['kind'] == 'survival' else 0]
            ece = 0.
            for low, high in zip(np.linspace(0, 1, 11)[:-1], np.linspace(0, 1, 11)[1:]):
                part = (p >= low) & ((p < high) if high < 1 else (p <= high))
                if part.any():
                    ece += float(part.mean()*abs(p[part].mean()-y[part].mean()))
            all_landmarks = data['subjects'] == subject
            rows.append(dict(subject=int(subject), model=model['kind'], horizon=horizon,
                             probability_is_current_conflict_proxy=model['kind'] == 'current' and horizon != 1,
                             eligible_landmarks=int(all_landmarks.sum()), complete_followup=int(keep.sum()),
                             right_censored=int(all_landmarks.sum()-keep.sum()), positive=int(y.sum()),
                             auc=float(roc_auc_score(y, p)) if 0 < y.sum() < len(y) else None,
                             brier=float(np.mean((p-y)**2)) if len(y) else None,
                             training_constant_brier=float(np.mean((p_constant-y)**2)) if len(y) else None,
                             ece=ece if len(y) else None))
    return rows
